<?php
  session_start();

include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
middle();
} 

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$check=1;
	$email=$arr[7];
        $name=$arr[1];
	$ref=$arr[11];
	$username=$_SESSION[username_session];
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
	}
	else {
		$statust="Pro";
	}
	$total=$arr[15];
	$paid=$arr[17];
	$unpaid=$arr[16];

?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Approved Gifts</b></font></p>
<br>
<b>Gifts Received:</b><br>
<?
    $sql="Select * from gifts where TUsername='$_SESSION[username_session]' and approved=1 order by ID";
    $wrs=mysql_query($sql);
    if(mysql_num_rows($wrs)>0) {
    $rc=0;
    echo("<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><font face=verdana size=2><b>#</b></font></td>
	<td align=center><font face=verdana size=2><b>From</b></font></td>
	<td align=center><font face=verdana size=2><b>Payment Details</b></font></td>
	<td align=center><font face=verdana size=2><b>Amount</b></font></td>
	<td align=center><font face=verdana size=2><b>Matrix</b></font></td>
	<td align=center><font face=verdana size=2><b>Date</b></font></td>
	<td align=center><font face=verdana size=2><b>Approval Date</b></font></td>
	</tr>");
	$rc=0;
    while($rss=mysql_fetch_row($wrs))
    {
	$rc++;
$rsm=mysql_query("select ID,Name,fee from membershiplevels where ID=$rss[6]");
$arrm=mysql_fetch_array($rsm);
if($rss[1]=="admin") $rss[1]="sukhminder";
      echo("<tr><td align=center><font face=verdana size=2>".$rc."</font></td>
	  <Td align=center><font face=verdana size=2>". $rss[1]."</font></td>
	  <Td align=center><font face=verdana size=2>$rss[3] ( $rss[4] )</font></td>
	  <Td align=center><font face=verdana size=2>$". $rss[5]." </font></td>
	  <Td align=center><font face=verdana size=2>$arrm[1] ( $$arrm[2] )<br>( ID: $rss[7] )</font></td>
	  <Td align=center><font face=verdana size=2>". $rss[9]." </font></td>
	  <Td align=center><font face=verdana size=2>$rss[10]</font></td>
	  </tr>");
    }
    echo("</table>");
    }
    else {
	echo "<br><b>No Records Found</b><br>";
    }
?>
<br><b>Gifts Sent:</b><br>
<?
    $sql="Select * from gifts where FUsername='$_SESSION[username_session]' and approved=1 order by ID";
    $wrs=mysql_query($sql);
    if(mysql_num_rows($wrs)>0) {
    $rc=0;
    echo("<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><font face=verdana size=2><b>#</b></font></td>
	<td align=center><font face=verdana size=2><b>To</b></font></td>
	<td align=center><font face=verdana size=2><b>Payment Details</b></font></td>
	<td align=center><font face=verdana size=2><b>Amount</b></font></td>
	<td align=center><font face=verdana size=2><b>Matrix</b></font></td>
	<td align=center><font face=verdana size=2><b>Date</b></font></td>
	<td align=center><font face=verdana size=2><b>Approval Date</b></font></td>
	</tr>");
	$rc=0;
    while($rss=mysql_fetch_row($wrs))
    {
	$rc++;
$rsm=mysql_query("select ID,Name,fee from membershiplevels where ID=$rss[6]");
$arrm=mysql_fetch_array($rsm);
if($rss[2]=="admin") $rss[2]="sukhminder";
      echo("<tr><td align=center><font face=verdana size=2>".$rc."</font></td>
	  <Td align=center><font face=verdana size=2>". $rss[2]."</font></td>
	  <Td align=center><font face=verdana size=2>$rss[3] ( $rss[4] )</font></td>
	  <Td align=center><font face=verdana size=2>$". $rss[5]." </font></td>
	  <Td align=center><font face=verdana size=2>$arrm[1] ( $$arrm[2] )<br>( ID: $rss[7] )</font></td>
	  <Td align=center><font face=verdana size=2>". $rss[9]." </font></td>
	  <Td align=center><font face=verdana size=2>$rss[10]</font></td>
	  </tr>");
    }
    echo("</table>");
    }
    else {
	echo "<br><b>No Records Found</b><br>";
    }
?>
</td></tr></table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php   return 1;
} include "footer.php";
?>