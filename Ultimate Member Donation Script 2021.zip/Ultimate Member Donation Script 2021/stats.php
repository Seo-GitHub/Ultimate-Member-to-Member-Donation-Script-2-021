<?php
  session_start();

include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
  middle();
}

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$check=1;
	$email=$arr[7];
        $name=$arr[1];
	$ref=$arr[11];
	$username=$_SESSION[username_session];
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
	}
	else {
		$statust="Pro";
	}
	$total=$arr[15];
	$paid=$arr[17];
	$unpaid=$arr[16];


?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Stats</b></font></p>
<br>
		<div align="center">
		<table border="0" cellpadding="3" cellspacing="0" width="450">
		      <tr> 
		        <td colspan="2"><b>
		         <hr><font face="Verdana, Arial, Helvetica, sans-serif" size="-1"><center>&nbsp;Account Details for <?php echo $name;?></font></center></b><hr>
		        </td>
		      </tr>
		      <tr> 
		        <td valign="center" align="left"><strong><font face="Verdana" size="-1">Total Amount Earned: </font></strong><br></td>
		        <td valign="center"> <font face="Verdana" size="-1">$<?php echo $total;?></font><br></td>
		      </tr>
		      <tr> 
		        <td valign="center" align="left"><strong><font face="Verdana" size="-1">Total Positions: </font></strong><br></td>
		        <td valign="center"> <font face="Verdana" size="-1"><?php 
$totalpos=0;
$rsm=mysql_query("select ID from membershiplevels order by ID");
while($arrm=mysql_fetch_array($rsm)) {
$rsm1=mysql_query("select ID from matrix$arrm[0] where Username='$username'");
$totalpos=$totalpos+mysql_num_rows($rsm1);
}
 echo $totalpos;?></font><br></td>
		      </tr>

		      <tr> 
		        <td valign="center" align="left"><strong><font face="Verdana" size="-1">Sponsor: </font></strong><br></td>
		        <td valign="center"> <font face="Verdana" size="-1"><?php 
$rs1=mysql_query("select * from users where active=1 and Username='$ref'");
if(mysql_num_rows($rs1)>0) {
$arr1=mysql_fetch_array($rs1);
echo "<a href=mailto:$arr1[7]>$arr1[1] (Username: $arr1[8])</a>";
}
else echo "No Sponsor";
?></font><br></td>
		      </tr>

		      <tr> 
		        <td valign="center" align="left"><strong><font face="Verdana" size="-1">Direct Referrals: </font></strong><br></td>
		        <td valign="center"> <font face="Verdana" size="-1"><?php 
$rs1=mysql_query("select Username from users where active=1 and ref_by='$username'");
 echo mysql_num_rows($rs1);
if(mysql_num_rows($rs1)>0) {
echo " ( <a href=viewdownlines.php>View Downlines</a>)";
}
?></font><br></td>
		      </tr>


	</table>
</td></tr></table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php }
include "footer.php";
?>