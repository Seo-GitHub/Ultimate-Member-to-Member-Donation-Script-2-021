<?php 
session_start();
include("config.php");
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n<title>";
echo $sitename;
echo " Admin Area</title>\r\n<body>\r\n";
if( !isset($_SESSION["ultmadmarea"]) ) 
{
    if( $_POST ) 
    {
        $a = $_POST["u"];
        $b = $_POST["pa"];
    }
    else
    {
        $a = "";
    }

    if( $a == "" || $b == "" ) 
    {
        echo "<form action=admin.php method=post><center><br><font face=verdana size=2>Username:</font><input type=text name='u' size=15><br><font face=verdana size=2>Password:</font><input type=password name='pa' size=15><br><br><input type=Submit value=Login></form>";
    }
    else
    {
        if( $a == $adminuser && $b == $adminpass ) 
        {
            $_SESSION["ultmadmarea"] = $adminpass;
            process();
        }
        else
        {
            echo "<form action=admin.php method=post><center><font face=verdana size=2><b>Invalid Username or Password</b></font><br><br><br><font face=verdana size=2>Username:</font><input type=text name='u'  size=15><br><font face=verdana size=2>Password:</font><input type=password name='pa'   size=15><br><br><input type=Submit value=Login></form>";
        }

    }

}
else
{
    process();
}
function process()
{
    include("config.php");

    if( $freemember == 0 ) 
    {
        $mtext = "Pending Members";
    }
    else
    {
        $mtext = "Free Members";
    }

    echo "<table border=0 width='100%' cellpadding=0 cellspacing=0><tr><td align=left valign=top><br><a href=admin.php?b=200>Instructions</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=100>Admin Settings</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=101>Edit your Pages</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=79>Matrices</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=1>Members List</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
    echo "" . "<a href=admin.php?b=21>" . $mtext . "</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
    echo "<a href=admin.php?b=22>Pro Members</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=201>Pending Members</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=2>Search Members</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=99>Top Sponsors</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=3>Email Users</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
    $rsm = mysql_query("select ID,Name from membershiplevels order by ID");
    while( $arrm = mysql_fetch_array($rsm) ) 
    {
        echo "" . "<a href=admin.php?b=5&mid=" . $arrm["0"] . ">" . $arrm["1"] . "</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
    }
    echo "<a href=admin.php?b=74>Pending Gifts</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=75>Approved Gifts</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=777>Promotional Banners</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=778>Promotional Solo Ads</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=210>Add Banner</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=211>Approved Banners</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=212>Pending Banners</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=310>Add TextAd</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=311>Approved Text Ads</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=312>Pending Text Ads</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=9111>Approved Testimonials</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=9112>Pending Testimonials</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=admin.php?b=199>Logout</a>&nbsp;&nbsp;|&nbsp;&nbsp;<br><br>";
    $today = date("Y-m-d H:i:s", mktime(date("H"), date("i"), date("s"), date("m"), date("d"), date("Y")));
    $last3days = date("Y-m-d H:i:s", mktime(date("H"), date("i"), date("s"), date("m"), date("d") - 3, date("Y")));
    $sql = "select count(*) from users where active=1 and status=1";
    $result = mysql_query($sql);
    $rs = mysql_fetch_row($result);
    $sql1 = "select count(*) from users where active=1 and status=2";
    $result1 = mysql_query($sql1);
    $rs1 = mysql_fetch_row($result1);
    $sqlpp1 = "select count(*) from users where active=0";
    $resultpp1 = mysql_query($sqlpp1);
    $rspp1 = mysql_fetch_row($resultpp1);
    $sql5 = "select sum(Amount) from wtransaction where approved=0";
    $result5 = mysql_query($sql5);
    $rs5 = mysql_fetch_row($result5);
    $sql6 = "select sum(Amount) from wtransaction where approved=1";
    $result6 = mysql_query($sql6);
    $rs6 = mysql_fetch_row($result6);
    $sqlc1 = "select count(*) from banners";
    $resultc1 = mysql_query($sqlc1);
    $rsc1 = mysql_fetch_row($resultc1);
    $sqlc2 = "select count(*) from soloads";
    $resultc2 = mysql_query($sqlc2);
    $rsc2 = mysql_fetch_row($resultc2);
    $sqlb1 = "select * from membersbanners where approved=1";
    $resultb1 = mysql_query($sqlb1);
    $rsb1 = mysql_num_rows($resultb1);
    $sqlb2 = "select * from membersbanners where approved=0";
    $resultb2 = mysql_query($sqlb2);
    $rsb2 = mysql_num_rows($resultb2);
    $sqlb44 = "select count(*) from memberstextads where approved=0";
    $resultb44 = mysql_query($sqlb44);
    $rsb44 = mysql_fetch_array($resultb44);
    $sqlb55 = "select count(*) from memberstextads where approved=1";
    $resultb55 = mysql_query($sqlb55);
    $rsb55 = mysql_fetch_array($resultb55);
    $rstt = mysql_query("Select * from testimonials where status>0");
    $rstt1 = mysql_query("Select * from testimonials where status=0");
    $sqlpt = "select count(*) from transaction";
    $resultpt = mysql_query($sqlpt);
    $rspt = mysql_fetch_row($resultpt);
    $sqlb44g = "select count(*) from gifts where approved=0";
    $resultb44g = mysql_query($sqlb44g);
    $rsb44g = mysql_fetch_array($resultb44g);
    $sqlb55g = "select count(*) from gifts where approved=1";
    $resultb55g = mysql_query($sqlb55g);
    $rsb55g = mysql_fetch_array($resultb55g);
    echo "Total Members: <SMALL><font color=red>" . ($rs[0] + $rs1[0] + $rspp1[0]) . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "" . $mtext . ": <SMALL><font color=red>" . $rs[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Pro Members: <SMALL><font color=red>" . $rs1[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Pending Members: <SMALL><font color=red>" . $rspp1[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    $sqlbl2m = "select * from membershiplevels";
    $resultbl2m = mysql_query($sqlbl2m);
    $rsbl2m = mysql_num_rows($resultbl2m);
    echo "Membership Levels: <SMALL><font color=red>" . $rsbl2m . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    $totalm = 0;
    $rsm = mysql_query("select * from membershiplevels order by ID");
    while( $arrm = mysql_fetch_array($rsm) ) 
    {
        $sql = "" . "select count(*) from matrix" . $arrm["0"];
        $result = mysql_query($sql);
        $rs = mysql_fetch_row($result);
        echo "" . $arrm["1"] . ": <SMALL><font color=red>" . $rs[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        $totalm = $totalm + $rs[0];
    }
    echo "" . "Paid Money: <SMALL><font color=red>\$" . number_format($rs6[0], 2) . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "" . "Pending Withdrawls: <SMALL><font color=red>\$" . number_format($rs5[0], 2) . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Approved Testimonials: <SMALL><font color=red>" . mysql_num_rows($rstt) . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Pending Testimonials: <SMALL><font color=red>" . mysql_num_rows($rstt1) . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Approved Gifts: <SMALL><font color=red>" . $rsb55g[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Pending Gifts: <SMALL><font color=red>" . $rsb44g[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Promotional Banners: <SMALL><font color=red>" . $rsc1[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Promotional SoloAds: <SMALL><font color=red>" . $rsc2[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Approved Banners: <SMALL><font color=red>" . $rsb1 . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Pending Banners: <SMALL><font color=red>" . $rsb2 . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Approved Text Ads: <SMALL><font color=red>" . $rsb55[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "Pending Text Ads: <SMALL><font color=red>" . $rsb44[0] . "</font></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    echo "<hr></td></tr><tr><td align=left valign=top>";
    $p = $_GET[p];
    $b = $_GET[b];
    if( !$b ) 
    {
        $b = $_POST[b];
    }

    $id = $_POST[id];
    $act = $_GET[act];
    $edit = $_POST[edit];
    if( $b == "100" ) 
    {
        echo "<h3 align=center>Admin Settings</h3>";
        if( !$_POST ) 
        {
            $sql = "select * from adminsettings";
            $result = mysql_query($sql);
            $rs = mysql_fetch_array($result);
            $sqlb = "select * from badminsettings";
            $resultb = mysql_query($sqlb);
            $rsb = mysql_fetch_array($resultb);
            $sqlt = "select * from tadminsettings";
            $resultt = mysql_query($sqlt);
            $rst = mysql_fetch_array($resultt);
            echo "<table><br><form action='admin.php?b=100' method=post><input type=hidden name=id value=" . $id . "><input type=hidden name=edit value=1>";
            echo "<tr><td colspan=2><h3><center>Update Information</h3></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Site Name</font></td><td width=600><input type=text name=asitename value='" . $rs[0] . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Site Url<br>like this http://www.abc.com</font></td><td width=600><input type=text name=asiteurl value='" . $rs[1] . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Admin Email Address</font></td><td width=600><input type=text name=aemail value='" . $rs[2] . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Admin Section Username</font></td><td width=600><input type=text name=ausername value='" . $rs[3] . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Admin Section Password</font></td><td width=600><input type=text name=apassword value='" . $rs[4] . "'></td></tr>";
            echo "<tr><Td colspan=2><p>&nbsp;</p></td></tr><tr><Td colspan=2><font face=verdana size=2>Enter your payment processors Details below, if you don't want to use any of these payment processors then just use 0 for that.</font></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Payza Email Address</font></td><td width=600><input type=text name=alertpay value='" . $rs[9] . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Egopay Email Address</font></td><td width=600><input type=text name=egopayid value='" . $egop[0] . "'></td></tr>";
            echo "<Tr><td colspan=2><font face=verdana size=2>Enter the number of extra merchants accounts that you want to use from 0 to 5</font></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Extra Merchants</font></td><td width=600><input type=text name=emerchants value='" . $rs[47] . "'></td></tr>";
            echo "<Tr><td colspan=2><font face=verdana size=2>Enter the merchant Name and payment id like if you are using SolidTrustPay in merchant name then enter your SolidTrustPay username in Merchant ID.</td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>1st Merchant Name</font></td><td width=600><input type=text name=mn1 value='" . stripslashes($rs[48]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>1st Merchant ID</font></td><td width=600><input type=text name=mc1 value='" . stripslashes($rs[49]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>2nd Merchant Name</font></td><td width=600><input type=text name=mn2 value='" . stripslashes($rs[50]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>2nd Merchant ID</font></td><td width=600><input type=text name=mc2 value='" . stripslashes($rs[51]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>3rd Merchant Name</font></td><td width=600><input type=text name=mn3 value='" . stripslashes($rs[52]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>3rd Merchant ID</font></td><td width=600><input type=text name=mc3 value='" . stripslashes($rs[53]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>4th Merchant Name</font></td><td width=600><input type=text name=mn4 value='" . stripslashes($rs[54]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>4th Merchant ID</font></td><td width=600><input type=text name=mc4 value='" . stripslashes($rs[55]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>5th Merchant Name</font></td><td width=600><input type=text name=mn5 value='" . stripslashes($rs[56]) . "'></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>5th Merchant ID</font></td><td width=600><input type=text name=mc5 value='" . stripslashes($rs[57]) . "'></td></tr>";
            echo "<tr><Td colspan=2><p>&nbsp;</p></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Auto Approve Purchase requests after:</font></td><td width=600><input type=text name=autoapprovaldays value='" . $rs[68] . "'> days</td></tr>";
            echo "<Tr><td colspan=2>&nbsp;  </td></tr><Tr><td colspan=2><font face=verdana size=2>You want to allow members to purchase 1st position from which matrix?</font></td></tr><tr><Td width=300><font face=verdana size=2>Starting Matrix Position</font></td><td width=600><select name=startmatrix>";
            if( $rs[12] == 0 ) 
            {
                echo "<option value=0 selected>Any Matrix</option>";
            }
            else
            {
                echo "<option value=0>Any Matrix</option>";
            }

            $rsm = mysql_query("select * from membershiplevels order by ID");
            while( $arrm = mysql_fetch_array($rsm) ) 
            {
                if( $arrm[0] == $rs[12] ) 
                {
                    echo "" . "<option value=" . $arrm["0"] . " selected>" . $arrm["1"] . "</option>";
                }
                else
                {
                    echo "" . "<option value=" . $arrm["0"] . ">" . $arrm["1"] . "</option>";
                }

            }
            echo "</select></td></tr><Tr><td colspan=2>&nbsp;  </td></tr><Tr><td colspan=2><font face=verdana size=2>Do you want to allow members to purchase more than 1 position in any matrix?</font></td></tr><tr><Td width=300><font face=verdana size=2>Multiple Purchase Allowed?</font></td><td width=600><select name=multipurchaseallowed>";
            if( $rs[14] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[14] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>Maximum positions a member can own in any particular matrix.</font></td><td width=600><input type=text name=maxposperlevel value='" . $rs[15] . "'></td></tr>";
            echo "<Tr><td colspan=2><font face=verdana size=2>Do you want to allow members to purchase positions in higher matrix without cycling and reaching that level?</td></tr><tr><Td width=300><font face=verdana size=2>Allow purchasing position in higher matrix</font></td><td width=600><select name=pospurnextlevel>";
            if( $rs[65] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[65] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><Tr><td colspan=2><font face=verdana size=2>Signup Details settings: You can show/hide these fields from join page.</font></td></tr><tr><Td width=300><font face=verdana size=2>Show Address field</font></td><td width=600><select name=showaddress>";
            if( $rs[16] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[16] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><tr><Td width=300><font face=verdana size=2>Show City field</font></td><td width=600><select name=showcity>";
            if( $rs[17] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[17] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><tr><Td width=300><font face=verdana size=2>Show State field</font></td><td width=600><select name=showstate>";
            if( $rs[18] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[18] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><tr><Td width=300><font face=verdana size=2>Show Postal Code/Zip field</font></td><td width=600><select name=showzip>";
            if( $rs[19] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[19] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><tr><Td width=300><font face=verdana size=2>Show Country field</font></td><td width=600><select name=showcountry>";
            if( $rs[20] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[20] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><tr><Td colspan=2><p>&nbsp;</p></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2><a href=http://www.yourfreeworld.com/script/affiliate.php target=_blank>YourFreeWorld.com Scripts Affiliate ID</a></font></td><td width=600><input type=text name=yfwid value='" . $rs[21] . "'></td></tr>";
            echo "<tr><Td colspan=2><p>&nbsp;</p></td></tr><Tr><td colspan=2><font face=verdana size=2>Enter your banners settings:</font></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>No. of banners to be shown at bottom of each page:</font></td><td width=600><input type=text name=showban value='" . $rsb[1] . "'></td></tr>";
            echo "<Tr><td colspan=2><font face=verdana size=2>Enter your Text Ads settings:</font></td></tr>";
            echo "<tr><Td width=300><font face=verdana size=2>No. of Text Ads to be shown at top of each page:</font></td><td width=600><input type=text name=nads value='" . $rst[1] . "'></td></tr>";
            echo "<tr><Td colspan=2><p>&nbsp;</p></td></tr><Tr><td colspan=2><font face=verdana size=2>If you want to send a confirmation email to verify the user email address in order to avoid non working or invalid email address then select <b>Yes</b> in Email Confirmation Required option otherwise select <b>No</b>.</font></td></tr><tr><Td width=300><font face=verdana size=2>Email Confirmation Required?</font></td><td width=600><select name=confirmreq>";
            if( $rs[22] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[22] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr><Tr><td colspan=2><font face=verdana size=2>If you want to send an email to sponsor to notify them that they have got a new signup or there referral has upgraded then select <b>Yes</b> in Send Referral Notification Email option otherwise select <b>No</b>.</font></td></tr><tr><Td width=300><font face=verdana size=2>Send Referral Notification Email</font></td><td width=600><select name=refnotification>";
            if( $rs[23] == 0 ) 
            {
                echo "<option value=0 selected>No</option>\r\n        <option value=1>Yes</option>";
            }
            else
            {
                if( $rs[23] == 1 ) 
                {
                    echo "<option value=0>No</option>\r\n        <option value=1 selected>Yes</option>";
                }

            }

            echo "</select></td></tr>";
            echo "" . "<Tr><td colspan=2><font face=verdana size=2>Change the email contents if you wants.<br><br>\r\nYou can use the following tags for personalized mailing and these will automatically get replaced by user information.<br><br>\r\n{name} for Name of the member<br>\r\n{username} for username of the member<br>\r\n{password} for the password of the member<br>\r\n{email} for the Email Address of the member<br>\r\n{sitename} for your sitename like " . $sitename . "<br>\r\n{siteurl} for your website url like " . $siteurl . "<br><br>\r\nNote: If you are using <b>Email Format</b> as <b>HTML</b> then you need to type the complete message in HTML format only.</font></td></tr>";
            echo "<tr><Td colspan=2><font face=verdana size=2>Confirmation Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject1 value=\"" . stripslashes($subject1) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat1>";
            if( $eformat1 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message1 cols=60 rows=10>" . stripslashes($message1) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>Please don't remove {validationurl} tag from the above email otherwise as it is used to show the validation link in confirmation email.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Free Members Account Activation Email.<br>If you are using only Pro Membership then this email is sent when someone validate the email address and is supposed to make the payment:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject2 value=\"" . stripslashes($subject2) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat2>";
            if( $eformat2 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message2 cols=60 rows=10>" . stripslashes($message2) . "</textarea></td></tr>";
            echo "</table></td></tr><tr><Td colspan=2><font face=verdana size=2>Referral Notification Email to sponsor when downline member activates the free account:<br>\r\nYou can use the following tags for showing the referred member details to sponsor.<br><br>\r\n{refname} for Referred Member Name<br>\r\n{refusername} for Referred Member Username<br>\r\n{refemail} for the Referred Member Email Address<br></font>\r\n<table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject3 value=\"" . stripslashes($subject3) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat3>";
            if( $eformat3 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message3 cols=60 rows=10>" . stripslashes($message3) . "</textarea></td></tr>";
            echo "</table></td></tr><tr><Td colspan=2><font face=verdana size=2>Password Reminder Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject5 value=\"" . stripslashes($subject5) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat5>";
            if( $eformat5 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message5 cols=60 rows=10>" . stripslashes($message5) . "</textarea></td></tr>";
            echo "</table></td></tr><tr><Td colspan=2><font face=verdana size=2>Banner Ad Approval Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject6 value=\"" . stripslashes($subject6) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat6>";
            if( $eformat6 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message6 cols=60 rows=10>" . stripslashes($message6) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{banner} and {websiteurl} tags can be used to show the banner ad and website url submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Banner Ad Rejection Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject7 value=\"" . stripslashes($subject7) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat7>";
            if( $eformat7 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message7 cols=60 rows=10>" . stripslashes($message7) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{banner} and {websiteurl} tags can be used to show the banner ad and website url submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Text Ad Approval Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject8 value=\"" . stripslashes($subject8) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat8>";
            if( $eformat8 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message8 cols=60 rows=10>" . stripslashes($message8) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{textad} and {websiteurl} tags can be used to show the textad and website url submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Text Ad Rejection Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject9 value=\"" . stripslashes($subject9) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat9>";
            if( $eformat9 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message9 cols=60 rows=10>" . stripslashes($message9) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{textad} and {websiteurl} tags can be used to show the textad and website url submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Member Pending Payment Received Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject10 value=\"" . stripslashes($subject10) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat10>";
            if( $eformat10 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message10 cols=60 rows=10>" . stripslashes($message10) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{amount} and {pmode} tags can be used to show the amount and payment mode submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Member Payment Auto Approval Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject11 value=\"" . stripslashes($subject11) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat11>";
            if( $eformat11 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message11 cols=60 rows=10>" . stripslashes($message11) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{amount} and {pmode} tags can be used to show the amount and payment mode submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Member Initiating the payment:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject12 value=\"" . stripslashes($subject12) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat12>";
            if( $eformat12 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message12 cols=60 rows=10>" . stripslashes($message12) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{amount} and {pmode} tags can be used to show the amount and payment mode submitted by member.</font></td></tr><tr><Td colspan=2><font face=verdana size=2>Payment declined Email:</font><br><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Subject:</td><td align=left><input type=text name=subject13 value=\"" . stripslashes($subject13) . "\"></td></tr>";
            echo "<tr><Td align=right valign=top><font face=verdana size=2>Email Format:</font></td><td width=600><select name=eformat13>";
            if( $eformat13 == 1 ) 
            {
                echo "<option value=1 selected>Text</option>\r\n        <option value=2>HTML</option>";
            }
            else
            {
                echo "<option value=1>Text</option>\r\n        <option value=2 selected>HTML</option>";
            }

            echo "<tr><td align=right valign=top><font face=verdana size=2>Message:</td><td align=left><textarea name=message13 cols=60 rows=10>" . stripslashes($message13) . "</textarea></td></tr>";
            echo "</table><br><font face=verdana size=2><b>Note: </b>{amount} and {pmode} tags can be used to show the amount and payment mode submitted by member.</font></td></tr><Tr><td colspan=2><font face=verdana size=2>Bonus Page Details: You can use html tags here.</font></td></tr><tr><Td colspan=2><table border=0>";
            echo "<tr><td align=right valign=top><font face=verdana size=2>Free Members Bonus:</font></td><td align=left><textarea name=freebonus cols=60 rows=10>" . stripslashes($freebonus) . "</textarea></td></tr>";
            echo "</table></td></tr><tr><Td colspan=2><p>&nbsp;</p></td></tr><tr><td colspan=2><input type=Submit style='' color:#000000; font-size:10pt; font-family:Verdana; font-weight:bold; border:1px ridge #000000; background-color:#B0D8DD  value='Update Settings'></form></td></tr></table>";
        }
        else
        {
            $eg = $_POST[egopayid];
            $sql_u = "" . "update adminsettings set \r\n   sitename='" . $_POST["asitename"] . "',\r\n   siteurl='" . $_POST["asiteurl"] . "',\r\n   Email='" . $_POST["aemail"] . "',\r\n   Username='" . $_POST["ausername"] . "',\r\n   Password='" . $_POST["apassword"] . "',\r\n   topbanner='" . $_POST["topban"] . "',\r\n   bottombanner='" . $_POST["botban"] . "',\r\n   Ebullion='" . $eg . "',\r\n   Alertpay='" . $_POST["alertpay"] . "',\r\n   showaddress='" . $_POST["showaddress"] . "',\r\n   showcity='" . $_POST["showcity"] . "',\r\n   showstate='" . $_POST["showstate"] . "',\r\n   showzip='" . $_POST["showzip"] . "',\r\n   showcountry='" . $_POST["showcountry"] . "',\r\n   yfwid='" . $_POST["yfwid"] . "',\r\n   confirmreq='" . $_POST["confirmreq"] . "',\r\n   refnotification='" . $_POST["refnotification"] . "',\r\n   eformat1='" . $_POST["eformat1"] . "',\r\n   eformat2='" . $_POST["eformat2"] . "',\r\n   eformat3='" . $_POST["eformat3"] . "',\r\n   eformat5='" . $_POST["eformat5"] . "',\r\n   eformat6='" . $_POST["eformat6"] . "',\r\n   eformat7='" . $_POST["eformat7"] . "',\r\n   eformat8='" . $_POST["eformat8"] . "',\r\n   eformat9='" . $_POST["eformat9"] . "',\r\n   eformat10='" . $_POST["eformat10"] . "',\r\n   eformat11='" . $_POST["eformat11"] . "',\r\n   eformat12='" . $_POST["eformat12"] . "',\r\n   eformat13='" . $_POST["eformat13"] . "',\r\n   startmatrix='" . $_POST["startmatrix"] . "',\r\n   multipurchaseallowed='" . $_POST["multipurchaseallowed"] . "',\r\n   maxposperlevel='" . $_POST["maxposperlevel"] . "',\r\n   pospurnextlevel='" . $_POST["pospurnextlevel"] . "',\r\n   Merchants='" . $_POST["emerchants"] . "',\r\n   autoapprovaldays='" . $_POST["autoapprovaldays"] . "'\r\n";
            $rs = mysql_query($sql_u);
            $subject1 = addslashes($_POST[subject1]);
            mysql_query("" . "update adminsettings set Subject1='" . $subject1 . "'");
            $subject2 = addslashes($_POST[subject2]);
            mysql_query("" . "update adminsettings set Subject2='" . $subject2 . "'");
            $subject3 = addslashes($_POST[subject3]);
            mysql_query("" . "update adminsettings set Subject3='" . $subject3 . "'");
            $subject5 = addslashes($_POST[subject5]);
            mysql_query("" . "update adminsettings set Subject5='" . $subject5 . "'");
            $subject6 = addslashes($_POST[subject6]);
            mysql_query("" . "update adminsettings set Subject6='" . $subject6 . "'");
            $subject7 = addslashes($_POST[subject7]);
            mysql_query("" . "update adminsettings set Subject7='" . $subject7 . "'");
            $subject8 = addslashes($_POST[subject8]);
            mysql_query("" . "update adminsettings set Subject8='" . $subject8 . "'");
            $subject9 = addslashes($_POST[subject9]);
            mysql_query("" . "update adminsettings set Subject9='" . $subject9 . "'");
            $subject10 = addslashes($_POST[subject10]);
            mysql_query("" . "update adminsettings set Subject10='" . $subject10 . "'");
            $subject11 = addslashes($_POST[subject11]);
            mysql_query("" . "update adminsettings set Subject11='" . $subject11 . "'");
            $subject12 = addslashes($_POST[subject12]);
            mysql_query("" . "update adminsettings set Subject12='" . $subject12 . "'");
            $subject13 = addslashes($_POST[subject13]);
            mysql_query("" . "update adminsettings set Subject13='" . $subject13 . "'");
            $message1 = addslashes($_POST[message1]);
            mysql_query("" . "update adminsettings set Message1='" . $message1 . "'");
            $message2 = addslashes($_POST[message2]);
            mysql_query("" . "update adminsettings set Message2='" . $message2 . "'");
            $message3 = addslashes($_POST[message3]);
            mysql_query("" . "update adminsettings set Message3='" . $message3 . "'");
            $message5 = addslashes($_POST[message5]);
            mysql_query("" . "update adminsettings set Message5='" . $message5 . "'");
            $message6 = addslashes($_POST[message6]);
            mysql_query("" . "update adminsettings set Message6='" . $message6 . "'");
            $message7 = addslashes($_POST[message7]);
            mysql_query("" . "update adminsettings set Message7='" . $message7 . "'");
            $message8 = addslashes($_POST[message8]);
            mysql_query("" . "update adminsettings set Message8='" . $message8 . "'");
            $message9 = addslashes($_POST[message9]);
            mysql_query("" . "update adminsettings set Message9='" . $message9 . "'");
            $message10 = addslashes($_POST[message10]);
            mysql_query("" . "update adminsettings set Message10='" . $message10 . "'");
            $message11 = addslashes($_POST[message11]);
            mysql_query("" . "update adminsettings set Message11='" . $message11 . "'");
            $message12 = addslashes($_POST[message12]);
            mysql_query("" . "update adminsettings set Message12='" . $message12 . "'");
            $message13 = addslashes($_POST[message13]);
            mysql_query("" . "update adminsettings set Message13='" . $message13 . "'");
            $freebonus = addslashes($_POST[freebonus]);
            mysql_query("" . "update adminsettings set freebonus='" . $freebonus . "'");
            $mn1 = addslashes($_POST[mn1]);
            $mn2 = addslashes($_POST[mn2]);
            $mn3 = addslashes($_POST[mn3]);
            $mn4 = addslashes($_POST[mn4]);
            $mn5 = addslashes($_POST[mn5]);
            $mc1 = addslashes($_POST[mc1]);
            $mc2 = addslashes($_POST[mc2]);
            $mc3 = addslashes($_POST[mc3]);
            $mc4 = addslashes($_POST[mc4]);
            $mc5 = addslashes($_POST[mc5]);
            mysql_query("" . "update adminsettings set MerchantName1='" . $mn1 . "'");
            mysql_query("" . "update adminsettings set MerchantCode1='" . $mc1 . "'");
            mysql_query("" . "update adminsettings set MerchantName2='" . $mn2 . "'");
            mysql_query("" . "update adminsettings set MerchantCode2='" . $mc2 . "'");
            mysql_query("" . "update adminsettings set MerchantName3='" . $mn3 . "'");
            mysql_query("" . "update adminsettings set MerchantCode3='" . $mc3 . "'");
            mysql_query("" . "update adminsettings set MerchantName4='" . $mn4 . "'");
            mysql_query("" . "update adminsettings set MerchantCode4='" . $mc4 . "'");
            mysql_query("" . "update adminsettings set MerchantName5='" . $mn5 . "'");
            mysql_query("" . "update adminsettings set MerchantCode5='" . $mc5 . "'");
            $sql_u = "" . "update badminsettings set \r\n   showban='" . $_POST["showban"] . "'";
            $rs = mysql_query($sql_u);
            $sql_u = "" . "update tadminsettings set \r\n   nads='" . $_POST["nads"] . "'";
            $rs = mysql_query($sql_u);
            echo "<br><br><b>Records Successfully Updated</b><br><br>";
        }

    }
    else
    {
        if( $b == "steps" ) 
        {
            echo "<center>\r\n<table width=90%><tr><td>\r\n<font face=verdana size=2><br><br>\r\nVisit <a href='https://www.payza.com/' target=_blank>https://www.payza.com/</a>\r\n<br><br>\r\n1. Login to your Payza account. <br>\r\n2. Go to \"My Profile\"<br>\r\n3. Click \"Business Accounts\"<br>\r\n4. Click \"Add\"<br>\r\n5. Fill out the form using an email address relating to your site, such as sales@domain.com.<br>\r\n6. Under IPN Setup:<br>\r\na. Check \"Enable IPN\"<br>\r\nb. Set the Alert URL to:<br>\r\n";
            echo $siteurl;
            echo "/alertpayipn.php<br>\r\nc. Enter a security Code.<br>\r\n7. Submit the form.<br>\r\n8. After this business email is added, go back into it by clicking \"edit\"<br>\r\n9. Scroll down and copy the \"Encrypted Security Code\". <br>\r\n10. Login to your admin area and click on the Admin Settings link and enter the Encrypted Security Code.\r\n<br><br>\r\nAll finished... <br><br>\r\n\r\n</font>\r\n</td></tr></table></center>\r\n";
        }
        else
        {
            if( $b == "stepse" ) 
            {
                echo "<center>\r\n<table width=90%><tr><td>\r\n<font face=verdana size=2><br><br>\r\nVisit <a href='https://www.egopay.com/' target=_blank>https://www.egopay.com/</a>\r\n<br><br>\r\n1. Login to your Egopay account. <br>\r\n2. Click \"Merchant\"<br>\r\n3. Click \"Add new\" under Manage Websites<br>\r\n4. Click \"Stores\" and then click on \"Add new\" under Manage Stores<br>\r\n5. Fill out the form and enter Store Name and Set Success Url as:<br>\r\n";
                echo $siteurl;
                echo "/thanks.php<br>\r\nSet Fail Url as:<br>\r\n";
                echo $siteurl;
                echo "/<br>\r\nSet CallBack Url as:<br>\r\n";
                echo $siteurl;
                echo "/egopayipn.php<br>\r\nand leave \"Test Mode\" as unchecked.<br>\r\n6. Submit the form.<br>\r\n7. Click on Stores button again<br>\r\n8. Click on Information icon and enter the Store ID and Store Pass in your admin area -> Admin Settings link.\r\n<br><br>\r\nAll finished... <br><br>\r\n\r\n</font>\r\n</td></tr></table></center>\r\n";
            }
            else
            {
                if( $b == "9111" ) 
                {
                    $rs = mysql_query("select * from testimonials where status=1");
                    if( 0 < mysql_num_rows($rs) ) 
                    {
                        echo "<br><center><h3>Approved Testimonials</h3></center><table width=90% border=1 cellspacing=0 cellpadding=0><tr><Td width=15 align=center>ID</td><td width=90 align=center>Member</td><td width=450 align=center>Testimonial</td><td width=90 align=center>Date</td><td align=center valign=center>Action</td></tr>";
                        while( $arr = mysql_fetch_array($rs) ) 
                        {
                            echo "<tr><Td align=center>" . $arr[0] . "</td><Td align=center>" . $arr[1] . "</td><Td align=center><font face=verdana size=2>" . str_replace("\n", "<br>", $arr[2]) . "</td><Td align=center>" . $arr[4] . "</td><Td align=center>";
                            echo "<form action=admin.php method=post><input type=hidden name=id value=" . $arr[0] . ">&nbsp;<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"EditT\">&nbsp;<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"DeleteTestimonial\"></form></td></tr>";
                        }
                        echo "</table>";
                    }
                    else
                    {
                        echo "<br><center><br><b>No Pending Accounts Records Found !</b></center>";
                    }

                }
                else
                {
                    if( $b == "9112" ) 
                    {
                        $rs = mysql_query("select * from testimonials where status=0");
                        if( 0 < mysql_num_rows($rs) ) 
                        {
                            echo "<br><center><h3>Pending Testimonials</h3></center><table width=90% border=1 cellspacing=0 cellpadding=0><tr><Td width=15 align=center>ID</td><td width=90 align=center>Member</td><td width=450 align=center>Testimonial</td><td width=90 align=center>Date</td><td align=center valign=center>Action</td></tr>";
                            while( $arr = mysql_fetch_array($rs) ) 
                            {
                                echo "<tr><Td align=center>" . $arr[0] . "</td><Td align=center>" . $arr[1] . "</td><Td align=left><font face=verdana size=2>" . str_replace("\n", "<br>", $arr[2]) . "</td><Td align=center>" . $arr[4] . "</td><Td align=center>";
                                echo "<form action=admin.php method=post><input type=hidden name=id value=" . $arr[0] . "><input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"VerifyT\">&nbsp;<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"EditT\">&nbsp;<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"DeleteTestimonial\"></form></td></tr>";
                            }
                            echo "</table>";
                        }
                        else
                        {
                            echo "<br><center><br><b>No Pending Accounts Records Found !</b></center>";
                        }

                    }
                    else
                    {
                        if( $b == "EditT" ) 
                        {
                            if( $_POST["data"] != "" ) 
                            {
                                mysql_query("" . "update testimonials set data='" . $_POST["data"] . "' where ID=" . $_POST["id"]);
                                echo "<br><center><b>Record Successfully Updated</b><br></center>";
                            }

                            $rs = mysql_query("select * from testimonials where ID=" . $_POST["id"]);
                            echo "<br><center><h3>Modify Testimonial</h3></center><table width=90% border=1 cellspacing=0 cellpadding=0><tr><Td width=15 align=center>ID</td><td width=90 align=center>Member</td><td width=450 align=center>Testimonial</td><td width=90 align=center>Date</td><td align=center valign=center>Action</td></tr>";
                            while( $arr = mysql_fetch_array($rs) ) 
                            {
                                echo "<tr><form action=admin.php method=post><Td align=center>" . $arr[0] . "</td><Td align=center>" . $arr[1] . "</td><Td align=left><textarea name=data rows=10 cols=50>" . $arr[2] . "</textarea></td><Td align=center>" . $arr[4] . "</td><Td align=center>";
                                echo "<input type=hidden name=id value=" . $arr[0] . "><input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"EditT\">&nbsp;</form></td></tr>";
                            }
                            echo "</table>";
                        }
                        else
                        {
                            if( $b == "DeleteTestimonial" ) 
                            {
                                mysql_query("delete from testimonials where ID=" . $_POST["id"]);
                                echo "<br><b>Record Successfully Deleted";
                            }
                            else
                            {
                                if( $b == "VerifyT" ) 
                                {
                                    mysql_query("Update testimonials set status=1 where ID=" . $_POST["id"]);
                                    echo "<b>Record SuccessFully Updated!</b>";
                                }
                                else
                                {
                                    if( $b == "199" ) 
                                    {
                                        $_SESSION["ultmadmarea"] = "";
                                        session_destroy();
                                        echo "<script>\r\nlocation.href='admin.php';\r\n</script>\r\n";
                                    }
                                    else
                                    {
                                        if( $b == "101" ) 
                                        {
                                            $editt = $_POST[editt];
                                            $edit = $_POST[edit];
                                            $idpage = $_POST[idpage];
                                            echo "<h3 align=center>Edit your Pages</h3>";
                                            if( $edit != 1 ) 
                                            {
                                                $sql = "select * from pages order by PName";
                                                $result = mysql_query($sql);
                                                echo "<div align=center><br><form action='admin.php?b=101' method=post><input type=hidden name=edit value=1>      Name of the page: <select name=idpage>\r\n       ";
                                                while( $p = mysql_fetch_array($result) ) 
                                                {
                                                    echo "\t <option value=\"";
                                                    echo $p[0];
                                                    echo "\">";
                                                    echo $p[1];
                                                    echo "</option>\r\n\t ";
                                                }
                                                echo " </select><br>\r\n     <input type=Submit style='' color:#000000; font-size:10pt; font-family:Verdana; font-weight:bold; border:1px ridge #000000; background-color:#B0D8DD  value='Edit Page'></form></div><br><br>";
                                            }
                                            else
                                            {
                                                if( $editt != 1 ) 
                                                {
                                                    $qry = "" . "select * from pages where ID = " . $_POST["idpage"];
                                                    $npag = mysql_query($qry) or exit( "Error" . mysql_error() . $qry );
                                                    $np = mysql_fetch_array($npag);
                                                    $np[2] = str_replace("</textarea>", "&lt;/textarea&gt", $np[2]);
                                                    $np[2] = str_replace("<textarea", "&lt;textarea", $np[2]);
                                                    echo "\r\n<div align=\"center\"><form method=\"POST\" action=\"admin.php?b=101\">\r\n<table><tr><td><font face=verdana size=2>Page Name:</font></td><td><font face=verdana size=2>";
                                                    echo $np[1];
                                                    echo "</font></td></tr>\r\n<tr><td><font face=verdana size=2>Page Contents:</font></td>\r\n<td><input type=hidden name=edit value=1>\r\n<input type=hidden name=editt value=1>\r\n<input type=\"hidden\" name=\"id\" value=\"";
                                                    echo $_POST[idpage];
                                                    echo "\">\r\n<TEXTAREA NAME=\"desc\" rows=15 cols=60>";
                                                    echo stripslashes($np[2]);
                                                    echo "</TEXTAREA></td></tr>\r\n<tr><td colspan=2><input type=submit value=\"Save Page\"></td></tr>\r\n</table>\r\n        </form>\r\n</div>\r\n\r\n   ";
                                                }
                                                else
                                                {
                                                    $descc = addslashes($_POST[desc]);
                                                    mysql_query("" . "update pages set pagedesc='" . $descc . "' where ID=" . $_POST["id"]) or exit( "Error:  " . mysql_error() );
                                                    echo "<br><br><b>Page Successfully Updated</b><br><br>";
                                                }

                                            }

                                        }
                                        else
                                        {
                                            if( $b == "777" ) 
                                            {
                                                print "<h3 align=center>Promotional Banners</h3><br><center>\r\n<br><font face=verdana size=2><b>Add a Banner that you want to show at 'Promotional Center' inside members area so that members can use it for promoting your site.</b>\r\n<br><form action=admin.php method=post>\r\n<b>Banner Url:</b><input type=text name=burl size=45 value='http://www.yoursitename.com/images/banner1.gif'> <input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"Add Banner\"></form><br></center>";
                                                $rs = mysql_query("select * from banners order by ID");
                                                print "<center><br><b>View Banners</b><br>";
                                                print "<table border=1 cellspacing=1 cellpadding=1><tr><td align=center><font face-verdana size=2><b>ID</b></font></td><td align=center><font face-verdana size=2><b>Banner</b></font></td><td align=center><font face-verdana size=2><b>Date</b></font></td><td align=center><font face-verdana size=2><b>Action</b></font></td></tr>";
                                                while( $arr = mysql_fetch_array($rs) ) 
                                                {
                                                    print "" . "<tr><Td align=center><font face=verdana size=2>" . $arr["0"] . "</font></td><Td align=center><font face=verdana size=2><img src='" . $arr["1"] . "'><br>" . $arr["1"] . "</font></td><Td align=center><font face=verdana size=2>" . $arr["2"] . "</font></td><Td align=center>";
                                                    print "<form action=admin.php method=post><input type=hidden name=id value=" . $arr[0] . ">&nbsp;<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"DeleteB\"></form></td></tr>";
                                                }
                                                print "</table></center>";
                                            }
                                            else
                                            {
                                                if( $b == "Add Banner" ) 
                                                {
                                                    $rs = mysql_query("" . "insert into banners(BannerURL,Date) values('" . $_POST["burl"] . "',now())");
                                                    print "<b><br>Record SuccessFully Added</b><br>";
                                                }
                                                else
                                                {
                                                    if( $b == "DeleteB" ) 
                                                    {
                                                        $rs = mysql_query("delete from banners where ID=" . $_POST["id"]);
                                                        print "<br><b>Record Successfully Deleted</b><br>";
                                                    }
                                                    else
                                                    {
                                                        if( $b == "778" ) 
                                                        {
                                                            print "<h3 align=center>Promotional SoloAds</h3><br>\r\n<br><font face=verdana size=2><b>Add a Solo Ad that you want to show at 'Promotional Center' inside members area so that members can use it for promoting your site.</b><br>\r\nYou can use the following tags for personalized Solo Ads and these will automatically get replaced by user information.<br><br>\r\n{name} for Name of the member<br>\r\n{username} for username of the member<br>\r\n{refurl} for the Referral Url of the member<br>\r\n\r\n<br><form action=admin.php method=post>\r\n<b>Subject:</b><input type=text name=subject size=35 value=''><br>\r\n<b>Message:</b><textarea name=message rows=10 cols=60></textarea><br>\r\n<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"Add SoloAd\"></form><br>";
                                                            $rs = mysql_query("select * from soloads order by ID");
                                                            print "<center><br><b>View Solo Ads</b><br>";
                                                            print "<table border=1 cellspacing=1 cellpadding=1><tr><td align=center><font face-verdana size=2><b>ID</b></font></td><td align=center width=500><font face-verdana size=2><b>Solo Ad</b></font></td><td align=center><font face-verdana size=2><b>Date</b></font></td><td align=center><font face-verdana size=2><b>Action</b></font></td></tr>";
                                                            while( $arr = mysql_fetch_array($rs) ) 
                                                            {
                                                                stripslashes($arr[1]);
                                                                stripslashes(str_replace("\n", "<br>", $arr[2]));
                                                                print "" . "<tr><Td align=center><font face=verdana size=2>" . $arr["0"] . "</font></td><Td align=center><font face=verdana size=2>Subject: " . stripslashes($arr[1]) . "\r\n<br>Message:<br>" . stripslashes(str_replace("\n", "<br>", $arr[2])) . "" . "</font></td><Td align=center><font face=verdana size=2>" . $arr["3"] . "</font></td><Td align=center>";
                                                                print "<form action=admin.php method=post><input type=hidden name=id value=" . $arr[0] . ">&nbsp;<input type=Submit style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"DeleteS\"></form></td></tr>";
                                                            }
                                                            print "</table></center>";
                                                        }
                                                        else
                                                        {
                                                            if( $b == "Add SoloAd" ) 
                                                            {
                                                                if( $_POST[subject] == "" ) 
                                                                {
                                                                    echo "<br><b>Subject can't be blank</b><br>";
                                                                }
                                                                else
                                                                {
                                                                    if( $_POST[message] == "" ) 
                                                                    {
                                                                        echo "<br><b>Message can't be blank</b><br>";
                                                                    }
                                                                    else
                                                                    {
                                                                        $subject = addslashes($_POST[subject]);
                                                                        $message = addslashes($_POST[message]);
                                                                        mysql_query("" . "insert into soloads(Subject,Message,Date) values('" . $subject . "','" . $message . "',now())");
                                                                        print "<b><br>Record SuccessFully Added</b><br>";
                                                                    }

                                                                }

                                                            }
                                                            else
                                                            {
                                                                if( $b == "DeleteS" ) 
                                                                {
                                                                    mysql_query("delete from soloads where ID=" . $_POST["id"]);
                                                                    print "<br><b>Record Successfully Deleted</b><br>";
                                                                }
                                                                else
                                                                {
                                                                    if( $b == "200" ) 
                                                                    {
                                                                        echo "<p>&nbsp;</p>\r\n<p><b><font face=\"Verdana\" size=\"2\">These notes will help you to \r\nbegin to understand how your Site works. </font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Please read through these \r\nnotes for any questions you may have in regards to any features in the admin \r\narea.</font></b></p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Admin Settings&nbsp; **</font></b></p>\r\n<p><font size=\"2\" face=\"Verdana\"><b>Here is where you decide how your program will be run. </font></b>\r\n</p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Edit your Pages&nbsp; **</font></b></p>\r\n<p><b><font size=\"2\" face=\"Verdana\">Here you can update the contents of your Home Page, FAQ Page, Login Page and Logout Page. </font>\r\n</b>\r\n</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Matrices&nbsp; **</font></b></p>\r\n<p><font size=\"2\" face=\"Verdana\"><b>Here you can create/edit/delete the matrices that you wants to use for your system. </font></b>\r\n</p>\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Members List/Search Members&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">From here you can view/edit/delete the members records.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Free Members/Pro Members/Pending Members&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">From here you can view/edit/delete the members of a particular category who is at free membership status or pro membership status or pending membership status.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Top Sponsors&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Here you can find the list of top 100 members who have referred maximum number of members to your site.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Email Users&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Use this section for updating your Members \r\n about information on your Downline Builder.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Matrix Details&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Here you can see all the Positions purchased by your members in all the matices.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Pending Transactions&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Use this section to check all the transactions which are pending either due to non payment or non payza transactions which requires admin approval.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Pending Gifts&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Use this section to check all the gift requests created which are waiting for the approve by there sponsor or admin. Please remember to check this section often so that you can approve the gifts which has been paid and removed the one who have submitted the payment transaction details but hadn't paid yet.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Approved Gifts&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Here you can see the list of all approved gifts.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Promotional Banners&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Here you can add/view/delete the banners that you wants to provide to your members for promoting your site with there referral url.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Promotional Solo Ads&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">Here you can add/view/delete the solo ads that you wants to provide to your members for promoting your site with there referral url.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Add banners&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section will allow you to submit your own banners for rotation in the system.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Approved banners&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section lets you track the banners submitted by members and you can track the details of each banner.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Pending banners&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section will show you the list of all the pending banner and you can approve them after checking the contents.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Add TextAds&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section will allow you to submit your own Text Ads for rotation in the system.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Approved Text Ads&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section lets you track the Text Ads submitted by members and you can track the details of each Text Ad.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Pending Text Ads&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section will show you the list of all the pending Text Ad and you can approve them after checking the contents.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Approved Testimonials&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section lets you track the Testimonials submitted by members.</font></b></p>\r\n<p>&nbsp;</p>\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; Pending Testimonials&nbsp; **</font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">This section will show you the list of all the pending Testimonials submitted by members and you can approve them after checking the contents.</font></b></p>\r\n<p>&nbsp;</p>\r\n\r\n<p><b><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">**&nbsp; If you want to show members textads at your other websites or pages then you can use the code provided below:&nbsp; **</font></b></p>\r\n<p><font size=\"2\" face=\"Verdana\"><b>\r\nTo show text ads in a horizontal ad box then just copy and paste the below code on any page where you want text ads to appear.<br>\r\n<textarea rows=2 cols=90>\r\n<script src=\"";
                                                                        echo $siteurl;
                                                                        echo "/hortextads.php\"></script>\t\r\n</textarea>\r\n<br><br>\r\nTo show text ads in a vertical ad box then just copy and paste the below code on any page where you want text ads to appear.<br>\r\n<textarea rows=2 cols=90>\r\n<script src=\"";
                                                                        echo $siteurl;
                                                                        echo "/vertextads.php\"></script>\t\r\n</textarea>\r\n\r\n </font></b>\r\n</p>\r\n\r\n\r\n<p><b><font face=\"Verdana\" size=\"2\">However Please remember we \r\nare always here to help you with anything that you may not understand or need \r\nclarification on.&nbsp; So please never hesitate to </font><font face=\"Verdana\" size=\"2\" color=\"#FF0000\"> <a href=\"http://www.yourfreeworld.com/script/contactus.php\" target=_blank>contact us</a></font><font face=\"Verdana\" size=\"2\">.</font><font face=\"Verdana\" size=\"2\" color=\"#FF0000\">&nbsp; </font></b></p>\r\n<p><b><font face=\"Verdana\" size=\"2\">\r\nWishing for your success<br>\r\nRohit Seth<br>\r\n<a href=http://www.yourfreeworld.com/script target=_blank>http://www.yourfreeworld.com/script</a></font>\r\n<br><br><font size=\"2\" face=\"Verdana\" color=\"#FF0000\">\r\nYou can Add Value To Your Existing Business and Attract More Visitors To Your Site by offering quality inclusions products as bonus.<br>\r\nGain Instant Access To Over 1000+ Master Resale Rights products for less than \$15<br>\r\n<a href='http://www.masterresalerightsclub.com/' target=_blank>http://www.masterresalerightsclub.com/</a><br>\r\n</font></b></p>\r\n";
                                                                    }
                                                                    else
                                                                    {
                                                                        if( trim($b) == 201 ) 
                                                                        {
                                                                            $query = "Select * from users where active=0 order by ID";
                                                                            $step = 50;
                                                                            $currentpage = $p;
                                                                            $sql = "select * from users where active=0";
                                                                            if( !($rs = mysql_query($sql)) ) 
                                                                            {
                                                                                mysql_error();
                                                                                print mysql_error();
                                                                                exit();
                                                                            }

                                                                            $row = mysql_num_rows($rs);
                                                                            $totallinks = $row;
                                                                            if( !isset($currentpage) ) 
                                                                            {
                                                                                $currentpage = 1;
                                                                            }

                                                                            if( 0 < $totallinks ) 
                                                                            {
                                                                                if( $totallinks < 50 ) 
                                                                                {
                                                                                    echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                }
                                                                                else
                                                                                {
                                                                                    if( $totallinks < $currentpage * 50 ) 
                                                                                    {
                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                    }

                                                                                }

                                                                            }

                                                                            if( $step < $totallinks ) 
                                                                            {
                                                                                $pagecount = ceil($totallinks / $step);
                                                                                print "<br>Page NO - &nbsp;&nbsp;";
                                                                                for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                {
                                                                                    if( $pageno == $i ) 
                                                                                    {
                                                                                        echo $i . " ";
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                    }

                                                                                }
                                                                                echo "<br><br><br>";
                                                                            }

                                                                            $start = ($currentpage - 1) * $step;
                                                                            $query = "Select * from users where active=0 order by ID";
                                                                            $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                            if( !($result = mysql_query($sql)) ) 
                                                                            {
                                                                                mysql_error();
                                                                                print mysql_error();
                                                                                exit();
                                                                            }

                                                                            echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>Record No.</b></td><td align=center><b>Name</b></td><td align=center valign=center><b>Email</b></td><td width=70 align=center><b>Username</b></td><td width=70 align=center><b>Status</b></td><td align=center><b>Action</b></td></tr>";
                                                                            while( $rs = mysql_fetch_row($result) ) 
                                                                            {
                                                                                $rowcount = $rowcount + 1;
                                                                                $no = intval($currentpage * 50) - 50 + $rowcount;
                                                                                if( $rs[10] == 0 ) 
                                                                                {
                                                                                    $st = "Inactive<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Resend Verfication Email'><br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Verify Account'>";
                                                                                }
                                                                                else
                                                                                {
                                                                                    if( $rs[14] == 1 ) 
                                                                                    {
                                                                                        $st = "Free";
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        $st = "Pro";
                                                                                    }

                                                                                }

                                                                                echo "" . "<tr><td align=center><form action='admin.php' method=post><input type=hidden name=id value=" . $rs["0"] . ">" . $no . "</td><Td align=center>" . $rs[1] . "</td><Td align=center>" . $rs[7] . "</td><Td align=center>" . $rs[8] . "</td><Td align=center>" . $st . "</td><Td align=center valign=center>";
                                                                                echo "<input type=hidden name=atype value=" . $number . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='View Details'>&nbsp;&nbsp;";
                                                                                echo "<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Account'></form></td></tr>";
                                                                            }
                                                                            echo "</table>";
                                                                        }
                                                                        else
                                                                        {
                                                                            if( $b == "2" ) 
                                                                            {
                                                                                echo "<h3 align=center>Search Members</h3>";
                                                                                if( !$_POST ) 
                                                                                {
                                                                                    echo "<br><form action='admin.php?b=2' method=post><center>Enter Name/Username/Email of the member to Search<br><input type=text name=user><br><br><input type=Submit style='' color:#000000; font-size:10pt; font-family:Verdana; font-weight:bold; border:1px ridge #000000; background-color:#B0D8DD  value='Search'></form></center>";
                                                                                }
                                                                                else
                                                                                {
                                                                                    $user = $_POST[user];
                                                                                    $sql = "" . "select * from users where Name like '%" . $user . "%' or Email like '%" . $user . "%' or Username like '%" . $user . "%'";
                                                                                    $res = mysql_query($sql);
                                                                                    if( 0 < mysql_num_rows($res) ) 
                                                                                    {
                                                                                        $rowcount = 0;
                                                                                        echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>Record No.</b></td><td align=center><b>Name</b></td><td align=center valign=center><b>Email</b></td><td width=70 align=center><b>Username</b></td><td width=70 align=center><b>Status</b></td><td align=center><b>Action</b></td></tr>";
                                                                                        while( $rs = mysql_fetch_row($res) ) 
                                                                                        {
                                                                                            if( $rs[10] == 0 ) 
                                                                                            {
                                                                                                $st = "Inactive<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Resend Verfication Email'><br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Verify Account'>";
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                if( $rs[14] == 1 ) 
                                                                                                {
                                                                                                    $st = "Free";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    $st = "Pro";
                                                                                                }

                                                                                            }

                                                                                            $rowcount = $rowcount + 1;
                                                                                            $no = $rowcount;
                                                                                            echo "<tr><form action='admin.php' method=post><input type=hidden name=id value=" . $rs[0] . "><td align=center>" . $no . "</td><Td align=center>" . $rs[1] . "</td><Td align=center>" . $rs[7] . "</td><Td align=center>" . $rs[8] . "</td><Td align=center>" . $st . "</td><Td align=center valign=center>";
                                                                                            echo "<input type=hidden name=atype value=" . $number . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='View Details'>&nbsp;&nbsp;";
                                                                                            echo "<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Account'></form></td></tr>";
                                                                                        }
                                                                                        echo "</table>";
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        echo "<br><br><b>No Results Found</b><br>";
                                                                                    }

                                                                                }

                                                                            }
                                                                            else
                                                                            {
                                                                                if( trim($b) == 21 ) 
                                                                                {
                                                                                    $query = "Select * from users where active=1 and status=1 order by ID";
                                                                                    $step = 50;
                                                                                    $currentpage = $p;
                                                                                    $sql = "select * from users where active=1 and status=1";
                                                                                    if( !($rs = mysql_query($sql)) ) 
                                                                                    {
                                                                                        mysql_error();
                                                                                        print mysql_error();
                                                                                        exit();
                                                                                    }

                                                                                    $row = mysql_num_rows($rs);
                                                                                    $totallinks = $row;
                                                                                    if( !isset($currentpage) ) 
                                                                                    {
                                                                                        $currentpage = 1;
                                                                                    }

                                                                                    if( 0 < $totallinks ) 
                                                                                    {
                                                                                        if( $totallinks < 50 ) 
                                                                                        {
                                                                                            echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            if( $totallinks < $currentpage * 50 ) 
                                                                                            {
                                                                                                echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                            }

                                                                                        }

                                                                                    }

                                                                                    if( $step < $totallinks ) 
                                                                                    {
                                                                                        $pagecount = ceil($totallinks / $step);
                                                                                        print "<br>Page NO - &nbsp;&nbsp;";
                                                                                        for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                        {
                                                                                            if( $pageno == $i ) 
                                                                                            {
                                                                                                echo $i . " ";
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                            }

                                                                                        }
                                                                                        echo "<br><br><br>";
                                                                                    }

                                                                                    $start = ($currentpage - 1) * $step;
                                                                                    $query = "Select * from users where active=1 and status=1 order by ID";
                                                                                    $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                    if( !($result = mysql_query($sql)) ) 
                                                                                    {
                                                                                        mysql_error();
                                                                                        print mysql_error();
                                                                                        exit();
                                                                                    }

                                                                                    echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>Record No.</b></td><td align=center><b>Name</b></td><td align=center valign=center><b>Email</b></td><td width=70 align=center><b>Username</b></td><td width=70 align=center><b>Status</b></td><td align=center><b>Action</b></td></tr>";
                                                                                    while( $rs = mysql_fetch_row($result) ) 
                                                                                    {
                                                                                        $rowcount = $rowcount + 1;
                                                                                        $no = intval($currentpage * 50) - 50 + $rowcount;
                                                                                        if( $rs[10] == 0 ) 
                                                                                        {
                                                                                            $st = "Inactive<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Resend Verfication Email'><br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Verify Account'>";
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            if( $rs[14] == 1 ) 
                                                                                            {
                                                                                                $st = "Free";
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                $st = "Pro";
                                                                                            }

                                                                                        }

                                                                                        echo "<tr><form action='admin.php' method=post><input type=hidden name=id value=" . $rs[0] . "><td align=center>" . $no . "</td><Td align=center>" . $rs[1] . "</td><Td align=center>" . $rs[7] . "</td><Td align=center>" . $rs[8] . "</td><Td align=center>" . $st . "</td><Td align=center valign=center>";
                                                                                        echo "<input type=hidden name=atype value=" . $number . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='View Details'>&nbsp;&nbsp;";
                                                                                        echo "<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Account'></form></td></tr>";
                                                                                    }
                                                                                    echo "</table>";
                                                                                }
                                                                                else
                                                                                {
                                                                                    if( trim($b) == 22 ) 
                                                                                    {
                                                                                        $query = "Select * from users where active=1 and status=2 order by ID";
                                                                                        $step = 50;
                                                                                        $currentpage = $p;
                                                                                        $sql = "select * from users where active=1 and status=2";
                                                                                        if( !($rs = mysql_query($sql)) ) 
                                                                                        {
                                                                                            mysql_error();
                                                                                            print mysql_error();
                                                                                            exit();
                                                                                        }

                                                                                        $row = mysql_num_rows($rs);
                                                                                        $totallinks = $row;
                                                                                        if( !isset($currentpage) ) 
                                                                                        {
                                                                                            $currentpage = 1;
                                                                                        }

                                                                                        if( 0 < $totallinks ) 
                                                                                        {
                                                                                            if( $totallinks < 50 ) 
                                                                                            {
                                                                                                echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                if( $totallinks < $currentpage * 50 ) 
                                                                                                {
                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                }

                                                                                            }

                                                                                        }

                                                                                        if( $step < $totallinks ) 
                                                                                        {
                                                                                            $pagecount = ceil($totallinks / $step);
                                                                                            print "<br>Page NO - &nbsp;&nbsp;";
                                                                                            for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                            {
                                                                                                if( $pageno == $i ) 
                                                                                                {
                                                                                                    echo $i . " ";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                }

                                                                                            }
                                                                                            echo "<br><br><br>";
                                                                                        }

                                                                                        $start = ($currentpage - 1) * $step;
                                                                                        $query = "Select * from users where active=1 and status=2 order by ID";
                                                                                        $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                        if( !($result = mysql_query($sql)) ) 
                                                                                        {
                                                                                            mysql_error();
                                                                                            print mysql_error();
                                                                                            exit();
                                                                                        }

                                                                                        echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>Record No.</b></td><td align=center><b>Name</b></td><td align=center valign=center><b>Email</b></td><td width=70 align=center><b>Username</b></td><td width=70 align=center><b>Status</b></td><td align=center><b>Action</b></td></tr>";
                                                                                        while( $rs = mysql_fetch_row($result) ) 
                                                                                        {
                                                                                            $rowcount = $rowcount + 1;
                                                                                            $no = intval($currentpage * 50) - 50 + $rowcount;
                                                                                            if( $rs[10] == 0 ) 
                                                                                            {
                                                                                                $st = "Inactive<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Resend Verfication Email'><br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Verify Account'>";
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                if( $rs[14] == 1 ) 
                                                                                                {
                                                                                                    $st = "Free";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    $st = "Pro";
                                                                                                }

                                                                                            }

                                                                                            echo "<form action='admin.php' method=post><input type=hidden name=id value=" . $rs[0] . "><tr><td align=center>" . $no . "</td><Td align=center>" . $rs[1] . "</td><Td align=center>" . $rs[7] . "</td><Td align=center>" . $rs[8] . "</td><Td align=center>" . $st . "</td><Td align=center valign=center>";
                                                                                            echo "<input type=hidden name=atype value=" . $number . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='View Details'>&nbsp;&nbsp;";
                                                                                            echo "<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Account'></form></td></tr>";
                                                                                        }
                                                                                        echo "</table>";
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        if( $b == 99 ) 
                                                                                        {
                                                                                            include("config.php");
                                                                                            $rs = mysql_query("select * from users where active=1");
                                                                                            $i = 0;
                                                                                            while( $arr = mysql_fetch_array($rs) ) 
                                                                                            {
                                                                                                if( $arr[11] == "" ) 
                                                                                                {
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    $a[$i] = $arr[8];
                                                                                                    $bb[$i] = $arr[11];
                                                                                                    $i++;
                                                                                                }

                                                                                            }
                                                                                            if( 0 < $i ) 
                                                                                            {
                                                                                                $e = my_array_unique($bb);
                                                                                                for( $j = 0; $j < count($e); $j++ ) 
                                                                                                {
                                                                                                    $c[$j] = 0;
                                                                                                }
                                                                                                for( $j = 0; $j < count($e); $j++ ) 
                                                                                                {
                                                                                                    for( $l = 0; $l < count($bb); $l++ ) 
                                                                                                    {
                                                                                                        if( $bb[$l] == $e[$j] ) 
                                                                                                        {
                                                                                                            $c[$j] = $c[$j] + 1;
                                                                                                        }

                                                                                                    }
                                                                                                }
                                                                                                $rs = mysql_query("drop table topref");
                                                                                                $rs = mysql_query("create table topref( ID text,ref int unsigned not null)");
                                                                                                for( $j = 0; $j < count($e); $j++ ) 
                                                                                                {
                                                                                                    $rs = mysql_query("" . "insert into topref values('" . $e[$j] . "','" . $c[$j] . "')");
                                                                                                }
                                                                                                echo "<h2 align=center> Top 100 Sponsors </h2><font face=verdana size=2><center>";
                                                                                                $rs = mysql_query("select * from topref order by ref desc limit 0,100");
                                                                                                while( $arr = mysql_fetch_array($rs) ) 
                                                                                                {
                                                                                                    $rs1 = mysql_query("" . "select * from users where Username='" . $arr["0"] . "'");
                                                                                                    $arr1 = mysql_fetch_array($rs1);
                                                                                                    $rs2 = mysql_query("" . "select * from users where status=2 and active=1 and ref_by='" . $arr["0"] . "'");
                                                                                                    $rs3 = mysql_query("" . "select * from users where status=1 and active=1 and ref_by='" . $arr["0"] . "'");
                                                                                                    echo "" . "<br> User:" . $arr["0"] . " have " . $arr["1"] . " Referrals (" . mysql_num_rows($rs2) . " pro & " . mysql_num_rows($rs3) . " free referrals)";
                                                                                                }
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                echo "<br><br><Center>No Record Found with any sponsor</center><br><br>";
                                                                                                return NULL;
                                                                                            }

                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            if( trim($b) == 1 ) 
                                                                                            {
                                                                                                $query = "Select * from users order by ID";
                                                                                                membersrecords($query, 1, $b, $p);
                                                                                                return NULL;
                                                                                            }

                                                                                            if( trim($b) == "View Details" ) 
                                                                                            {
                                                                                                $id = $_POST[id];
                                                                                                $sql = "select * from users where id=" . $_POST[id];
                                                                                                $result = mysql_query($sql);
                                                                                                $rs = mysql_fetch_row($result);
                                                                                                echo "<table><br><form action='admin.php' method=post><input type=hidden name=id value=" . $id . "><input type=hidden name=atype value=" . $atype . ">";
                                                                                                echo "<tr><td colspan=2><h3><center>Member's Information</h3></td></tr>";
                                                                                                echo "<tr><Td width=200><b>Name</b></td><td width=400>" . $rs[1] . "</td></tr>";
                                                                                                if( $showaddress == 1 ) 
                                                                                                {
                                                                                                    echo "<tr><Td width=200><b>Addres</b></td><td width=400>" . $rs[2] . "</td></tr>";
                                                                                                }

                                                                                                if( $showcity == 1 ) 
                                                                                                {
                                                                                                    echo "<tr><Td width=200><b>City</b></td><td width=400>" . $rs[3] . "</td></tr>";
                                                                                                }

                                                                                                if( $showstate == 1 ) 
                                                                                                {
                                                                                                    echo "<tr><Td width=200><b>State</b></td><td width=400>" . $rs[4] . "</td></tr>";
                                                                                                }

                                                                                                if( $showzip == 1 ) 
                                                                                                {
                                                                                                    echo "<tr><Td width=200><b>Zip</b></td><td width=400>" . $rs[5] . "</td></tr>";
                                                                                                }

                                                                                                if( $showcountry == 1 ) 
                                                                                                {
                                                                                                    echo "<tr><Td with=200><b>Country</b></td><td width=400>" . $rs[6] . "</td></tr>";
                                                                                                }

                                                                                                echo "<tr><Td width=200><b>Phone</b></td><td width=400>" . $rs[31] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Email</b></td><td width=400>" . $rs[7] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Payza Email</b></td><td width=400>" . $rs[24] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Egopay Email</b></td><td width=400>" . $rs[25] . "</td></tr>";
                                                                                                if( 0 < $extramerchants ) 
                                                                                                {
                                                                                                    echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400>" . $rs[26] . "</td></tr>";
                                                                                                }

                                                                                                if( 1 < $extramerchants ) 
                                                                                                {
                                                                                                    echo "" . "<tr><Td width=200><b>" . $merchantname2 . "</b></td><td width=400>" . $rs[27] . "</td></tr>";
                                                                                                }

                                                                                                if( 2 < $extramerchants ) 
                                                                                                {
                                                                                                    echo "" . "<tr><Td width=200><b>" . $merchantname3 . "</b></td><td width=400>" . $rs[28] . "</td></tr>";
                                                                                                }

                                                                                                if( 3 < $extramerchants ) 
                                                                                                {
                                                                                                    echo "" . "<tr><Td width=200><b>" . $merchantname4 . "</b></td><td width=400>" . $rs[29] . "</td></tr>";
                                                                                                }

                                                                                                if( 4 < $extramerchants ) 
                                                                                                {
                                                                                                    echo "" . "<tr><Td width=200><b>" . $merchantname5 . "</b></td><td width=400>" . $rs[30] . "</td></tr>";
                                                                                                }

                                                                                                if( $rs[19] == 0 ) 
                                                                                                {
                                                                                                    $mmstatus = "Unsubscribed<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Change to Subscribed'>";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    $mmstatus = "Subscribed";
                                                                                                }

                                                                                                echo "<tr><Td width=200><b>Admin Mailing Status</b></td><td width=400>" . $mmstatus . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Username</b></td><td width=400>" . $rs[8] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Password</b></td><td width=400>" . $rs[9] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Referred By</b></td><td width=400>" . $rs[11] . "</td></tr>";
                                                                                                $rs1 = mysql_query("" . "select * from users where active=1 and ref_by='" . $rs["8"] . "'");
                                                                                                $dref = mysql_num_rows($rs1);
                                                                                                echo "<tr><Td width=200><b>Direct Referrals</b></td><td width=400>" . $dref . "</td></tr>";
                                                                                                echo "" . "<tr><Td width=200><b>Total Earned</b></td><td width=400>\$" . $rs[15] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Banner Credits</b></td><td width=400>" . $rs[20] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Unused Banner Credits</b></td><td width=400>" . ($rs[20] - $rs[21]) . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Used Banner Credits</b></td><td width=400>" . $rs[21] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Text Ads Credits</b></td><td width=400>" . $rs[22] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Unused Text Ads Credits</b></td><td width=400>" . ($rs[22] - $rs[23]) . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Used Text Ads Credits</b></td><td width=400>" . $rs[23] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>IP</b></td><td width=400>" . $rs[12] . "</td></tr>";
                                                                                                if( $rs[10] == 0 ) 
                                                                                                {
                                                                                                    echo "<tr><Td width=200><b>Status</b></td><td width=400>Inactive<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Resend Verfication Email'><br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Verify Account'></td></tr>";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    if( $rs[14] == 1 ) 
                                                                                                    {
                                                                                                        echo "<tr><Td width=200><b>Status</b></td><td width=400>Free</td></tr>";
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        echo "<tr><Td width=200><b>Status</b></td><td width=400>Pro</td></tr>";
                                                                                                    }

                                                                                                }

                                                                                                echo "<tr><Td width=200><b>Date . Time of Registration</b></td><td width=400>" . $rs[13] . "</td></tr>";
                                                                                                echo "<tr><Td width=200><b>Positions Details</b></td><td width=400></td></tr><tr><td colspan=2>";
                                                                                                $count = 0;
                                                                                                $rsm = mysql_query("select * from membershiplevels order by ID");
                                                                                                while( $arrm = mysql_fetch_array($rsm) ) 
                                                                                                {
                                                                                                    $levels = $arrm[4];
                                                                                                    $result = mysql_query("" . "Select * from matrix" . $arrm["0"] . " where Username='" . $rs["8"] . "' order by ID");
                                                                                                    if( 0 < mysql_num_rows($result) ) 
                                                                                                    {
                                                                                                        $rc = 0;
                                                                                                        echo "" . "<br><b>" . $arrm["1"] . "</b><br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=70><font face=verdana size=2><b>#</b></font></td><td align=center valign=center><font face=verdana size=2><b>Matrix ID</b></font></td><td align=center valign=center><font face=verdana size=2><b>Matrix Upline</b></font></td>";
                                                                                                        for( $i = 1; $i <= $levels; $i++ ) 
                                                                                                        {
                                                                                                            echo "" . "<td align=center><font face=verdana size=2><b>Level" . $i . "</b></font></td>";
                                                                                                        }
                                                                                                        echo "<td width=70 align=center><font face=verdana size=2><b>Total Earned</b></font></td><td align=center><font face=verdana size=2><b>Purchased Date</b></font></td><td align=center><font face=verdana size=2><b>Activation Date</b></font></td></tr>";
                                                                                                        while( $rss = mysql_fetch_row($result) ) 
                                                                                                        {
                                                                                                            $rc++;
                                                                                                            $count++;
                                                                                                            if( $rss[16] == $rss[18] ) 
                                                                                                            {
                                                                                                                $cycled = "Not Yet";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                $cycled = "" . $rss["18"];
                                                                                                            }

                                                                                                            echo "<tr><td align=center><font face=verdana size=2>" . $rc . "</font></td><td align=center><font face=verdana size=2>" . $rss[0] . "</font></td><td align=center><font face=verdana size=2>" . $rss[3] . "</font></td>";
                                                                                                            for( $i = 1; $i <= $levels; $i++ ) 
                                                                                                            {
                                                                                                                echo "<td align=center><font face=verdana size=2>" . $rss[3 + $i] . "</font></td>";
                                                                                                            }
                                                                                                            echo "" . "<td align=center><font face=verdana size=2>\$" . $rss[15] . "</font></td><td align=center><font face=verdana size=2>" . $rss[16] . "</font></td><td align=center><font face=verdana size=2>" . $cycled . "</font></td></tr>";
                                                                                                        }
                                                                                                        echo "</table>";
                                                                                                    }

                                                                                                }
                                                                                                if( $count == 0 ) 
                                                                                                {
                                                                                                    echo "<b>No Position Details Found</b></center>";
                                                                                                }

                                                                                                echo "</td></tr><tr><Td width=200><b>Gift Details</b></td><td width=400></td></tr><tr><td colspan=2>";
                                                                                                $sql = "" . "Select * from gifts where FUsername='" . $rs["8"] . "' or TUsername='" . $rs["8"] . "' order by ID";
                                                                                                $wrs = mysql_query($sql);
                                                                                                if( 0 < mysql_num_rows($wrs) ) 
                                                                                                {
                                                                                                    $rc = 0;
                                                                                                    echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><font face=verdana size=2><b>ID.</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>From</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>To</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Payment Details</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Amount</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Matrix</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Date</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Status</b></font></td>\r\n\t</tr>";
                                                                                                    while( $rss = mysql_fetch_row($wrs) ) 
                                                                                                    {
                                                                                                        $rsm = mysql_query("" . "select ID,Name,fee from membershiplevels where ID=" . $rss["6"]);
                                                                                                        $arrm = mysql_fetch_array($rsm);
                                                                                                        if( $rss[8] == 0 ) 
                                                                                                        {
                                                                                                            $status = "Pending";
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            $status = "" . "Approved on " . $rss["10"];
                                                                                                        }

                                                                                                        echo "<tr><td align=center><font face=verdana size=2>" . $rss[0] . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rss[1] . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rss[2] . "" . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rss["3"] . " ( " . $rss["4"] . " )</font></td>\r\n\t  <Td align=center><font face=verdana size=2>\$" . $rss[5] . "" . " </font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $arrm["1"] . " ( \$" . $arrm["2"] . " )<br>( ID: " . $rss["7"] . " )</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rss[9] . "" . " </font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $status . "</font></td>\r\n\t  </tr>";
                                                                                                    }
                                                                                                    echo "</table>";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    echo "<b>No Records Found</b>";
                                                                                                }

                                                                                                echo "</td></tr><tr><Td width=200><b>Referrals Details</b></td><td width=400></td></tr><tr><td colspan=2>";
                                                                                                $result = mysql_query("" . "Select * from users where ref_by='" . $rs["8"] . "' order by ID");
                                                                                                if( 0 < mysql_num_rows($result) ) 
                                                                                                {
                                                                                                    $rc = 0;
                                                                                                    echo "<table width=500><tr>\r\n<td width=150><font face=verdana size=2><b>Name</b></font></td>\r\n<td width=100><font face=verdana size=2><b>Username</b></font></td>\r\n<td width=150><font face=verdana size=2><b>Email</b></font></td>\r\n<td width=100><font face=verdana size=2><b>Status</b></font></td>\r\n<td width=100><font face=verdana size=2><b>Date Joined</b></font></td>\r\n</tr>";
                                                                                                    while( $rss = mysql_fetch_row($result) ) 
                                                                                                    {
                                                                                                        if( $rss[14] == 1 ) 
                                                                                                        {
                                                                                                            $status = "Free";
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            $totalpos = 0;
                                                                                                            $rsm = mysql_query("select * from membershiplevels order by ID");
                                                                                                            while( $arrm = mysql_fetch_array($rsm) ) 
                                                                                                            {
                                                                                                                $rsm1 = mysql_query("" . "select * from matrix" . $arrm["0"] . " where Username='" . $rss["8"] . "'");
                                                                                                                $totalpos = $totalpos + mysql_num_rows($rsm1);
                                                                                                            }
                                                                                                            $status = "" . "Pro (" . $totalpos . " Positions)";
                                                                                                        }

                                                                                                        echo "" . "<tr>\r\n<td ><font face=verdana size=2>" . $rss["1"] . "</font></td>\r\n<td ><font face=verdana size=2>" . $rss["8"] . "</font></td>\r\n<td ><font face=verdana size=2><A href=mailto:" . $rss["7"] . ">" . $rss["7"] . "</a></font></td>\r\n<td ><font face=verdana size=2>" . $status . "</font></td>\r\n<td ><font face=verdana size=2>" . $rss["13"] . "</font></td>\r\n</tr>";
                                                                                                    }
                                                                                                    echo "</table>";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    echo "<b>No Referrals Found</b>";
                                                                                                }

                                                                                                echo "</td></tr><tr><Td colspan=2><p>&nbsp;</p></td></tr><tr><td colspan=2><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Edit Details'>&nbsp;&nbsp;<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Account'></form></td></tr></table>";
                                                                                                return NULL;
                                                                                            }

                                                                                            if( $b == "Verify Account" ) 
                                                                                            {
                                                                                                $id = $_POST[id];
                                                                                                mysql_query("" . "update users set active=1 where id=" . $id);
                                                                                                $sql = "select * from users where id=" . $id;
                                                                                                $result = mysql_query($sql);
                                                                                                $rs = mysql_fetch_row($result);
                                                                                                echo "<br><b>Account Successfully verified</b><br>";
                                                                                                $to = $rs[7];
                                                                                                $message1 = $message2;
                                                                                                $message1 = str_replace("{name}", "" . $rs["1"], $message1);
                                                                                                $message1 = str_replace("{email}", "" . $rs["7"], $message1);
                                                                                                $message1 = str_replace("{username}", "" . $rs["8"], $message1);
                                                                                                $message1 = str_replace("{password}", "" . $rs["9"], $message1);
                                                                                                $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                $subject1 = str_replace("{name}", "" . $rs["1"], $subject2);
                                                                                                $subject1 = str_replace("{email}", "" . $rs["7"], $subject1);
                                                                                                $subject1 = str_replace("{username}", "" . $rs["8"], $subject1);
                                                                                                $subject1 = str_replace("{password}", "" . $rs["9"], $subject1);
                                                                                                $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                $message = stripslashes($message1);
                                                                                                $subject = stripslashes($subject1);
                                                                                                $from = $webmasteremail;
                                                                                                $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                if( $eformat2 == 1 ) 
                                                                                                {
                                                                                                    $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                }

                                                                                                $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                $header .= "X-Mailer: PHP4\n";
                                                                                                $header .= "X-Priority: 3\n";
                                                                                                $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                mail($to, $subject, $message, $header);
                                                                                                if( $refnotification == 1 ) 
                                                                                                {
                                                                                                    $ref_by = $rs[11];
                                                                                                    $rs1 = mysql_query("" . "select * from users where Username='" . $ref_by . "'");
                                                                                                    if( 0 < mysql_num_rows($rs1) ) 
                                                                                                    {
                                                                                                        $arr1 = mysql_fetch_array($rs1);
                                                                                                        $message1 = $message3;
                                                                                                        $message1 = str_replace("{name}", "" . $arr1["1"], $message1);
                                                                                                        $message1 = str_replace("{email}", "" . $arr1["7"], $message1);
                                                                                                        $message1 = str_replace("{username}", "" . $arr1["8"], $message1);
                                                                                                        $message1 = str_replace("{password}", "" . $arr1["9"], $message1);
                                                                                                        $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                        $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                        $message1 = str_replace("{refname}", "" . $rs["1"], $message1);
                                                                                                        $message1 = str_replace("{refemail}", "" . $rs["7"], $message1);
                                                                                                        $message1 = str_replace("{refusername}", "" . $rs["8"], $message1);
                                                                                                        $subject1 = str_replace("{name}", "" . $arr1["1"], $subject3);
                                                                                                        $subject1 = str_replace("{email}", "" . $arr1["7"], $subject1);
                                                                                                        $subject1 = str_replace("{username}", "" . $arr1["8"], $subject1);
                                                                                                        $subject1 = str_replace("{password}", "" . $arr1["9"], $subject1);
                                                                                                        $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                        $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                        $subject1 = str_replace("{refname}", "" . $rs["1"], $subject1);
                                                                                                        $subject1 = str_replace("{refemail}", "" . $rs["7"], $subject1);
                                                                                                        $subject1 = str_replace("{refusername}", "" . $rs["8"], $subject1);
                                                                                                        $message = stripslashes($message1);
                                                                                                        $subject = stripslashes($subject1);
                                                                                                        $to = $arr1[7];
                                                                                                        $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                        if( $eformat3 == 1 ) 
                                                                                                        {
                                                                                                            $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                        }

                                                                                                        $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                        $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                        $header .= "X-Mailer: PHP4\n";
                                                                                                        $header .= "X-Priority: 3\n";
                                                                                                        $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                        mail($to, $subject, $message, $header);
                                                                                                        return NULL;
                                                                                                    }

                                                                                                }

                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                if( $b == "Resend Verfication Email" ) 
                                                                                                {
                                                                                                    $id = $_POST[id];
                                                                                                    $sql = "select * from users where id=" . $id;
                                                                                                    $result = mysql_query($sql);
                                                                                                    $rs = mysql_fetch_row($result);
                                                                                                    $to = $rs[7];
                                                                                                    $validationurl = "" . $siteurl . "/confirm.php?username=" . $rs["8"] . "&id=" . $rs["0"];
                                                                                                    $message1 = str_replace("{validationurl}", "" . $validationurl, $message1);
                                                                                                    $message1 = str_replace("{name}", "" . $rs["1"], $message1);
                                                                                                    $message1 = str_replace("{email}", "" . $rs["7"], $message1);
                                                                                                    $message1 = str_replace("{username}", "" . $rs["8"], $message1);
                                                                                                    $message1 = str_replace("{password}", "" . $rs["9"], $message1);
                                                                                                    $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                    $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                    $subject1 = str_replace("{name}", "" . $rs["1"], $subject1);
                                                                                                    $subject1 = str_replace("{email}", "" . $rs["7"], $subject1);
                                                                                                    $subject1 = str_replace("{username}", "" . $rs["8"], $subject1);
                                                                                                    $subject1 = str_replace("{password}", "" . $rs["9"], $subject1);
                                                                                                    $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                    $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                    $message = stripslashes($message1);
                                                                                                    $subject = stripslashes($subject1);
                                                                                                    $from = $webmasteremail;
                                                                                                    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                    if( $eformat1 == 1 ) 
                                                                                                    {
                                                                                                        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                    }

                                                                                                    $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                    $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                    $header .= "X-Mailer: PHP4\n";
                                                                                                    $header .= "X-Priority: 3\n";
                                                                                                    $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                    mail($to, $subject, $message, $header);
                                                                                                    echo "<br><b>Confirmation Email has been send to " . $rs[7];
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( $b == "Change to Subscribed" ) 
                                                                                                {
                                                                                                    $rs = mysql_query("" . "select * from users where ID=" . $_POST["id"]);
                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                    if( $arr[19] == 1 ) 
                                                                                                    {
                                                                                                        echo "<br><b>Mailing Status is already subscribed</b><br>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    $rs = mysql_query("" . "update users set subscribed=1 where ID=" . $_POST["id"]);
                                                                                                    echo "<br><b>Mailing Subscription status successfully changed</b><br>";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( $b == "Edit Details" ) 
                                                                                                {
                                                                                                    $id = $_POST[id];
                                                                                                    if( $_POST[edit] != 1 ) 
                                                                                                    {
                                                                                                        $sql = "select * from users where id=" . $_POST[id];
                                                                                                        $result = mysql_query($sql);
                                                                                                        $rs = mysql_fetch_row($result);
                                                                                                        echo "<table><br><form action='admin.php' method=post><input type=hidden name=id value=" . $id . "><input type=hidden name=edit value=1>";
                                                                                                        echo "<tr><td colspan=2><h3><center>Update Member's Information</h3></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Name</b></td><td width=400><input type=text name=name value='" . $rs[1] . "'></td></tr>";
                                                                                                        if( $showaddress == 1 ) 
                                                                                                        {
                                                                                                            echo "<tr><Td width=200><b>Addres</b></td><td width=400><input type=text name=address value='" . $rs[2] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( $showcity == 1 ) 
                                                                                                        {
                                                                                                            echo "<tr><Td width=200><b>City</b></td><td width=400><input type=text name=city value='" . $rs[3] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( $showstate == 1 ) 
                                                                                                        {
                                                                                                            echo "<tr><Td width=200><b>State</b></td><td width=400><input type=text name=state value='" . $rs[4] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( $showzip == 1 ) 
                                                                                                        {
                                                                                                            echo "<tr><Td width=200><b>Zip</b></td><td width=400><input type=text name=zip value='" . $rs[5] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( $showcountry == 1 ) 
                                                                                                        {
                                                                                                            echo "<tr><Td width=200><b>Country</b></td><td width=400><input type=text name=country value='" . $rs[6] . "'></td></tr>";
                                                                                                        }

                                                                                                        echo "<tr><Td width=200><b>Email</b></td><td width=400><input type=text name=email value='" . $rs[7] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Payza Email</b></td><td width=400><input type=text name=payza value='" . $rs[24] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Egopay Email</b></td><td width=400><input type=text name=egopay value='" . $rs[25] . "'></td></tr>";
                                                                                                        if( 0 < $extramerchants ) 
                                                                                                        {
                                                                                                            echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400><input type=text name=merchant1 value='" . $rs[26] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( 1 < $extramerchants ) 
                                                                                                        {
                                                                                                            echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400><input type=text name=merchant2 value='" . $rs[27] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( 2 < $extramerchants ) 
                                                                                                        {
                                                                                                            echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400><input type=text name=merchant3 value='" . $rs[28] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( 3 < $extramerchants ) 
                                                                                                        {
                                                                                                            echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400><input type=text name=merchant4 value='" . $rs[29] . "'></td></tr>";
                                                                                                        }

                                                                                                        if( 4 < $extramerchants ) 
                                                                                                        {
                                                                                                            echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400><input type=text name=merchant5 value='" . $rs[30] . "'></td></tr>";
                                                                                                        }

                                                                                                        echo "<tr><Td width=200><b>Phone</b></td><td width=400><input type=text name=phone value='" . $rs[31] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Sponsor</b></td><td width=400><input type=text name=ref value='" . $rs[11] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Username</b></td><td width=400><b>" . $rs[8] . "</b></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Password</b></td><td width=400><input type=text name=password value='" . $rs[9] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Banner Credits</b></td><td width=400><input type=text name=bc value='" . $rs[20] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Used Banner Credits</b></td><td width=400><input type=text name=ubc value='" . $rs[21] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Text Ad Credits</b></td><td width=400><input type=text name=tc value='" . $rs[22] . "'></td></tr>";
                                                                                                        echo "<tr><Td width=200><b>Used Text Ad Credits</b></td><td width=400><input type=text name=utc value='" . $rs[23] . "'></td></tr>";
                                                                                                        echo "<tr><Td colspan=2><p>&nbsp;</p></td></tr><tr><td colspan=2><input type=Submit style='' color:#000000; font-size:10pt; font-family:Verdana; font-weight:bold; border:1px ridge #000000; background-color:#B0D8DD name='b' value='Edit Details'></form></td></tr></table>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    $sql_u = "update users set Name='" . $_POST[name] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    if( $showaddress == 1 ) 
                                                                                                    {
                                                                                                        $sql_u = "update users set Address='" . $_POST[address] . "' where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql_u);
                                                                                                    }

                                                                                                    if( $showcity == 1 ) 
                                                                                                    {
                                                                                                        $sql_u = "update users set City='" . $_POST[city] . "' where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql_u);
                                                                                                    }

                                                                                                    if( $showstate == 1 ) 
                                                                                                    {
                                                                                                        $sql_u = "update users set State='" . $_POST[state] . "' where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql_u);
                                                                                                    }

                                                                                                    if( $showzip == 1 ) 
                                                                                                    {
                                                                                                        $sql_u = "update users set Zip='" . $_POST[zip] . "' where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql_u);
                                                                                                    }

                                                                                                    if( $showcountry == 1 ) 
                                                                                                    {
                                                                                                        $sql_u = "update users set Country='" . $_POST[country] . "' where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql_u);
                                                                                                    }

                                                                                                    $sql_u = "update users set Phone='" . $_POST[phone] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set ref_by='" . $_POST[ref] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Email='" . $_POST[email] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Payza='" . $_POST[payza] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Egopay='" . $_POST[egopay] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Merchant1='" . $_POST[merchant1] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Merchant2='" . $_POST[merchant2] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Merchant3='" . $_POST[merchant3] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Merchant4='" . $_POST[merchant4] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Merchant5='" . $_POST[merchant5] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set Password='" . $_POST[password] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set banners='" . $_POST[bc] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set bannersused='" . $_POST[ubc] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set textads='" . $_POST[tc] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    $sql_u = "update users set textadsused='" . $_POST[utc] . "' where ID=" . $_POST[id];
                                                                                                    $rs = mysql_query($sql_u);
                                                                                                    echo "<br><b>Record Successfully Updated<br><br>";
                                                                                                    $sql = "select * from users where id=" . $_POST[id];
                                                                                                    $result = mysql_query($sql);
                                                                                                    $rs = mysql_fetch_row($result);
                                                                                                    echo "<table><tr><td colspan=2><h3><center>Member's Information</h3></td></tr>";
                                                                                                    echo "<tr><Td width=200><b>Name</b></td><td width=400>" . $rs[1] . "</td></tr>";
                                                                                                    if( $showaddress == 1 ) 
                                                                                                    {
                                                                                                        echo "<tr><Td width=200><b>Addres</b></td><td width=400>" . $rs[2] . "</td></tr>";
                                                                                                    }

                                                                                                    if( $showcity == 1 ) 
                                                                                                    {
                                                                                                        echo "<tr><Td width=200><b>City</b></td><td width=400>" . $rs[3] . "</td></tr>";
                                                                                                    }

                                                                                                    if( $showstate == 1 ) 
                                                                                                    {
                                                                                                        echo "<tr><Td width=200><b>State</b></td><td width=400>" . $rs[4] . "</td></tr>";
                                                                                                    }

                                                                                                    if( $showzip == 1 ) 
                                                                                                    {
                                                                                                        echo "<tr><Td width=200><b>Zip</b></td><td width=400>" . $rs[5] . "</td></tr>";
                                                                                                    }

                                                                                                    if( $showcountry == 1 ) 
                                                                                                    {
                                                                                                        echo "<tr><Td with=200><b>Country</b></td><td width=400>" . $rs[6] . "</td></tr>";
                                                                                                    }

                                                                                                    echo "<tr><Td width=200><b>Email</b></td><td width=400>" . $rs[7] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200><b>Payza Email</b></td><td width=400>" . $rs[24] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200><b>Egopay Email</b></td><td width=400>" . $rs[25] . "</td></tr>";
                                                                                                    if( 0 < $extramerchants ) 
                                                                                                    {
                                                                                                        echo "" . "<tr><Td width=200><b>" . $merchantname1 . "</b></td><td width=400>" . $rs[26] . "</td></tr>";
                                                                                                    }

                                                                                                    if( 1 < $extramerchants ) 
                                                                                                    {
                                                                                                        echo "" . "<tr><Td width=200><b>" . $merchantname2 . "</b></td><td width=400>" . $rs[27] . "</td></tr>";
                                                                                                    }

                                                                                                    if( 2 < $extramerchants ) 
                                                                                                    {
                                                                                                        echo "" . "<tr><Td width=200><b>" . $merchantname3 . "</b></td><td width=400>" . $rs[28] . "</td></tr>";
                                                                                                    }

                                                                                                    if( 3 < $extramerchants ) 
                                                                                                    {
                                                                                                        echo "" . "<tr><Td width=200><b>" . $merchantname4 . "</b></td><td width=400>" . $rs[29] . "</td></tr>";
                                                                                                    }

                                                                                                    if( 4 < $extramerchants ) 
                                                                                                    {
                                                                                                        echo "" . "<tr><Td width=200><b>" . $merchantname5 . "</b></td><td width=400>" . $rs[30] . "</td></tr>";
                                                                                                    }

                                                                                                    echo "<tr><Td width=200><b>Phone</b></td><td width=400>" . $rs[31] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200><b>Sponsor</b></td><td width=400>" . $rs[11] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200><b>Username</b></td><td width=400>" . $rs[8] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200><b>Password</b></td><td width=400>" . $rs[9] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200>Banner Credits</td><td width=400>" . $rs[20] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200>Unused Banner Credits</td><td width=400>" . ($rs[20] - $rs[21]) . "</td></tr>";
                                                                                                    echo "<tr><Td width=200>Used Banner Credits</td><td width=400>" . $rs[21] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200>Text Ads Credits</td><td width=400>" . $rs[22] . "</td></tr>";
                                                                                                    echo "<tr><Td width=200>Unused Text Ads Credits</td><td width=400>" . ($rs[22] - $rs[23]) . "</td></tr>";
                                                                                                    echo "<tr><Td width=200>Used Text Ads Credits</td><td width=400>" . $rs[23] . "</td></tr></table>";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( trim($b) == "Delete Account" ) 
                                                                                                {
                                                                                                    $id = $_POST[id];
                                                                                                    $rs = mysql_query("" . "select * from users where ID=" . $id);
                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                    echo "" . "<br><center><b><font face=verdana size=2>Are you sure you want to delete User: " . $arr["8"] . "?<br></b></font>\r\n<form action='' method=post>\r\n<input type=hidden name=id value=" . $id . ">\r\n<input type=submit name=b value='Confirm Delete Account'></form>\r\n</center>";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( trim($b) == "Confirm Delete Account" ) 
                                                                                                {
                                                                                                    $id = $_POST[id];
                                                                                                    $rs = mysql_query("" . "select * from users where ID=" . $id);
                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                    $sql_d = "Delete from wtransaction where Username='" . $arr[8] . "'";
                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                    $sql_d = "Delete from memberstextads where Username='" . $arr[8] . "'";
                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                    $sql_d = "Delete from membersbanners where Username='" . $arr[8] . "'";
                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                    $sql_d = "Delete from transaction where Username='" . $arr[8] . "'";
                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                    $sql_d = "Delete from users where ID=" . $id;
                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                    $rsm = mysql_query("select * from membershiplevels order by ID");
                                                                                                    while( $arrm = mysql_fetch_array($rsm) ) 
                                                                                                    {
                                                                                                        mysql_query("" . "update matrix" . $arrm["0"] . " set Username='admin' where Username='" . $arr["8"] . "'");
                                                                                                    }
                                                                                                    $sql_d = "update users set ref_by='' where ref_by='" . $arr[8] . "'";
                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                    $rsuser = mysql_query("" . "select * from transaction where Username='" . $arr["8"] . "' order by ID");
                                                                                                    while( $arruser = mysql_fetch_array($rsuser) ) 
                                                                                                    {
                                                                                                        $user = $arruser[1];
                                                                                                        $tablee = "" . "matrix" . $arruser["3"];
                                                                                                        $acountid = $arruser[6];
                                                                                                        $refid = $arruser[5];
                                                                                                        $rsmu = mysql_query("" . "select ref_by from " . $tablee . " where ID=" . $acountid);
                                                                                                        if( 0 < mysql_num_rows($rsmu) ) 
                                                                                                        {
                                                                                                            $arrmu = mysql_fetch_array($rsmu);
                                                                                                            $refid = $arrmu[0];
                                                                                                        }

                                                                                                        assignreferralss($acountid, $refid, 1, 1, $arruser[3]);
                                                                                                        mysql_query("" . "delete from " . $tablee . " where ID=" . $arruser["6"]);
                                                                                                        mysql_query("" . "delete from gifts where posid=" . $arruser["6"]);
                                                                                                        mysql_query("" . "delete from transaction where ID=" . $arruser["0"]);
                                                                                                    }
                                                                                                    echo "<br><b>Account Successfully Deleted";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( trim($b) == "DeleteT" ) 
                                                                                                {
                                                                                                    $id = $_POST[id];
                                                                                                    $rsuser = mysql_query("" . "select * from transaction where ID=" . $id);
                                                                                                    $arruser = mysql_fetch_array($rsuser);
                                                                                                    $user = $arruser[1];
                                                                                                    $tablee = "" . "matrix" . $arruser["3"];
                                                                                                    $acountid = $arruser[6];
                                                                                                    $refid = $arruser[5];
                                                                                                    $rsmu = mysql_query("" . "select ref_by from " . $tablee . " where ID=" . $acountid);
                                                                                                    if( 0 < mysql_num_rows($rsmu) ) 
                                                                                                    {
                                                                                                        $arrmu = mysql_fetch_array($rsmu);
                                                                                                        $refid = $arrmu[0];
                                                                                                    }

                                                                                                    assignreferralss($acountid, $refid, 1, 1, $arruser[3]);
                                                                                                    mysql_query("" . "delete from " . $tablee . " where ID=" . $arruser["6"]);
                                                                                                    mysql_query("" . "delete from gifts where posid=" . $arruser["6"]);
                                                                                                    mysql_query("" . "delete from transaction where ID=" . $arruser["0"]);
                                                                                                    echo "<br><b>Account Successfully Deleted";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( trim($b) == "ApproveT" ) 
                                                                                                {
                                                                                                    $sql_rc = "select * from transaction where ID=" . $_POST[id];
                                                                                                    $result = mysql_query($sql_rc);
                                                                                                    if( 0 < mysql_num_rows($result) ) 
                                                                                                    {
                                                                                                        $arruser = mysql_fetch_array($result);
                                                                                                        $user = $arruser[1];
                                                                                                        $tablee = "" . "matrix" . $arruser["3"];
                                                                                                        $mid = $arruser[3];
                                                                                                        $acountid = $arruser[6];
                                                                                                        $refid = $arruser[5];
                                                                                                        $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
                                                                                                        $arrm = mysql_fetch_array($rsm);
                                                                                                        $textcreditsentry = $arrm[49];
                                                                                                        $bannercreditsentry = $arrm[50];
                                                                                                        $welcomemail = $arrm[70];
                                                                                                        if( $welcomemail == 1 ) 
                                                                                                        {
                                                                                                            matrixmail($acountid, $user, $mid, 1);
                                                                                                        }

                                                                                                        $today = date("Y-m-d H:i:s", mktime(date("H"), date("i"), date("s"), date("m"), date("d"), date("Y")));
                                                                                                        mysql_query("" . "update " . $tablee . " set CDate='" . $today . "' where ID=" . $arruser["6"]);
                                                                                                        mysql_query("" . "update gifts set ADate='" . $today . "',approved=1 where posid=" . $arruser["6"]);
                                                                                                        mysql_query("" . "update users set banners=banners+" . $bannercreditsentry . ",textads=textads+" . $textcreditsentry . ",status=2 where Username='" . $user . "'");
                                                                                                        $acountid = $arruser[6];
                                                                                                        $refid = $arruser[5];
                                                                                                        $rsmu = mysql_query("" . "select ref_by from " . $tablee . " where ID=" . $acountid);
                                                                                                        if( 0 < mysql_num_rows($rsmu) ) 
                                                                                                        {
                                                                                                            $arrmu = mysql_fetch_array($rsmu);
                                                                                                            $refid = $arrmu[0];
                                                                                                        }

                                                                                                        rassignreferrals($acountid, $refid, 1, 1, $arruser[3]);
                                                                                                        mysql_query("" . "delete from transaction where ID=" . $arruser["0"]);
                                                                                                        echo "<b><br>Transaction successfully approved.</b><br>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    echo "<b><br>This transaction has already been completed";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( $b == "79" ) 
                                                                                                {
                                                                                                    print "" . "<h3 align=center>Matrices</h3>\r\n<font face=verdana size=2>\r\n<center><b>Add a new Matrix</b><br>\r\n<form action=admin.php method=post>\r\n<table>\r\n<tr><td><font face=verdana size=2><b>Matrix Name:</b></td><td><font face=verdana size=2><input type=text name=name> (ie Bronze Matrix)</td></tr>\r\n<tr><td><font face=verdana size=2><b>Membership Fee:</b></td><td><font face=verdana size=2>\$<input type=text name=fee> (ie \$5)</td></tr>\r\n\r\n<tr><td><font face=verdana size=2><b>Matrix Type:</b></td><td><font face=verdana size=2><select name=matrixtype><option value=1>Regular Forced Matrix</option><option value=2>Company Forced Matrix</option></select></td></tr>\r\n\r\n<tr><Td><font face=verdana size=2><b>Matrix Depth (No. of levels deep you want matrix to go from 1 to 10) </b></font></td><td><input type=text name=levels><font face=verdana size=2> (ie. 2)</font></td></tr>\r\n\r\n<tr><Td><font face=verdana size=2><b>Matrix Width </b></font></td><td><input type=text name=forcedmatrix><font face=verdana size=2> (ie. 2)</font></td></tr>\r\n\r\n<input type=hidden name=refbonus value=0>\r\n<input type=hidden name=refbonuspaid value=1>\r\n<input type=hidden name=payouttype value=2>\r\n<input type=hidden name=matrixbonus value=0>\r\n<input type=hidden name=matchingbonus value=0>\r\n<input type=hidden name=level1c value=0>\r\n<input type=hidden name=level1cm value=0>\r\n<input type=hidden name=level2c value=0>\r\n<input type=hidden name=level2cm value=0>\r\n<input type=hidden name=level3c value=0>\r\n<input type=hidden name=level3cm value=0>\r\n<input type=hidden name=level4c value=0>\r\n<input type=hidden name=level4cm value=0>\r\n<input type=hidden name=level5c value=0>\r\n<input type=hidden name=level5cm value=0>\r\n<input type=hidden name=level6c value=0>\r\n<input type=hidden name=level6cm value=0>\r\n<input type=hidden name=level7c value=0>\r\n<input type=hidden name=level7cm value=0>\r\n<input type=hidden name=level8c value=0>\r\n<input type=hidden name=level8cm value=0>\r\n<input type=hidden name=level9c value=0>\r\n<input type=hidden name=level9cm value=0>\r\n<input type=hidden name=level10c value=0>\r\n<input type=hidden name=level10cm value=0>\r\n<input type=hidden name=reentry value=0>\r\n<input type=hidden name=reentrynum value=0>\r\n<input type=hidden name=entry1 value=0><input type=hidden name=matrixid1 value=0><input type=hidden name=entry1num value=0>\r\n<input type=hidden name=entry2 value=0><input type=hidden name=matrixid2 value=0><input type=hidden name=entry2num value=0>\r\n<input type=hidden name=entry3 value=0><input type=hidden name=matrixid3 value=0><input type=hidden name=entry3num value=0>\r\n<input type=hidden name=entry4 value=0><input type=hidden name=matrixid4 value=0><input type=hidden name=entry4num value=0>\r\n<input type=hidden name=entry5 value=0><input type=hidden name=matrixid5 value=0><input type=hidden name=entry5num value=0>\r\n<input type=hidden name=textcreditscycle value=0>\r\n<input type=hidden name=bannercreditscycle value=0>\r\n<input type=hidden name=cyclemail value=0>\r\n<input type=hidden name=cyclemailsponsor value=0>\r\n<input type=hidden name=level1m value=0>\r\n<input type=hidden name=level2m value=0>\r\n<input type=hidden name=level3m value=0>\r\n<input type=hidden name=level4m value=0>\r\n<input type=hidden name=level5m value=0>\r\n<input type=hidden name=level6m value=0>\r\n<input type=hidden name=level7m value=0>\r\n<input type=hidden name=level8m value=0>\r\n<input type=hidden name=level9m value=0>\r\n<input type=hidden name=level10m value=0>\r\n\r\n<tr><td colspan=2><font face=verdana size=2>\r\n<div align=center><table border=1 width=400 cellspacing=0 cellpadding=0>\r\n<tr>\r\n<td width=50% align=center><font face=verdana size=2>Matrix Level</font></td>\r\n<td width=50% align=center><font face=verdana size=2>Matrix Bonus</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 1</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level1 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 2</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level2 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 3</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level3 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 4</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level4 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 5</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level5 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 6</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level6 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 7</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level7 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 8</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level8 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 9</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level9 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 10</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level10 size=5 value=0> ( ie. \$2 )</font></td>\r\n</tr>\r\n</table></div>\r\n</b></font></td></tr>\r\n<tr><td colspan=2>&nbsp;</td></tr>\r\n<tr><td colspan=2><font face=verdana size=2>Bonus Credits on purchasing entry to this matrix or entering this matrix by cycling of any position.</font></td></tr>\r\n\r\n<tr><td><font face=verdana size=2><b>Text Ad Credits:</b></td><td><font face=verdana size=2><input type=text name=textcreditsentry> (ie 500)</td></tr>\r\n<tr><td><font face=verdana size=2><b>Banner Ad Credits:</b></td><td><font face=verdana size=2><input type=text name=bannercreditsentry> (ie 500)</td></tr>\r\n\r\n<tr><td colspan=2><font face=verdana size=2>Bonus Credits on cycling of a position in this matrix.</font></td></tr>\r\n\r\n<tr><td colspan=2>&nbsp;</td></tr>\r\n\r\n<tr><td valign=top><font face=verdana size=2><b>Bonus Downloads:</b></td><td><textarea name=bonusdownloads cols=60 rows=10><font face=verdana size=2>10,000 Banner Impressions and 10,000 Text Ad Impressions (\$50 Value) -- <a href=http://www.maxviralmarketing.com/specialjoin.php target=_blank>Click to Get</a>.<br><br>Lifetime Pro Membership to 7DayPromos.com (\$19 Value) -- <a href=http://www.7daypromos.com/bonusprojoin.php target=_blank>Click to Get</a>.<br><br>\r\n</textarea></td></tr>\r\n\r\n<Tr><td colspan=2><font face=verdana size=2>Change the email contents if you wants.<br><br>\r\nYou can use the following tags for personalized mailing and these will automatically get replaced by user information.<br><br>\r\n{name} for Name of the member<br>\r\n{id} for Matrix ID of the member<br>\r\n{username} for username of the member<br>\r\n{password} for the password of the member<br>\r\n{email} for the Email Address of the member<br>\r\n{sitename} for your sitename like " . $sitename . "<br>\r\n{siteurl} for your website url like " . $siteurl . "<br><br>\r\nNote: If you are using <b>Email Format</b> as <b>HTML</b> then you need to type the complete message in HTML format only.</font></td></tr>";
                                                                                                    echo "<tr><td colspan=2><font face=verdana size=2>If you want to send an welcome email to member to notify them that they have got a entry in this matrix then select <b>Yes</b> in Send Welcome Email option otherwise select <b>No</b>.</font></td></tr>\r\n\r\n<tr><td><font face=verdana size=2><b>Send Welcome Email</b></font></td><td><select name=welcomemail>\r\n<option value=0 selected>No</option>\r\n<option value=1>Yes</option>\r\n</select></td></tr>\r\n\r\n<tr><Td colspan=2><font face=verdana size=2><b>Welcome Email:</b></font><br>\r\n\r\n<table border=0>\r\n<tr><td><font face=verdana size=2><b>Subject:</b></td><td align=left><input type=text name=subject1 value=\"Welcome to {matrix} board!\"></td></tr>\r\n\r\n<tr><Td><font face=verdana size=2><b>Email Format:</b></font></td><td><select name=eformat1>\r\n<option value=1 selected>Text</option>\r\n<option value=2>HTML</option>\r\n</select></td></tr>\r\n\r\n<tr><td valign=top><font face=verdana size=2><b>Message:</b></td><td><textarea name=message1 cols=60 rows=10>Dear member,\n\nWelcome to {matrix} board.\nYou can start promoting your account so that you can earn from this matrix!\nIf you further need any help feel free to contact us.\n\nAdministrator\n{sitename}\r\n</textarea></td></tr>\r\n</table>\r\n\r\n</td></tr>";
                                                                                                    print "<tr><Td colspan=2><input type=Submit     style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border:       1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"Add Matrix\"></td></tr></table></form>";
                                                                                                    $rs = mysql_query("select * from membershiplevels order by ID");
                                                                                                    print "<br><b>View Matrices</b><br>";
                                                                                                    print "<table border=1 cellspacing=1 cellpadding=1><tr>\r\n<td align=center><font face=verdana size=2><b>Matrix Name</b></font></td>\r\n<td align=center><font face=verdana size=2><b>Matrix Details</b></font></td>\r\n<td align=center><font face=verdana size=2><b>Payout Type</b></font></td>\r\n<td align=center><font face=verdana size=2><b>Bonus Credits</b></font></td>\r\n<td align=center><font face=verdana size=2><b>Action</b></font></td></tr>";
                                                                                                    while( $arr = mysql_fetch_array($rs) ) 
                                                                                                    {
                                                                                                        if( $arr[3] == 1 ) 
                                                                                                        {
                                                                                                            $md = "" . "Matrix Type: " . $arr["5"] . " x " . $arr["4"] . " Regular Forcedmatrix<br>";
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            $md = "" . "Matrix Type: " . $arr["5"] . " x " . $arr["4"] . " Company Forcedmatrix<br>";
                                                                                                        }

                                                                                                        $md .= "" . "Membership Fee: \$" . $arr["2"] . "<br>\r\nMatrix Depth: " . $arr["4"] . "<br>\r\nMatrix Width: " . $arr["5"] . "<br>";
                                                                                                        $pt = "";
                                                                                                        if( $arr[6] == 1 ) 
                                                                                                        {
                                                                                                            $pt .= "Payout on Complete Cycle";
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            if( $arr[6] == 2 ) 
                                                                                                            {
                                                                                                                $pt .= "Payout on Per Member Per Level";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                $pt .= "Payout on Completing each Level";
                                                                                                            }

                                                                                                        }

                                                                                                        $pt .= "<br>";
                                                                                                        if( $arr[6] == 1 ) 
                                                                                                        {
                                                                                                            $pt .= "" . "Complete Matrix Bonus: \$" . $arr["7"] . "<br>Matching Bonus: \$" . $arr["8"];
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            if( $arr[6] == 2 ) 
                                                                                                            {
                                                                                                                $pt .= "" . "<table border=1 width=300 cellspacing=0 cellpadding=0>\r\n<tr>\r\n<td width=33% align=center><font face=verdana size=2>Matrix Level</font></td>\r\n<td width=33% align=center><font face=verdana size=2>Matrix Bonus</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 1</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["9"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 2</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["10"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 3</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["11"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 4</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["12"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 5</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["13"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 6</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["14"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 7</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["15"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 8</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["16"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 9</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["17"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 10</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["18"] . "</font></td>\r\n</tr>\r\n</table>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                if( $arr[6] == 3 ) 
                                                                                                                {
                                                                                                                    $pt .= "" . "<table border=1 width=300 cellspacing=0 cellpadding=0>\r\n<tr>\r\n<td width=33% align=center><font face=verdana size=2>Matrix Level</font></td>\r\n<td width=33% align=center><font face=verdana size=2>Matrix Bonus</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 1</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["29"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 2</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["30"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 3</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["31"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 4</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["32"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 5</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["33"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 6</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["34"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 7</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["35"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 8</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["36"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 9</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["37"] . "</font></td>\r\n</tr>\r\n<tr>\r\n<td width=33%><font face=verdana size=2>Level 10</font></td>\r\n<td width=33%><font face=verdana size=2>\$" . $arr["38"] . "</font></td>\r\n</tr>\r\n</table>";
                                                                                                                }

                                                                                                            }

                                                                                                        }

                                                                                                        $bc = "" . "Text Ad Credits On Entry: " . $arr["49"] . "<br>\r\nBanner Ad Credits On Entry: " . $arr["50"] . "<br>";
                                                                                                        $md .= "" . "Matrix Creation Date: " . $arr["85"] . "<br>";
                                                                                                        print "<tr>\r\n<td align=center><font face=verdana size=2>" . $arr[1] . "</font></td>\r\n<td align=center><font face=verdana size=2>" . $md . "</font></td>\r\n<td align=center><font face=verdana size=2>" . $pt . "</font></td>\r\n<td align=center><font face=verdana size=2>" . $bc . "</font></td>\r\n<Td align=center>";
                                                                                                        print "<form action=admin.php method=post><input type=hidden name=id value=" . $arr[0] . ">&nbsp;<input type=Submit      style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border:       1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"Edit Matrix Details\">&nbsp;<input type=Submit      style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border:       1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"Delete Matrix\"></form></td></tr>";
                                                                                                    }
                                                                                                    print "</table>";
                                                                                                    return NULL;
                                                                                                }

                                                                                                if( $b == "Add Matrix" ) 
                                                                                                {
                                                                                                    $rs = mysql_query("" . "insert into membershiplevels values(NULL,'" . $_POST["name"] . "','" . $_POST["fee"] . "','" . $_POST["matrixtype"] . "','" . $_POST["levels"] . "','" . $_POST["forcedmatrix"] . "','" . $_POST["payouttype"] . "','" . $_POST["matrixbonus"] . "','" . $_POST["matchingbonus"] . "','" . $_POST["level1"] . "','" . $_POST["level2"] . "','" . $_POST["level3"] . "','" . $_POST["level4"] . "','" . $_POST["level5"] . "','" . $_POST["level6"] . "','" . $_POST["level7"] . "','" . $_POST["level8"] . "','" . $_POST["level9"] . "','" . $_POST["level10"] . "','" . $_POST["level1m"] . "','" . $_POST["level2m"] . "','" . $_POST["level3m"] . "','" . $_POST["level4m"] . "','" . $_POST["level5m"] . "','" . $_POST["level6m"] . "','" . $_POST["level7m"] . "','" . $_POST["level8m"] . "','" . $_POST["level9m"] . "','" . $_POST["level10m"] . "','" . $_POST["level1c"] . "','" . $_POST["level2c"] . "','" . $_POST["level3c"] . "','" . $_POST["level4c"] . "','" . $_POST["level5c"] . "','" . $_POST["level6c"] . "','" . $_POST["level7c"] . "','" . $_POST["level8c"] . "','" . $_POST["level9c"] . "','" . $_POST["level10c"] . "','" . $_POST["level1cm"] . "','" . $_POST["level2cm"] . "','" . $_POST["level3cm"] . "','" . $_POST["level4cm"] . "','" . $_POST["level5cm"] . "','" . $_POST["level6cm"] . "','" . $_POST["level7cm"] . "','" . $_POST["level8cm"] . "','" . $_POST["level9cm"] . "','" . $_POST["level10cm"] . "','" . $_POST["textcreditsentry"] . "','" . $_POST["bannercreditsentry"] . "','" . $_POST["textcreditscycle"] . "','" . $_POST["bannercreditscycle"] . "','" . $_POST["reentry"] . "','" . $_POST["reentrynum"] . "','" . $_POST["entry1"] . "','" . $_POST["entry1num"] . "','" . $_POST["matrixid1"] . "','" . $_POST["entry2"] . "','" . $_POST["entry2num"] . "','" . $_POST["matrixid2"] . "','" . $_POST["entry3"] . "','" . $_POST["entry3num"] . "','" . $_POST["matrixid3"] . "','" . $_POST["entry4"] . "','" . $_POST["entry4num"] . "','" . $_POST["matrixid4"] . "','" . $_POST["entry5"] . "','" . $_POST["entry5num"] . "','" . $_POST["matrixid5"] . "','" . $_POST["welcomemail"] . "','','','" . $_POST["eformat1"] . "','" . $_POST["cyclemail"] . "','','','" . $_POST["eformat2"] . "','" . $_POST["cyclemailsponsor"] . "','','','" . $_POST["eformat3"] . "',''," . $_POST["refbonuspaid"] . ",'" . $_POST["refbonus"] . "',now())");
                                                                                                    $b = mysql_insert_id();
                                                                                                    $bonusdownloads = addslashes($_POST[bonusdownloads]);
                                                                                                    mysql_query("" . "update membershiplevels set bonusdownloads='" . $bonusdownloads . "' where ID=" . $b);
                                                                                                    $subject1 = addslashes($_POST[subject1]);
                                                                                                    mysql_query("" . "update membershiplevels set Subject1='" . $subject1 . "' where ID=" . $b);
                                                                                                    $message1 = addslashes($_POST[message1]);
                                                                                                    mysql_query("" . "update membershiplevels set Message1='" . $message1 . "' where ID=" . $b);
                                                                                                    print "<b><br>Record SuccessFully Added";
                                                                                                    if( 0 < $b ) 
                                                                                                    {
                                                                                                        $sql = "" . "create table matrix" . $b . "\r\n(\r\n   ID int unsigned not null auto_increment primary key,\r\n   Username varchar(75),\r\n   Sponsor varchar(75),\r\n   ref_by int unsigned not null,\r\n   Level1 int unsigned not null,\r\n   Level2 int unsigned not null,\r\n   Level3 int unsigned not null,\r\n   Level4 int unsigned not null,\r\n   Level5 int unsigned not null,\r\n   Level6 int unsigned not null,\r\n   Level7 int unsigned not null,\r\n   Level8 int unsigned not null,\r\n   Level9 int unsigned not null,\r\n   Level10 int unsigned not null,\r\n   Leader int unsigned not null,\r\n   Total float(8,2),\r\n   Date datetime,\r\n   MainID int unsigned not null,\r\n   CDate datetime\r\n)";
                                                                                                        if( mysql_query($sql) ) 
                                                                                                        {
                                                                                                            print "" . " Table Created : matrix" . $b . " <br>";
                                                                                                            $bcount = 1000000 * $b;
                                                                                                            mysql_query("" . "ALTER TABLE matrix" . $b . " AUTO_INCREMENT = " . $bcount);
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        echo mysql_error();
                                                                                                        print "<BR>" . $sql . "<BR><BR>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    if( $b == "Edit Matrix Details" ) 
                                                                                                    {
                                                                                                        $id = $_POST[id];
                                                                                                        $id1 = $_POST[id1];
                                                                                                        if( !$id1 ) 
                                                                                                        {
                                                                                                            $rs = mysql_query("" . "select * from membershiplevels where ID=" . $id);
                                                                                                            $arr = mysql_fetch_array($rs);
                                                                                                            print "" . "<font face=verdana size=2><center><b>Update Matrix Details</b></center><br>\r\n<form action='' method=post>\r\n<table>\r\n<tr><td><font face=verdana size=2><b>Matrix Name:</b></td><td><font face=verdana size=2><input type=text name=name value=\"" . $arr["1"] . "\"> (ie Bronze Matrix)</td></tr>\r\n<tr><td><font face=verdana size=2><b>Membership Fee:</b></td><td><font face=verdana size=2>\$<input type=text name=fee value=\"" . $arr["2"] . "\"> (ie \$5)</td></tr>\r\n\r\n<tr><td><font face=verdana size=2><b>Matrix Type:</b></td><td><font face=verdana size=2><select name=matrixtype>";
                                                                                                            if( $arr[3] == 1 ) 
                                                                                                            {
                                                                                                                print "<option value=1>Regular Forced Matrix</option><option value=2>Company Forced Matrix</option>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                print "<option value=1>Regular Forced Matrix</option><option value=2 selected>Company Forced Matrix</option>";
                                                                                                            }

                                                                                                            print "" . "</select></td></tr>\r\n\r\n<tr><Td><font face=verdana size=2><b>Matrix Depth (No. of levels deep you want matrix to go from 1 to 10) </b></font></td><td><input type=text name=levels value=\"" . $arr["4"] . "\"><font face=verdana size=2> (ie. 2)</font></td></tr>\r\n\r\n<tr><Td><font face=verdana size=2><b>Matrix Width </b></font></td><td><input type=text name=forcedmatrix value=\"" . $arr["5"] . "\"><font face=verdana size=2> (ie. 2)</font></td></tr>\r\n\r\n<input type=hidden name=refbonus value=0>\r\n<input type=hidden name=refbonuspaid value=1>\r\n<input type=hidden name=payouttype value=2>\r\n<input type=hidden name=matrixbonus value=0>\r\n<input type=hidden name=matchingbonus value=0>\r\n<input type=hidden name=level1c value=0>\r\n<input type=hidden name=level1cm value=0>\r\n<input type=hidden name=level2c value=0>\r\n<input type=hidden name=level2cm value=0>\r\n<input type=hidden name=level3c value=0>\r\n<input type=hidden name=level3cm value=0>\r\n<input type=hidden name=level4c value=0>\r\n<input type=hidden name=level4cm value=0>\r\n<input type=hidden name=level5c value=0>\r\n<input type=hidden name=level5cm value=0>\r\n<input type=hidden name=level6c value=0>\r\n<input type=hidden name=level6cm value=0>\r\n<input type=hidden name=level7c value=0>\r\n<input type=hidden name=level7cm value=0>\r\n<input type=hidden name=level8c value=0>\r\n<input type=hidden name=level8cm value=0>\r\n<input type=hidden name=level9c value=0>\r\n<input type=hidden name=level9cm value=0>\r\n<input type=hidden name=level10c value=0>\r\n<input type=hidden name=level10cm value=0>\r\n<input type=hidden name=reentry value=0>\r\n<input type=hidden name=reentrynum value=0>\r\n<input type=hidden name=entry1 value=0><input type=hidden name=matrixid1 value=0><input type=hidden name=entry1num value=0>\r\n<input type=hidden name=entry2 value=0><input type=hidden name=matrixid2 value=0><input type=hidden name=entry2num value=0>\r\n<input type=hidden name=entry3 value=0><input type=hidden name=matrixid3 value=0><input type=hidden name=entry3num value=0>\r\n<input type=hidden name=entry4 value=0><input type=hidden name=matrixid4 value=0><input type=hidden name=entry4num value=0>\r\n<input type=hidden name=entry5 value=0><input type=hidden name=matrixid5 value=0><input type=hidden name=entry5num value=0>\r\n<input type=hidden name=textcreditscycle value=0>\r\n<input type=hidden name=bannercreditscycle value=0>\r\n<input type=hidden name=cyclemail value=0>\r\n<input type=hidden name=cyclemailsponsor value=0>\r\n<input type=hidden name=level1m value=0>\r\n<input type=hidden name=level2m value=0>\r\n<input type=hidden name=level3m value=0>\r\n<input type=hidden name=level4m value=0>\r\n<input type=hidden name=level5m value=0>\r\n<input type=hidden name=level6m value=0>\r\n<input type=hidden name=level7m value=0>\r\n<input type=hidden name=level8m value=0>\r\n<input type=hidden name=level9m value=0>\r\n<input type=hidden name=level10m value=0>\r\n\r\n<tr><td colspan=2><font face=verdana size=2>\r\n<div align=center>\r\n<table border=1 width=400 cellspacing=0 cellpadding=0>\r\n<tr>\r\n<td width=50% align=center><font face=verdana size=2>Matrix Level</font></td>\r\n<td width=50% align=center><font face=verdana size=2>Matrix Bonus</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 1</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level1 size=5 value=\"" . $arr["9"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 2</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level2 size=5 value=\"" . $arr["10"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 3</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level3 size=5 value=\"" . $arr["11"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 4</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level4 size=5 value=\"" . $arr["12"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 5</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level5 size=5 value=\"" . $arr["13"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 6</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level6 size=5 value=\"" . $arr["14"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 7</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level7 size=5 value=\"" . $arr["15"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 8</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level8 size=5 value=\"" . $arr["16"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 9</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level9 size=5 value=\"" . $arr["17"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n<tr>\r\n<td align=center><font face=verdana size=2>Level 10</font></td>\r\n<td align=center><font face=verdana size=2>\$<input type=text name=level10 size=5 value=\"" . $arr["18"] . "\"> ( ie. \$2 )</font></td>\r\n</tr>\r\n</table>\r\n</b></font></td></tr>\r\n<tr><td colspan=2>&nbsp;</td></tr>\r\n\r\n<tr><td colspan=2><font face=verdana size=2>Bonus Credits on purchasing entry to this matrix or entering this matrix by cycling of any position.</font></td></tr>\r\n\r\n<tr><td><font face=verdana size=2><b>Text Ad Credits:</b></td><td><font face=verdana size=2><input type=text name=textcreditsentry value=\"" . $arr["49"] . "\"> (ie 500)</td></tr>\r\n<tr><td><font face=verdana size=2><b>Banner Ad Credits:</b></td><td><font face=verdana size=2><input type=text name=bannercreditsentry value=\"" . $arr["50"] . "\"> (ie 500)</td></tr>\r\n\r\n";
                                                                                                            echo "<tr><td colspan=2>&nbsp;</td></tr>\r\n\r\n<tr><td valign=top><font face=verdana size=2><b>Bonus Downloads:</b></td><td><textarea name=bonusdownloads cols=60 rows=10>" . stripslashes($arr[82]) . "" . "</textarea></td></tr>\r\n\r\n<Tr><td colspan=2><font face=verdana size=2>Change the email contents if you wants.<br><br>\r\nYou can use the following tags for personalized mailing and these will automatically get replaced by user information.<br><br>\r\n{name} for Name of the member<br>\r\n{id} for Matrix ID of the member<br>\r\n{username} for username of the member<br>\r\n{password} for the password of the member<br>\r\n{email} for the Email Address of the member<br>\r\n{sitename} for your sitename like " . $sitename . "<br>\r\n{siteurl} for your website url like " . $siteurl . "<br><br>\r\nNote: If you are using <b>Email Format</b> as <b>HTML</b> then you need to type the complete message in HTML format only.</font></td></tr>";
                                                                                                            echo "<tr><td colspan=2><font face=verdana size=2>If you want to send an welcome email to member to notify them that they have got a entry in this matrix then select <b>Yes</b> in Send Welcome Email option otherwise select <b>No</b>.</font></td></tr>\r\n\r\n<tr><td><font face=verdana size=2><b>Send Welcome Email</b></font></td><td><select name=welcomemail>";
                                                                                                            if( $arr[70] == 1 ) 
                                                                                                            {
                                                                                                                echo "<option value=0>No</option>\r\n<option value=1 selected>Yes</option>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                echo "<option value=0 selected>No</option>\r\n<option value=1>Yes</option>";
                                                                                                            }

                                                                                                            echo "</select></td></tr>\r\n\r\n<tr><Td colspan=2><font face=verdana size=2><b>Welcome Email:</b></font><br>\r\n\r\n<table border=0>\r\n<tr><td><font face=verdana size=2><b>Subject:</b></font></td><td align=left><input type=text name=subject1 value=\"" . stripslashes($arr[71]) . "\"></td></tr>\r\n\r\n<tr><Td><font face=verdana size=2><b>Email Format:</b></font></td><td><select name=eformat1>";
                                                                                                            if( $arr[73] == 1 ) 
                                                                                                            {
                                                                                                                print "<option value=1 selected>Text</option>\r\n<option value=2>HTML</option>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                print "<option value=1>Text</option>\r\n<option value=2 selected>HTML</option>";
                                                                                                            }

                                                                                                            echo "</select></td></tr>\r\n\r\n<tr><td valign=top><font face=verdana size=2><b>Message:</b></font></td><td><textarea name=message1 cols=60 rows=10>" . stripslashes($arr[72]) . "</textarea></td></tr>\r\n</table>\r\n\r\n</td></tr>";
                                                                                                            print "" . "<tr><Td colspan=2><input type=hidden name=id value=" . $arr["0"] . "><input type=hidden name=id1 value=1><input type=Submit     style=\"color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border:       1px ridge #000000; background-color: B0D8DD\" name=\"b\" value=\"Edit Matrix Details\"></td></tr></table></form>";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        $b = $id;
                                                                                                        $sql = "" . "update membershiplevels set Name='" . $_POST["name"] . "',fee='" . $_POST["fee"] . "',matrixtype='" . $_POST["matrixtype"] . "',levels='" . $_POST["levels"] . "',forcedmatrix='" . $_POST["forcedmatrix"] . "',payouttype='" . $_POST["payouttype"] . "',matrixbonus='" . $_POST["matrixbonus"] . "',matchingbonus='" . $_POST["matchingbonus"] . "',Level1='" . $_POST["level1"] . "',Level2='" . $_POST["level2"] . "',Level3='" . $_POST["level3"] . "',Level4='" . $_POST["level4"] . "',Level5='" . $_POST["level5"] . "',Level6='" . $_POST["level6"] . "',Level7='" . $_POST["level7"] . "',Level8='" . $_POST["level8"] . "',Level9='" . $_POST["level9"] . "',Level10='" . $_POST["level10"] . "',Level1m='" . $_POST["level1m"] . "',Level2m='" . $_POST["level2m"] . "',Level3m='" . $_POST["level3m"] . "',Level4m='" . $_POST["level4m"] . "',Level5m='" . $_POST["level5m"] . "',Level6m='" . $_POST["level6m"] . "',Level7m='" . $_POST["level7m"] . "',Level8m='" . $_POST["level8m"] . "',Level9m='" . $_POST["level9m"] . "',Level10m='" . $_POST["level10m"] . "',Level1c='" . $_POST["level1c"] . "',Level2c='" . $_POST["level2c"] . "',Level3c='" . $_POST["level3c"] . "',Level4c='" . $_POST["level4c"] . "',Level5c='" . $_POST["level5c"] . "',Level6c='" . $_POST["level6c"] . "',Level7c='" . $_POST["level7c"] . "',Level8c='" . $_POST["level8c"] . "',Level9c='" . $_POST["level9c"] . "',Level10c='" . $_POST["level10c"] . "',Level1cm='" . $_POST["level1cm"] . "',Level2cm='" . $_POST["level2cm"] . "',Level3cm='" . $_POST["level3cm"] . "',Level4cm='" . $_POST["level4cm"] . "',Level5cm='" . $_POST["level5cm"] . "',Level6cm='" . $_POST["level6cm"] . "',Level7cm='" . $_POST["level7cm"] . "',Level8cm='" . $_POST["level8cm"] . "',Level9cm='" . $_POST["level9cm"] . "',Level10cm='" . $_POST["level10cm"] . "',textcreditsentry='" . $_POST["textcreditsentry"] . "',bannercreditsentry='" . $_POST["bannercreditsentry"] . "',textcreditscycle='" . $_POST["textcreditscycle"] . "',bannercreditscycle='" . $_POST["bannercreditscycle"] . "',reentry='" . $_POST["reentry"] . "',reentrynum='" . $_POST["reentrynum"] . "',entry1='" . $_POST["entry1"] . "',entry1num='" . $_POST["entry1num"] . "',matrixid1='" . $_POST["matrixid1"] . "',entry2='" . $_POST["entry2"] . "',entry2num='" . $_POST["entry2num"] . "',matrixid2='" . $_POST["matrixid2"] . "',entry3='" . $_POST["entry3"] . "',entry3num='" . $_POST["entry3num"] . "',matrixid3='" . $_POST["matrixid3"] . "',entry4='" . $_POST["entry4"] . "',entry4num='" . $_POST["entry4num"] . "',matrixid4='" . $_POST["matrixid4"] . "',entry5='" . $_POST["entry5"] . "',entry5num='" . $_POST["entry5num"] . "',matrixid5='" . $_POST["matrixid5"] . "',welcomemail='" . $_POST["welcomemail"] . "',eformat1='" . $_POST["eformat1"] . "',cyclemail='" . $_POST["cyclemail"] . "',eformat2='" . $_POST["eformat2"] . "',cyclemailsponsor='" . $_POST["cyclemailsponsor"] . "',eformat3='" . $_POST["eformat3"] . "',refbonus='" . $_POST["refbonus"] . "',refbonuspaid='" . $_POST["refbonuspaid"] . "' where ID=" . $id;
                                                                                                        mysql_query($sql);
                                                                                                        $bonusdownloads = addslashes($_POST[bonusdownloads]);
                                                                                                        mysql_query("" . "update membershiplevels set bonusdownloads='" . $bonusdownloads . "' where ID=" . $b);
                                                                                                        $subject1 = addslashes($_POST[subject1]);
                                                                                                        mysql_query("" . "update membershiplevels set Subject1='" . $subject1 . "' where ID=" . $b);
                                                                                                        $message1 = addslashes($_POST[message1]);
                                                                                                        mysql_query("" . "update membershiplevels set Message1='" . $message1 . "' where ID=" . $b);
                                                                                                        print "<br><br><b>Records Successfully updated</b><br>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( $b == "Delete Matrix" ) 
                                                                                                    {
                                                                                                        $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $id);
                                                                                                        $arrm = mysql_fetch_array($rsm);
                                                                                                        echo "" . "<form action='' method=post><input type=hidden name=id value=" . $_POST["id"] . "><br><b>Are you sure you want to delete the matrix with Matrix: " . $arrm["1"] . "?<br>Deleting the matrix will also remove all the members details.<br>\r\n<input type=submit name=b value='Confirm Delete Matrix'></form>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( $b == "Confirm Delete Matrix" ) 
                                                                                                    {
                                                                                                        $id = $_POST[id];
                                                                                                        $rs = mysql_query("delete from membershiplevels where ID=" . $id);
                                                                                                        $rs = mysql_query("delete from transaction where matrixid=" . $id);
                                                                                                        $rs = mysql_query("delete from gifts where matrixid=" . $id);
                                                                                                        mysql_query("" . "drop table matrix" . $id);
                                                                                                        print "<br><b>Record Successfully Deleted";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == 5 ) 
                                                                                                    {
                                                                                                        $mid = (int) $_GET[mid];
                                                                                                        $tablee = "" . "matrix" . $mid;
                                                                                                        $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
                                                                                                        $arrm = mysql_fetch_array($rsm);
                                                                                                        $mname = $arrm[1];
                                                                                                        $fee = $arrm[2];
                                                                                                        $matrixtype = $arrm[3];
                                                                                                        $levels = $arrm[4];
                                                                                                        $forcedmatrix = $arrm[5];
                                                                                                        echo "" . "<h2 align=center>" . $mname . " Details</h2>";
                                                                                                        $step = 50;
                                                                                                        $currentpage = $p;
                                                                                                        $sql = "" . "Select * from " . $tablee . " order by ID";
                                                                                                        if( !($rs = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        $row = mysql_num_rows($rs);
                                                                                                        $totallinks = $row;
                                                                                                        if( !isset($currentpage) ) 
                                                                                                        {
                                                                                                            $currentpage = 1;
                                                                                                        }

                                                                                                        if( 0 < $totallinks ) 
                                                                                                        {
                                                                                                            if( $totallinks < 50 ) 
                                                                                                            {
                                                                                                                echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                if( $totallinks < $currentpage * 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                }

                                                                                                            }

                                                                                                        }

                                                                                                        if( $step < $totallinks ) 
                                                                                                        {
                                                                                                            $pagecount = ceil($totallinks / $step);
                                                                                                            print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                            for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                            {
                                                                                                                if( $pageno == $i ) 
                                                                                                                {
                                                                                                                    echo $i . " ";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "" . "<a href='admin.php?mid=" . $mid . "&b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><br><br>";
                                                                                                        }

                                                                                                        $start = ($currentpage - 1) * $step;
                                                                                                        $query = "" . "Select * from " . $tablee . " order by ID";
                                                                                                        $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                        if( !($result = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=70><font face=verdana size=2><b>#</b></font></td><td align=center valign=center><font face=verdana size=2><b>Username</b></font></td><td align=center valign=center><font face=verdana size=2><b>Sponsor</b></font></td><td align=center valign=center><font face=verdana size=2><b>Matrix Upline</b></font></td>";
                                                                                                        for( $i = 1; $i <= $levels; $i++ ) 
                                                                                                        {
                                                                                                            echo "" . "<td align=center><font face=verdana size=2><b>Level" . $i . "</b></font></td>";
                                                                                                        }
                                                                                                        echo "<td width=70 align=center><font face=verdana size=2><b>Total Earned</b></font></td><td align=center><font face=verdana size=2><b>Purchased Date</b></font></td><td align=center><font face=verdana size=2><b>Activation Date</b></font></td><td align=center><font face=verdana size=2><b>Action</b></font></td></tr>";
                                                                                                        while( $rss = mysql_fetch_row($result) ) 
                                                                                                        {
                                                                                                            if( $rss[16] == $rss[18] ) 
                                                                                                            {
                                                                                                                $cycled = "Not yet";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                $cycled = "" . $rss["18"];
                                                                                                            }

                                                                                                            echo "<tr><td align=center><font face=verdana size=2>" . $rss[0] . "</font></td><td align=center><font face=verdana size=2>" . $rss[1] . "</font></td><td align=center><font face=verdana size=2>" . $rss[2] . "</font></td><td align=center><font face=verdana size=2>" . $rss[3] . "</font></td>";
                                                                                                            for( $i = 1; $i <= $levels; $i++ ) 
                                                                                                            {
                                                                                                                echo "<td align=center><font face=verdana size=2>" . $rss[3 + $i] . "</font></td>";
                                                                                                            }
                                                                                                            echo "" . "<td align=center><font face=verdana size=2>\$" . $rss[15] . "</font></td><td align=center><font face=verdana size=2>" . $rss[16] . "</font></td><td align=center><font face=verdana size=2>" . $cycled . "" . "</font></td><td align=center><form action=admin.php method=post><input type=hidden name=id value=" . $rss["0"] . "><input type=hidden name=mid value=" . $mid . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Position'></form></td></tr>";
                                                                                                        }
                                                                                                        echo "</table>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( $b == "Delete Position" ) 
                                                                                                    {
                                                                                                        echo "" . "<form action='' method=post><input type=hidden name=id value=" . $_POST["id"] . "><input type=hidden name=mid value=" . $_POST["mid"] . "><br><b>Are you sure you want to delete the position with Matrix ID: " . $id . "?<br>Deleting this position will change the ownership of this position to admin in order to avoid creating holes.<br>\r\n<input type=submit name=b value='Confirm Delete Position'></form>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( $b == "Confirm Delete Position" ) 
                                                                                                    {
                                                                                                        $id = $_POST[id];
                                                                                                        $mid = $_POST[mid];
                                                                                                        mysql_query("" . "update matrix" . $mid . " set Username='admin' where ID=" . $id);
                                                                                                        echo "<br><b>Matrix Position Successfully deleted from member account.</b><br>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == 4 ) 
                                                                                                    {
                                                                                                        echo "<h2 align=center>Pending Transactions</h2><br><b>Note:</b>These are the transactions which hadn't got completed due to any of these reasons.<br>\r\n1. User had send the money but payment hadn't got approved automatically.<br>\r\n2. User hadn't paid the money, if you hadn't received the payment then just delete this transaction<br>\r\n<b>Please Note:</b> All Transactions that are pending for more than 3 days are automatically deleted from database.<br>";
                                                                                                        $step = 50;
                                                                                                        $currentpage = $p;
                                                                                                        $sql = "Select * from transaction order by ID";
                                                                                                        if( !($rs = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        $row = mysql_num_rows($rs);
                                                                                                        $totallinks = $row;
                                                                                                        if( !isset($currentpage) ) 
                                                                                                        {
                                                                                                            $currentpage = 1;
                                                                                                        }

                                                                                                        if( 0 < $totallinks ) 
                                                                                                        {
                                                                                                            if( $totallinks < 50 ) 
                                                                                                            {
                                                                                                                echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                if( $totallinks < $currentpage * 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                }

                                                                                                            }

                                                                                                        }

                                                                                                        if( $step < $totallinks ) 
                                                                                                        {
                                                                                                            $pagecount = ceil($totallinks / $step);
                                                                                                            print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                            for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                            {
                                                                                                                if( $pageno == $i ) 
                                                                                                                {
                                                                                                                    echo $i . " ";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><br><br>";
                                                                                                        }

                                                                                                        $start = ($currentpage - 1) * $step;
                                                                                                        $query = "Select * from transaction order by ID";
                                                                                                        $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                        if( !($result = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><font face=verdana size=2><b>ID.</b></font></td><td align=center><font face=verdana size=2><b>Username</b></font></td><td align=center valign=center><font face=verdana size=2><b>PaymentMode</b></font></td><td align=center valign=center><font face=verdana size=2><b>Gift Details</b></font></td><td width=70 align=center><font face=verdana size=2><b>Matrix</b></font></td><td width=70 align=center><font face=verdana size=2><b>Date</b></font></td><td width=70 align=center><font face=verdana size=2><b>Action</b></font></td></tr>";
                                                                                                        while( $rs = mysql_fetch_row($result) ) 
                                                                                                        {
                                                                                                            $rsm = mysql_query("" . "select ID,Name,fee from membershiplevels where ID=" . $rs["3"]);
                                                                                                            $arrm = mysql_fetch_array($rsm);
                                                                                                            $rsg = mysql_query("" . "select * from gifts where posid=" . $rs["6"]);
                                                                                                            if( 0 < mysql_num_rows($rsg) ) 
                                                                                                            {
                                                                                                                $arrg = mysql_fetch_array($rsg);
                                                                                                                $giftd = "" . $arrg["2"] . " ( " . $rs["5"] . " )";
                                                                                                            }

                                                                                                            echo "<tr><td align=center><font face=verdana size=2>" . $rs[0] . "</font></td><Td align=center><font face=verdana size=2>" . $rs[1] . "</font></td><Td align=center><font face=verdana size=2>" . $rs[2] . "" . " ( " . $rs["7"] . " )</font></td><Td align=center><font face=verdana size=2>" . $giftd . "</font></td><Td align=center><font face=verdana size=2>" . $arrm["1"] . " ( \$" . $arrm["2"] . " )<br>( ID: " . $rs["6"] . " )</font></td><Td align=center><font face=verdana size=2>" . $rs[4] . "" . " </font></td><td align=center><form action=admin.php method=post><input type=hidden name=id value=" . $rs["0"] . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='ApproveT'> &nbsp; <input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='DeleteT'></form></td></tr>";
                                                                                                        }
                                                                                                        echo "</table>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == 74 ) 
                                                                                                    {
                                                                                                        echo "<h2 align=center>Pending Gifts</h2>";
                                                                                                        $step = 50;
                                                                                                        $currentpage = $p;
                                                                                                        $sql = "Select * from gifts where approved=0 order by ID";
                                                                                                        if( !($rs = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        $row = mysql_num_rows($rs);
                                                                                                        $totallinks = $row;
                                                                                                        if( !isset($currentpage) ) 
                                                                                                        {
                                                                                                            $currentpage = 1;
                                                                                                        }

                                                                                                        if( 0 < $totallinks ) 
                                                                                                        {
                                                                                                            if( $totallinks < 50 ) 
                                                                                                            {
                                                                                                                echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                if( $totallinks < $currentpage * 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                }

                                                                                                            }

                                                                                                        }

                                                                                                        if( $step < $totallinks ) 
                                                                                                        {
                                                                                                            $pagecount = ceil($totallinks / $step);
                                                                                                            print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                            for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                            {
                                                                                                                if( $pageno == $i ) 
                                                                                                                {
                                                                                                                    echo $i . " ";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><br><br>";
                                                                                                        }

                                                                                                        $start = ($currentpage - 1) * $step;
                                                                                                        $query = "Select * from gifts where approved=0 order by ID";
                                                                                                        $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                        if( !($result = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><font face=verdana size=2><b>ID.</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>From</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>To</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Payment Details</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Amount</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Matrix</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Date</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Action</b></font></td></tr>";
                                                                                                        while( $rs = mysql_fetch_row($result) ) 
                                                                                                        {
                                                                                                            $rsm = mysql_query("" . "select ID,Name,fee from membershiplevels where ID=" . $rs["6"]);
                                                                                                            $arrm = mysql_fetch_array($rsm);
                                                                                                            echo "<tr><td align=center><font face=verdana size=2>" . $rs[0] . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[1] . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[2] . "" . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs["3"] . " ( " . $rs["4"] . " )</font></td>\r\n\t  <Td align=center><font face=verdana size=2>\$" . $rs[5] . "" . " </font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $arrm["1"] . " ( \$" . $arrm["2"] . " )<br>( ID: " . $rs["7"] . " )</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[9] . "" . " </font></td>\r\n\t  <td align=center><form action=admin.php method=post><input type=hidden name=id value=" . $rs["0"] . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='ApproveGift'> &nbsp; <input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='DeleteGift'></form></td></tr>";
                                                                                                        }
                                                                                                        echo "</table>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == 75 ) 
                                                                                                    {
                                                                                                        echo "<h2 align=center>Approved Gifts</h2>";
                                                                                                        $step = 50;
                                                                                                        $currentpage = $p;
                                                                                                        $sql = "Select * from gifts where approved=1 order by ID";
                                                                                                        if( !($rs = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        $row = mysql_num_rows($rs);
                                                                                                        $totallinks = $row;
                                                                                                        if( !isset($currentpage) ) 
                                                                                                        {
                                                                                                            $currentpage = 1;
                                                                                                        }

                                                                                                        if( 0 < $totallinks ) 
                                                                                                        {
                                                                                                            if( $totallinks < 50 ) 
                                                                                                            {
                                                                                                                echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                if( $totallinks < $currentpage * 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                }

                                                                                                            }

                                                                                                        }

                                                                                                        if( $step < $totallinks ) 
                                                                                                        {
                                                                                                            $pagecount = ceil($totallinks / $step);
                                                                                                            print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                            for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                            {
                                                                                                                if( $pageno == $i ) 
                                                                                                                {
                                                                                                                    echo $i . " ";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><br><br>";
                                                                                                        }

                                                                                                        $start = ($currentpage - 1) * $step;
                                                                                                        $query = "Select * from gifts where approved=1 order by ID";
                                                                                                        $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                        if( !($result = mysql_query($sql)) ) 
                                                                                                        {
                                                                                                            mysql_error();
                                                                                                            print mysql_error();
                                                                                                            exit();
                                                                                                        }

                                                                                                        echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><font face=verdana size=2><b>ID.</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>From</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>To</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Payment Details</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Amount</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Matrix</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Date</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Approval Date</b></font></td>\r\n\t<td align=center><font face=verdana size=2><b>Action</b></font></td></tr>";
                                                                                                        while( $rs = mysql_fetch_row($result) ) 
                                                                                                        {
                                                                                                            $rsm = mysql_query("" . "select ID,Name,fee from membershiplevels where ID=" . $rs["6"]);
                                                                                                            $arrm = mysql_fetch_array($rsm);
                                                                                                            echo "<tr><td align=center><font face=verdana size=2>" . $rs[0] . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[1] . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[2] . "" . "</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs["3"] . " ( " . $rs["4"] . " )</font></td>\r\n\t  <Td align=center><font face=verdana size=2>\$" . $rs[5] . "" . " </font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $arrm["1"] . " ( \$" . $arrm["2"] . " )<br>( ID: " . $rs["7"] . " )</font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[9] . " </font></td>\r\n\t  <Td align=center><font face=verdana size=2>" . $rs[10] . "" . " </font></td>\r\n\t  <td align=center><form action=admin.php method=post><input type=hidden name=id value=" . $rs["0"] . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='DeleteGift'></form></td></tr>";
                                                                                                        }
                                                                                                        echo "</table>";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == "DeleteGift" ) 
                                                                                                    {
                                                                                                        $sql = "select * from gifts where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql);
                                                                                                        $arr = mysql_fetch_array($rs);
                                                                                                        $rsuser = mysql_query("" . "select * from transaction where posid=" . $arr["7"]);
                                                                                                        if( 0 < mysql_num_rows($rsuser) ) 
                                                                                                        {
                                                                                                            $arruser = mysql_fetch_array($rsuser);
                                                                                                            $user = $arruser[1];
                                                                                                            $tablee = "" . "matrix" . $arruser["3"];
                                                                                                            $acountid = $arruser[6];
                                                                                                            $refid = $arruser[5];
                                                                                                            $rsmu = mysql_query("" . "select ref_by from " . $tablee . " where ID=" . $acountid);
                                                                                                            if( 0 < mysql_num_rows($rsmu) ) 
                                                                                                            {
                                                                                                                $arrmu = mysql_fetch_array($rsmu);
                                                                                                                $refid = $arrmu[0];
                                                                                                            }

                                                                                                            assignreferralss($acountid, $refid, 1, 1, $arruser[3]);
                                                                                                            mysql_query("" . "delete from " . $tablee . " where ID=" . $arruser["6"]);
                                                                                                            mysql_query("" . "delete from gifts where posid=" . $arruser["6"]);
                                                                                                            mysql_query("" . "delete from transaction where ID=" . $arruser["0"]);
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            $user = $arr[1];
                                                                                                            $tablee = "" . "matrix" . $arr["6"];
                                                                                                            $acountid = $arr[7];
                                                                                                            $refid = 0;
                                                                                                            $rsmu = mysql_query("" . "select ref_by from " . $tablee . " where ID=" . $acountid);
                                                                                                            if( 0 < mysql_num_rows($rsmu) ) 
                                                                                                            {
                                                                                                                $arrmu = mysql_fetch_array($rsmu);
                                                                                                                $refid = $arrmu[0];
                                                                                                            }

                                                                                                            assignreferralss($acountid, $refid, 1, 1, $arruser[3]);
                                                                                                            mysql_query("" . "delete from " . $tablee . " where ID=" . $arr["7"]);
                                                                                                            mysql_query("" . "delete from gifts where ID=" . $arr["0"]);
                                                                                                        }

                                                                                                        echo "<br><b>Gift Successfully Deleted";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == "ApproveGift" ) 
                                                                                                    {
                                                                                                        $sql = "select * from gifts where ID=" . $_POST[id];
                                                                                                        $rs = mysql_query($sql);
                                                                                                        $arr = mysql_fetch_array($rs);
                                                                                                        $rsuser = mysql_query("" . "select * from transaction where posid=" . $arr["7"]);
                                                                                                        if( 0 < mysql_num_rows($rs) ) 
                                                                                                        {
                                                                                                            $arruser = mysql_fetch_array($rsuser);
                                                                                                            $user = $arruser[1];
                                                                                                            $tablee = "" . "matrix" . $arruser["3"];
                                                                                                            $mid = $arruser[3];
                                                                                                            $acountid = $arruser[6];
                                                                                                            $refid = $arruser[5];
                                                                                                            $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
                                                                                                            $arrm = mysql_fetch_array($rsm);
                                                                                                            $textcreditsentry = $arrm[49];
                                                                                                            $bannercreditsentry = $arrm[50];
                                                                                                            $welcomemail = $arrm[70];
                                                                                                            if( $welcomemail == 1 ) 
                                                                                                            {
                                                                                                                matrixmail($acountid, $user, $mid, 1);
                                                                                                            }

                                                                                                            $today = date("Y-m-d H:i:s", mktime(date("H"), date("i"), date("s"), date("m"), date("d"), date("Y")));
                                                                                                            mysql_query("" . "update " . $tablee . " set CDate='" . $today . "' where ID=" . $arruser["6"]);
                                                                                                            mysql_query("" . "update gifts set ADate='" . $today . "',approved=1 where posid=" . $arruser["6"]);
                                                                                                            mysql_query("" . "update users set banners=banners+" . $bannercreditsentry . ",textads=textads+" . $textcreditsentry . ",status=2 where Username='" . $user . "'");
                                                                                                            $acountid = $arruser[6];
                                                                                                            $refid = $arruser[5];
                                                                                                            $rsmu = mysql_query("" . "select ref_by from " . $tablee . " where ID=" . $acountid);
                                                                                                            if( 0 < mysql_num_rows($rsmu) ) 
                                                                                                            {
                                                                                                                $arrmu = mysql_fetch_array($rsmu);
                                                                                                                $refid = $arrmu[0];
                                                                                                            }

                                                                                                            rassignreferrals($acountid, $refid, 1, 1, $arruser[3]);
                                                                                                            mysql_query("" . "delete from transaction where ID=" . $arruser["0"]);
                                                                                                            echo "<b><br>Gift successfully approved.</b><br>";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        echo "<b><br>This Gift has already been approved";
                                                                                                        return NULL;
                                                                                                    }

                                                                                                    if( trim($b) == 3 ) 
                                                                                                    {
                                                                                                        $act = $_GET[act];
                                                                                                        if( trim($act) != "send" ) 
                                                                                                        {
                                                                                                            echo "<b><p align=left style='font-size: 150%; font-family: '>E-mail Users</p></b><form action='admin.php?b=3&act=send' method=post><font face=verdana size=2>You can use the following tags for personalized mailing and these will automatically get replaced by user information.<br><br>{fname} for First Name of the member<br>{name} for Full Name of the member<br>{username} for username of the member<br>{password} for the password of the member<br>{email} for the Email Address of the member<br>{ip} for the IP Address recorded at the time of joining of the member<br>{date} for Date of Joining of the member<br>{sponsor} for the Sponsor Username of the member<br><p align=left><table border=0><tr><td align=right valign=top>Subject:</td><td align=left><input type=text name=subject></td></tr>";
                                                                                                            echo "" . "<tr><td align=right valign=top>Category:</td><td align=left><Select name='cat'><option Value='1'>All Members<option value=2>" . $mtext . "<option value=3>Pro Members</select></td></tr>";
                                                                                                            echo "<tr><td align=right valign=top>Format:</td><td align=left><Select name='format'><option Value='0'>Text<option value=1 selected>HTML</select></td></tr><tr><td align=right valign=top>Message:</td><td align=left><textarea name=message cols=60 rows=10></textarea></td></tr><tr><td colspan=2 align=center valign=top><br><input type=submit value='Send Mail' style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD'></td></tr></form></table></p>";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($act) == "send" ) 
                                                                                                        {
                                                                                                            $subject = $_POST[subject];
                                                                                                            $format = $_POST[format];
                                                                                                            $message = $_POST[message];
                                                                                                            $cat = $_POST[cat];
                                                                                                            $users = "";
                                                                                                            $usercount = 0;
                                                                                                            if( $cat == 1 ) 
                                                                                                            {
                                                                                                                $sql_rc = "select count(*) from users where active=1 and subscribed=1";
                                                                                                                $sql = "select Email,ref_by,Name,Username,Password,ID,IP,Date from users where active=1 and subscribed=1 order by ID";
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                if( $cat == 2 ) 
                                                                                                                {
                                                                                                                    $sql_rc = "select count(*) from users where active=1 and status=1";
                                                                                                                    $sql = "select Email,ref_by,Name,Username,Password,ID,IP,Date from users where active=1 and subscribed=1 and status=1 order by ID";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    if( $cat == 3 ) 
                                                                                                                    {
                                                                                                                        $sql_rc = "select count(*) from users where active=1 and status=2";
                                                                                                                        $sql = "select Email,ref_by,Name,Username,Password,ID,IP,Date from users where active=1 and subscribed=1 and status=2 order by ID";
                                                                                                                    }

                                                                                                                }

                                                                                                            }

                                                                                                            $result_rc = mysql_query($sql_rc);
                                                                                                            $rscount_rc = mysql_fetch_row($result_rc);
                                                                                                            $totalm = $rscount_rc[0];
                                                                                                            $result = mysql_query($sql);
                                                                                                            while( $rs = mysql_fetch_row($result) ) 
                                                                                                            {
                                                                                                                $d = explode(" ", $rs[2]);
                                                                                                                $subject1 = stripslashes($_POST[subject]);
                                                                                                                $subject1 = str_replace("{name}", $rs[2], $subject1);
                                                                                                                $subject1 = str_replace("{fname}", $d[0], $subject1);
                                                                                                                $subject1 = str_replace("{username}", $rs[3], $subject1);
                                                                                                                $subject1 = str_replace("{password}", $rs[4], $subject1);
                                                                                                                $subject1 = str_replace("{sponsor}", $rs[1], $subject1);
                                                                                                                $subject1 = str_replace("{email}", $rs[0], $subject1);
                                                                                                                $subject1 = str_replace("{ip}", $rs[6], $subject1);
                                                                                                                $subject1 = str_replace("{date}", $rs[7], $subject1);
                                                                                                                $message1 = stripslashes($_POST[message]);
                                                                                                                $message1 = str_replace("{name}", $rs[2], $message1);
                                                                                                                $message1 = str_replace("{fname}", $d[0], $message1);
                                                                                                                $message1 = str_replace("{username}", $rs[3], $message1);
                                                                                                                $message1 = str_replace("{password}", $rs[4], $message1);
                                                                                                                $message1 = str_replace("{sponsor}", $rs[1], $message1);
                                                                                                                $message1 = str_replace("{email}", $rs[0], $message1);
                                                                                                                $message1 = str_replace("{ip}", $rs[6], $message1);
                                                                                                                $message1 = str_replace("{date}", $rs[7], $message1);
                                                                                                                if( $format == 1 ) 
                                                                                                                {
                                                                                                                    $message1 .= "" . "<hr>You are receiving this message because you are a member of " . $sitename . ".<br>If you would like to no longer wish receive any updates please click on this link: <a href=" . $siteurl . "/remove.php?id=" . $rs["5"] . "&email=" . $rs["0"] . ">" . $siteurl . "/remove.php?id=" . $rs["5"] . "&email=" . $rs["0"] . "</a><hr>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    $message1 .= "" . "\n*********************************************************\n\r\nYou are receiving this message because you are a member of " . $sitename . ".\n\r\nIf you would like to no longer wish receive any updates please click on this link: " . $siteurl . "/remove.php?id=" . $rs["5"] . "&email=" . $rs["0"] . "\n\r\n*********************************************************";
                                                                                                                }

                                                                                                                sendmail($webmasteremail, $rs[0], $subject1, $format, $message1);
                                                                                                                $usercount = $usercount + 1;
                                                                                                                echo $usercount . " . Message Successfully Send to :" . $rs[0] . "<br>";
                                                                                                            }
                                                                                                        }

                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        if( trim($b) == 210 ) 
                                                                                                        {
                                                                                                            $burl = str_replace("\"", "", $_POST[burl]);
                                                                                                            $burl = str_replace("'", "", $burl);
                                                                                                            $wurl = str_replace("\"", "", $_POST[wurl]);
                                                                                                            $wurl = str_replace("'", "", $wurl);
                                                                                                            if( $_POST[burl] ) 
                                                                                                            {
                                                                                                                $sql_i = "" . "insert into membersbanners(Username,BannerURL,WebsiteURL,assigned,remaining,hits,approved,Date) values('admin','" . $burl . "','" . $wurl . "'," . $_POST["credits"] . "," . $_POST["credits"] . ",0,1,now())";
                                                                                                                $rsi = mysql_query($sql_i);
                                                                                                                print "<p align='center'><font color='red'><b>Sucessfully added record and banner approved!</b></font></p><br><br>";
                                                                                                                return NULL;
                                                                                                            }

                                                                                                            echo "<p align=\"center\"><h2 align=\"center\">Add Banner</h2>\r\n<form method=\"post\" width=\"60%\" action=\"\" />\r\n<table border=\"0\" align=\"center\">\r\n<table>\r\n<tr><td><font face=verdana size=2>Banner Url:</td><td><input type=text name=burl value=\"http://\"></td></tr>\r\n<tr><td><font face=verdana size=2>Website Url:</td><td><input type=text name=wurl value=\"http://\"></td></tr>\r\n<tr><td><font face=verdana size=2>Assign Credits:</td><td><input type=text name=credits value=\"10000\"></td></tr>\r\n<tr><td colspan=2><input type=submit value=\"Add Record\"> </td></tr>\r\n</table>\r\n</form>\r\n";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == 211 ) 
                                                                                                        {
                                                                                                            echo "<h2 align=center>Approved Banners</h2>";
                                                                                                            $step = 50;
                                                                                                            $currentpage = $p;
                                                                                                            $sql = "Select * from membersbanners where approved=1 order by ID";
                                                                                                            if( !($rs = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            $row = mysql_num_rows($rs);
                                                                                                            $totallinks = $row;
                                                                                                            if( !isset($currentpage) ) 
                                                                                                            {
                                                                                                                $currentpage = 1;
                                                                                                            }

                                                                                                            if( 0 < $totallinks ) 
                                                                                                            {
                                                                                                                if( $totallinks < 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    if( $totallinks < $currentpage * 50 ) 
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                    }

                                                                                                                }

                                                                                                            }

                                                                                                            if( $step < $totallinks ) 
                                                                                                            {
                                                                                                                $pagecount = ceil($totallinks / $step);
                                                                                                                print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                                for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                                {
                                                                                                                    if( $pageno == $i ) 
                                                                                                                    {
                                                                                                                        echo $i . " ";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                    }

                                                                                                                }
                                                                                                                echo "<br><br><br>";
                                                                                                            }

                                                                                                            $start = ($currentpage - 1) * $step;
                                                                                                            $query = "Select * from membersbanners where approved=1 order by ID";
                                                                                                            $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                            if( !($result = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            if( 0 < mysql_num_rows($rs) ) 
                                                                                                            {
                                                                                                                echo "<br><form action=admin.php method=post name=maj><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>ID.</b></td><td align=center><b>Username</b></td><td width=486 align=center><b>Banner with Url</b></td><td width=70 align=center><b>Impressions Purchased</b></td><td width=70 align=center><b>Remaining</b></td><td width=70 align=center><b>Hits</b></td><td width=70 align=center><b>Date</b></td><td>Action</td></tr>";
                                                                                                                while( $rs = mysql_fetch_row($result) ) 
                                                                                                                {
                                                                                                                    echo "<tr><td align=center>" . $rs[0] . "</td><Td align=center>" . $rs[1] . "" . "</td><Td align=center><a href=" . $rs["3"] . " target=_blank><img src=" . $rs["2"] . " border=0></a></td><Td align=center>" . $rs["4"] . "</td><Td align=center>" . $rs["5"] . "</td><Td align=center>" . $rs["6"] . "</td><Td align=center>" . $rs["8"] . "</td><td><input type=checkbox name=id" . $rs[0] . "></td></tr>";
                                                                                                                }
                                                                                                                echo "<tr><td colspan=8 align=center><input name=allbox type=checkbox value=1 onClick=\"CheckAll();\">Select/Un-Select All\r\n<br>\r\n<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Edit Banner'> &nbsp; \r\n<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Remove'>\r\n</form></td></tr></table><script language=\"JavaScript\">\r\n   <!--\r\n   function CheckAll()\r\n   {\r\n      for (var i=0;i<document.maj.elements.length;i++)\r\n      {\r\n         var e = document.maj.elements[i];\r\n         if (e.name != \"allbox\")\r\n            e.checked = document.maj.allbox.checked;\r\n      }\r\n   }\r\n   //-->\r\n</script>\r\n";
                                                                                                                return NULL;
                                                                                                            }

                                                                                                            echo "<br><b>No Records Found</b><br>";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == 212 ) 
                                                                                                        {
                                                                                                            echo "<h2 align=center>Pending Banners</h2>";
                                                                                                            $step = 50;
                                                                                                            $currentpage = $p;
                                                                                                            $sql = "Select * from membersbanners where approved=0 order by ID";
                                                                                                            if( !($rs = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            $row = mysql_num_rows($rs);
                                                                                                            $totallinks = $row;
                                                                                                            if( !isset($currentpage) ) 
                                                                                                            {
                                                                                                                $currentpage = 1;
                                                                                                            }

                                                                                                            if( 0 < $totallinks ) 
                                                                                                            {
                                                                                                                if( $totallinks < 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    if( $totallinks < $currentpage * 50 ) 
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                    }

                                                                                                                }

                                                                                                            }

                                                                                                            if( $step < $totallinks ) 
                                                                                                            {
                                                                                                                $pagecount = ceil($totallinks / $step);
                                                                                                                print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                                for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                                {
                                                                                                                    if( $pageno == $i ) 
                                                                                                                    {
                                                                                                                        echo $i . " ";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                    }

                                                                                                                }
                                                                                                                echo "<br><br><br>";
                                                                                                            }

                                                                                                            $start = ($currentpage - 1) * $step;
                                                                                                            $query = "Select * from membersbanners where approved=0 order by ID";
                                                                                                            $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                            if( !($result = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            if( 0 < mysql_num_rows($rs) ) 
                                                                                                            {
                                                                                                                echo "<br><form name=maj action=admin.php method=post><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>ID.</b></td><td align=center><b>Username</b></td><td width=486 align=center><b>Banner with Url</b></td><td width=70 align=center><b>Impressions Purchased</b></td><td width=70 align=center><b>Remaining</b></td><td width=70 align=center><b>Hits</b></td><td width=70 align=center><b>Date</b></td><td align=center><b>Action</b></td></tr>";
                                                                                                                while( $rs = mysql_fetch_row($result) ) 
                                                                                                                {
                                                                                                                    echo "<tr><td align=center>" . $rs[0] . "</td><Td align=center>" . $rs[1] . "" . "</td><Td align=center><a href=" . $rs["3"] . " target=_blank><img src=" . $rs["2"] . " border=0></a></td><Td align=center>" . $rs["4"] . "</td><Td align=center>" . $rs["5"] . "</td><Td align=center>" . $rs["6"] . "</td><Td align=center>" . $rs["8"] . "</td><td><input type=checkbox name=id" . $rs[0] . "></td></tr>";
                                                                                                                }
                                                                                                                echo "<tr><td colspan=8 align=center><input name=allbox type=checkbox value=1 onClick=\"CheckAll();\">Select/Un-Select All\r\n<br>\r\n<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Approve Banner'> &nbsp; \r\n<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Edit Banner'> &nbsp; \r\n<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Remove'>\r\n</form></td></tr></table><script language=\"JavaScript\">\r\n   <!--\r\n   function CheckAll()\r\n   {\r\n      for (var i=0;i<document.maj.elements.length;i++)\r\n      {\r\n         var e = document.maj.elements[i];\r\n         if (e.name != \"allbox\")\r\n            e.checked = document.maj.allbox.checked;\r\n      }\r\n   }\r\n   //-->\r\n</script>\r\n";
                                                                                                                return NULL;
                                                                                                            }

                                                                                                            echo "<br><b>No Records Found</b><br>";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == "Approve Banner" ) 
                                                                                                        {
                                                                                                            foreach( $_POST as $k => $v ) 
                                                                                                            {
                                                                                                                $d = explode("id", $k);
                                                                                                                if( $d[1] != "" ) 
                                                                                                                {
                                                                                                                    $rs = mysql_query("" . "select * from membersbanners where ID=" . $d["1"]);
                                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                                    $id = $arr[0];
                                                                                                                    $sql_d = "Update membersbanners set approved=1 where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $sql_d = "select * from membersbanners where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $arr = mysql_fetch_array($rs_d);
                                                                                                                    $sql = "" . "select * from users where Username='" . $arr["1"] . "'";
                                                                                                                    $rs = mysql_query($sql);
                                                                                                                    $arr1 = mysql_fetch_array($rs);
                                                                                                                    $to = $arr1[7];
                                                                                                                    $message1 = $message6;
                                                                                                                    $message1 = str_replace("{name}", "" . $arr1["1"], $message1);
                                                                                                                    $message1 = str_replace("{email}", "" . $arr1["7"], $message1);
                                                                                                                    $message1 = str_replace("{username}", "" . $arr1["8"], $message1);
                                                                                                                    $message1 = str_replace("{password}", "" . $arr1["9"], $message1);
                                                                                                                    $message1 = str_replace("{banner}", "" . $arr["2"], $message1);
                                                                                                                    $message1 = str_replace("{websiteurl}", "" . $arr["3"], $message1);
                                                                                                                    $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                                    $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                                    $subject1 = str_replace("{name}", "" . $arr1["1"], $subject6);
                                                                                                                    $subject1 = str_replace("{email}", "" . $arr1["7"], $subject1);
                                                                                                                    $subject1 = str_replace("{username}", "" . $arr1["8"], $subject1);
                                                                                                                    $subject1 = str_replace("{password}", "" . $arr1["9"], $subject1);
                                                                                                                    $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                                    $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                                    $message = stripslashes($message1);
                                                                                                                    $subject = stripslashes($subject1);
                                                                                                                    $from = $webmasteremail;
                                                                                                                    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                                    if( $eformat6 == 1 ) 
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                                    }

                                                                                                                    $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                                    $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                                    $header .= "X-Mailer: PHP4\n";
                                                                                                                    $header .= "X-Priority: 3\n";
                                                                                                                    $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                                    mail($to, $subject, $message, $header);
                                                                                                                    echo "" . "<br><b>Banner with following details <a href=" . $arr["3"] . " target=_blank><img src=" . $arr["2"] . " border=0></a> has been successfully approved";
                                                                                                                }

                                                                                                            }
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( $b == "Remove" ) 
                                                                                                        {
                                                                                                            foreach( $_POST as $k => $v ) 
                                                                                                            {
                                                                                                                $d = explode("id", $k);
                                                                                                                if( $d[1] != "" ) 
                                                                                                                {
                                                                                                                    $rs = mysql_query("" . "select * from membersbanners where ID=" . $d["1"]);
                                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                                    $id = $arr[0];
                                                                                                                    $sql_d = "Update membersbanners set approved=2,assigned=assigned-remaining where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $sql_d = "select * from membersbanners where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $arr = mysql_fetch_array($rs_d);
                                                                                                                    $rem = $arr[5];
                                                                                                                    mysql_query("" . "update users set bannersused=bannersused-" . $rem . " where Username='" . $arr["1"] . "'");
                                                                                                                    $sql = "" . "select * from users where Username='" . $arr["1"] . "'";
                                                                                                                    $rs = mysql_query($sql);
                                                                                                                    $arr1 = mysql_fetch_array($rs);
                                                                                                                    $to = $arr1[7];
                                                                                                                    $message1 = $message7;
                                                                                                                    $message1 = str_replace("{name}", "" . $arr1["1"], $message1);
                                                                                                                    $message1 = str_replace("{email}", "" . $arr1["7"], $message1);
                                                                                                                    $message1 = str_replace("{username}", "" . $arr1["8"], $message1);
                                                                                                                    $message1 = str_replace("{password}", "" . $arr1["9"], $message1);
                                                                                                                    $message1 = str_replace("{banner}", "" . $arr["2"], $message1);
                                                                                                                    $message1 = str_replace("{websiteurl}", "" . $arr["3"], $message1);
                                                                                                                    $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                                    $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                                    $subject1 = str_replace("{name}", "" . $arr1["1"], $subject7);
                                                                                                                    $subject1 = str_replace("{email}", "" . $arr1["7"], $subject1);
                                                                                                                    $subject1 = str_replace("{username}", "" . $arr1["8"], $subject1);
                                                                                                                    $subject1 = str_replace("{password}", "" . $arr1["9"], $subject1);
                                                                                                                    $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                                    $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                                    $message = stripslashes($message1);
                                                                                                                    $subject = stripslashes($subject1);
                                                                                                                    $from = $webmasteremail;
                                                                                                                    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                                    if( $eformat7 == 1 ) 
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                                    }

                                                                                                                    $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                                    $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                                    $header .= "X-Mailer: PHP4\n";
                                                                                                                    $header .= "X-Priority: 3\n";
                                                                                                                    $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                                    mail($to, $subject, $message, $header);
                                                                                                                    echo "" . "<br><b>Banner with following details <a href=" . $arr["3"] . " target=_blank><img src=" . $arr["2"] . " border=0></a> has been successfully removed";
                                                                                                                }

                                                                                                            }
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == "Edit Banner" ) 
                                                                                                        {
                                                                                                            if( !$_POST[eb] == 1 ) 
                                                                                                            {
                                                                                                                echo "<form action=admin.php method=post><input type=hidden name=eb value=1>";
                                                                                                                foreach( $_POST as $k => $v ) 
                                                                                                                {
                                                                                                                    $d = explode("id", $k);
                                                                                                                    if( $d[1] != "" ) 
                                                                                                                    {
                                                                                                                        $rs = mysql_query("" . "select * from membersbanners where ID=" . $d["1"]);
                                                                                                                        $arr = mysql_fetch_array($rs);
                                                                                                                        $id = $arr[0];
                                                                                                                        echo "" . "<br>\r\nBanner Url : <input type=text name=burl" . $arr["0"] . " value=\"" . $arr["2"] . "\"><br>\r\nWebsite Url : <input type=text name=wurl" . $arr["0"] . " value=\"" . $arr["3"] . "\"><br>\r\nBanner Display: <A href=" . $arr["3"] . " target=_Blank><img src=" . $arr["2"] . " border=0></a>\r\n<br>";
                                                                                                                    }

                                                                                                                }
                                                                                                                echo "<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Edit Banner'></form>";
                                                                                                                return NULL;
                                                                                                            }

                                                                                                            foreach( $_POST as $k => $v ) 
                                                                                                            {
                                                                                                                $mailbody .= $k . " = " . $v . "\r\n";
                                                                                                            }
                                                                                                            $d = explode("\r\n", $mailbody);
                                                                                                            for( $i = 0; $i < count($d) - 1; $i++ ) 
                                                                                                            {
                                                                                                                $dataa = explode(" = ", $d[$i]);
                                                                                                                $dt = $dataa[0];
                                                                                                                $dataa[0] = eregi_replace("burl", "", $dataa[0]);
                                                                                                                $dataa[0] = eregi_replace("wurl", "", $dataa[0]);
                                                                                                                if( $dataa[0] == "b" || $dataa[0] == "eb" ) 
                                                                                                                {
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    $rs = mysql_query("select * from membersbanners where ID=" . $dataa[0]);
                                                                                                                    if( 0 < mysql_num_rows($rs) ) 
                                                                                                                    {
                                                                                                                        $ac = ereg("burl", $dt);
                                                                                                                        if( $ac == 0 ) 
                                                                                                                        {
                                                                                                                            $rss = mysql_query("" . "update membersbanners set WebsiteURL='" . $dataa["1"] . "' where ID=" . $dataa["0"]);
                                                                                                                        }
                                                                                                                        else
                                                                                                                        {
                                                                                                                            $rss = mysql_query("" . "update membersbanners set BannerURL='" . $dataa["1"] . "' where ID=" . $dataa["0"]);
                                                                                                                        }

                                                                                                                    }

                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><b>Records Successfully Updated</b><br>";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == 310 ) 
                                                                                                        {
                                                                                                            $a[1] = trim($_POST[burl]);
                                                                                                            $a[1] = addslashes($a[1]);
                                                                                                            $a[2] = trim($_POST[wurl]);
                                                                                                            $a[2] = str_replace("\"", "", $a[2]);
                                                                                                            $a[2] = str_replace("'", "", $a[2]);
                                                                                                            $textad = "" . $_POST["burl1"] . "<br>" . $_POST["burl2"] . "<br>" . $_POST["burl3"];
                                                                                                            $textad = addslashes($textad);
                                                                                                            $a[3] = trim($textad);
                                                                                                            if( $_POST[burl] ) 
                                                                                                            {
                                                                                                                $sql_i = "" . "insert into memberstextads(Username,Textad,WebsiteURL,assigned,remaining,hits,approved,Date,Textad1) values('admin','" . $a["1"] . "','" . $a["2"] . "'," . $_POST["credits"] . "," . $_POST["credits"] . ",0,0,now(),'" . $a["3"] . "')";
                                                                                                                $rsi = mysql_query($sql_i);
                                                                                                                print "<p align='center'><font color='red'><b>Sucessfully added record!</b></font></p><br><br>";
                                                                                                                return NULL;
                                                                                                            }

                                                                                                            echo "<p align=\"center\"><h2 align=\"center\">Add Text Ad</h2>\r\n<form method=\"post\" width=\"60%\" action=\"\" />\r\n<table border=\"0\" align=\"center\">\r\n<table>\r\n<tr><td><font face=verdana size=2>Subject:</td><td><input type=text name=burl maxlength=20 value=\"\"></td></tr>\r\n<tr><td><font face=verdana size=2>Line1 Text Ad:</td><td><input type=text name=burl1 maxlength=24 value=\"\"></td></tr>\r\n<tr><td><font face=verdana size=2>Line2 Text Ad:</td><td><input type=text name=burl2 maxlength=24 value=\"\"></td></tr>\r\n<tr><td><font face=verdana size=2>Line3 Text Ad:</td><td><input type=text name=burl3 maxlength=24 value=\"\"></td></tr>\r\n<tr><td><font face=verdana size=2>Website Url:</td><td><input type=text name=wurl value=\"http://\"></td></tr>\r\n<tr><td><font face=verdana size=2>Assign Credits:</td><td><input type=text name=credits value=\"1000\"></td></tr>\r\n<tr><td colspan=2><input type=submit value=\"Add Record\"> </td></tr>\r\n</table>\r\n</form>\r\n";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == 311 ) 
                                                                                                        {
                                                                                                            echo "<h2 align=center>Approved Text Ads</h2>";
                                                                                                            $step = 50;
                                                                                                            $currentpage = $p;
                                                                                                            $sql = "Select * from memberstextads where approved=1 order by ID";
                                                                                                            if( !($rs = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            $row = mysql_num_rows($rs);
                                                                                                            $totallinks = $row;
                                                                                                            if( !isset($currentpage) ) 
                                                                                                            {
                                                                                                                $currentpage = 1;
                                                                                                            }

                                                                                                            if( 0 < $totallinks ) 
                                                                                                            {
                                                                                                                if( $totallinks < 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    if( $totallinks < $currentpage * 50 ) 
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                    }

                                                                                                                }

                                                                                                            }

                                                                                                            if( $step < $totallinks ) 
                                                                                                            {
                                                                                                                $pagecount = ceil($totallinks / $step);
                                                                                                                print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                                for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                                {
                                                                                                                    if( $pageno == $i ) 
                                                                                                                    {
                                                                                                                        echo $i . " ";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                    }

                                                                                                                }
                                                                                                                echo "<br><br><br>";
                                                                                                            }

                                                                                                            $start = ($currentpage - 1) * $step;
                                                                                                            $query = "Select * from memberstextads where approved=1 order by ID";
                                                                                                            $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                            if( !($result = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            echo "<br><form action=admin.php method=post name=maj><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>ID.</b></td><td align=center><b>Member ID</b></td><td width=486 align=center><b>Text Ad</b></td><td width=70 align=center><b>Impressions Purchased</b></td><td width=70 align=center><b>Remaining</b></td><td width=70 align=center><b>Hits</b></td><td width=70 align=center><b>Date</b></td><td>Action</td></tr>";
                                                                                                            while( $rs = mysql_fetch_row($result) ) 
                                                                                                            {
                                                                                                                echo "<tr><td align=center>" . $rs[0] . "</td><Td align=center>" . $rs[1] . "" . "</td><Td align=center><a href=" . $rs["3"] . " target=_blank>" . stripslashes($rs[2]) . "</a><br>" . stripslashes($rs[9]) . "" . "</td><Td align=center>" . $rs["4"] . "</td><Td align=center>" . $rs["5"] . "</td><Td align=center>" . $rs["6"] . "</td><Td align=center>" . $rs["8"] . "</td><td><input type=checkbox name=id" . $rs[0] . "></td></tr>";
                                                                                                            }
                                                                                                            echo "<tr><td colspan=8 align=center><input name=allbox type=checkbox value=1 onClick=\"CheckAll();\">Select/Un-Select All\r\n<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Remove TextAd'>\r\n</form></td></tr></table><script language=\"JavaScript\">\r\n   <!--\r\n   function CheckAll()\r\n   {\r\n      for (var i=0;i<document.maj.elements.length;i++)\r\n      {\r\n         var e = document.maj.elements[i];\r\n         if (e.name != \"allbox\")\r\n            e.checked = document.maj.allbox.checked;\r\n      }\r\n   }\r\n   //-->\r\n</script>\r\n";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == 312 ) 
                                                                                                        {
                                                                                                            echo "<h2 align=center>Pending Text Ads</h2>";
                                                                                                            $step = 50;
                                                                                                            $currentpage = $p;
                                                                                                            $sql = "Select * from memberstextads where approved=0 order by ID";
                                                                                                            if( !($rs = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            $row = mysql_num_rows($rs);
                                                                                                            $totallinks = $row;
                                                                                                            if( !isset($currentpage) ) 
                                                                                                            {
                                                                                                                $currentpage = 1;
                                                                                                            }

                                                                                                            if( 0 < $totallinks ) 
                                                                                                            {
                                                                                                                if( $totallinks < 50 ) 
                                                                                                                {
                                                                                                                    echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    if( $totallinks < $currentpage * 50 ) 
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
                                                                                                                    }

                                                                                                                }

                                                                                                            }

                                                                                                            if( $step < $totallinks ) 
                                                                                                            {
                                                                                                                $pagecount = ceil($totallinks / $step);
                                                                                                                print "<br>Page NO - &nbsp;&nbsp;";
                                                                                                                for( $i = 1; $i <= $pagecount; $i++ ) 
                                                                                                                {
                                                                                                                    if( $pageno == $i ) 
                                                                                                                    {
                                                                                                                        echo $i . " ";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
                                                                                                                    }

                                                                                                                }
                                                                                                                echo "<br><br><br>";
                                                                                                            }

                                                                                                            $start = ($currentpage - 1) * $step;
                                                                                                            $query = "Select * from memberstextads where approved=0 order by ID";
                                                                                                            $sql = $query . "" . " LIMIT " . $start . "," . $step;
                                                                                                            if( !($result = mysql_query($sql)) ) 
                                                                                                            {
                                                                                                                mysql_error();
                                                                                                                print mysql_error();
                                                                                                                exit();
                                                                                                            }

                                                                                                            echo "<br><form action=admin.php method=post name=maj><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>ID.</b></td><td align=center><b>Member ID</b></td><td width=486 align=center><b>Text Ad</b></td><td width=70 align=center><b>Impressions Purchased</b></td><td width=70 align=center><b>Remaining</b></td><td width=70 align=center><b>Hits</b></td><td width=70 align=center><b>Date</b></td><td align=center><b>Action</b></td></tr>";
                                                                                                            while( $rs = mysql_fetch_row($result) ) 
                                                                                                            {
                                                                                                                echo "<tr><td align=center>" . $rs[0] . "</td><Td align=center>" . $rs[1] . "" . "</td><Td align=center><a href=" . $rs["3"] . " target=_blank>" . stripslashes($rs[2]) . "</a><br>" . stripslashes($rs[9]) . "" . "</td><Td align=center>" . $rs["4"] . "</td><Td align=center>" . $rs["5"] . "</td><Td align=center>" . $rs["6"] . "</td><Td align=center>" . $rs["8"] . "</td><td><input type=checkbox name=id" . $rs[0] . "></td></tr>";
                                                                                                            }
                                                                                                            echo "<tr><td colspan=8 align=center><input name=allbox type=checkbox value=1 onClick=\"CheckAll();\">Select/Un-Select All\r\n<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Approve TextAd'>\r\n    <input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Remove TextAd'>\r\n</form></td></tr></table><script language=\"JavaScript\">\r\n   <!--\r\n   function CheckAll()\r\n   {\r\n      for (var i=0;i<document.maj.elements.length;i++)\r\n      {\r\n         var e = document.maj.elements[i];\r\n         if (e.name != \"allbox\")\r\n            e.checked = document.maj.allbox.checked;\r\n      }\r\n   }\r\n   //-->\r\n</script>\r\n";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == "Remove TextAd" ) 
                                                                                                        {
                                                                                                            foreach( $_POST as $k => $v ) 
                                                                                                            {
                                                                                                                $d = explode("id", $k);
                                                                                                                if( $d[1] != "" ) 
                                                                                                                {
                                                                                                                    $rs = mysql_query("" . "select * from memberstextads where ID=" . $d["1"]);
                                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                                    $id = $arr[0];
                                                                                                                    $sql_d = "select * from memberstextads where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $arr = mysql_fetch_array($rs_d);
                                                                                                                    $sql_d = "delete from memberstextads where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $sql = "" . "select * from users where Username='" . $arr["1"] . "'";
                                                                                                                    $rs = mysql_query($sql);
                                                                                                                    $arr1 = mysql_fetch_array($rs);
                                                                                                                    mysql_query("" . "update users set textadsused=textadsused-" . $arr["5"] . " where Username='" . $arr["1"] . "'");
                                                                                                                    $to = $arr1[7];
                                                                                                                    $message1 = $message9;
                                                                                                                    $message1 = str_replace("{name}", "" . $arr1["1"], $message1);
                                                                                                                    $message1 = str_replace("{email}", "" . $arr1["7"], $message1);
                                                                                                                    $message1 = str_replace("{username}", "" . $arr1["8"], $message1);
                                                                                                                    $message1 = str_replace("{password}", "" . $arr1["9"], $message1);
                                                                                                                    $message1 = str_replace("{textad}", "" . $arr["2"], $message1);
                                                                                                                    $message1 = str_replace("{websiteurl}", "" . $arr["3"], $message1);
                                                                                                                    $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                                    $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                                    $subject1 = str_replace("{name}", "" . $arr1["1"], $subject9);
                                                                                                                    $subject1 = str_replace("{email}", "" . $arr1["7"], $subject1);
                                                                                                                    $subject1 = str_replace("{username}", "" . $arr1["8"], $subject1);
                                                                                                                    $subject1 = str_replace("{password}", "" . $arr1["9"], $subject1);
                                                                                                                    $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                                    $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                                    $message = stripslashes($message1);
                                                                                                                    $subject = stripslashes($subject1);
                                                                                                                    $from = $webmasteremail;
                                                                                                                    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                                    if( $eformat9 == 1 ) 
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                                    }

                                                                                                                    $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                                    $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                                    $header .= "X-Mailer: PHP4\n";
                                                                                                                    $header .= "X-Priority: 3\n";
                                                                                                                    $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                                    mail($to, $subject, $message, $header);
                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><b>Text Ad(s) Successfully Removed";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        if( trim($b) == "Approve TextAd" ) 
                                                                                                        {
                                                                                                            foreach( $_POST as $k => $v ) 
                                                                                                            {
                                                                                                                $d = explode("id", $k);
                                                                                                                if( $d[1] != "" ) 
                                                                                                                {
                                                                                                                    $rs = mysql_query("" . "select * from memberstextads where ID=" . $d["1"]);
                                                                                                                    $arr = mysql_fetch_array($rs);
                                                                                                                    $id = $arr[0];
                                                                                                                    $sql_d = "Update memberstextads set approved=1 where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $sql_d = "select * from memberstextads where ID=" . $id;
                                                                                                                    $rs_d = mysql_query($sql_d);
                                                                                                                    $arr = mysql_fetch_array($rs_d);
                                                                                                                    $sql = "" . "select * from users where Username='" . $arr["1"] . "'";
                                                                                                                    $rs = mysql_query($sql);
                                                                                                                    $arr1 = mysql_fetch_array($rs);
                                                                                                                    $to = $arr1[7];
                                                                                                                    $message1 = $message8;
                                                                                                                    $message1 = str_replace("{name}", "" . $arr1["1"], $message1);
                                                                                                                    $message1 = str_replace("{email}", "" . $arr1["7"], $message1);
                                                                                                                    $message1 = str_replace("{username}", "" . $arr1["8"], $message1);
                                                                                                                    $message1 = str_replace("{password}", "" . $arr1["9"], $message1);
                                                                                                                    $message1 = str_replace("{textad}", "" . $arr["2"], $message1);
                                                                                                                    $message1 = str_replace("{websiteurl}", "" . $arr["3"], $message1);
                                                                                                                    $message1 = str_replace("{sitename}", "" . $sitename, $message1);
                                                                                                                    $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
                                                                                                                    $subject1 = str_replace("{name}", "" . $arr1["1"], $subject8);
                                                                                                                    $subject1 = str_replace("{email}", "" . $arr1["7"], $subject1);
                                                                                                                    $subject1 = str_replace("{username}", "" . $arr1["8"], $subject1);
                                                                                                                    $subject1 = str_replace("{password}", "" . $arr1["9"], $subject1);
                                                                                                                    $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
                                                                                                                    $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
                                                                                                                    $message = stripslashes($message1);
                                                                                                                    $subject = stripslashes($subject1);
                                                                                                                    $from = $webmasteremail;
                                                                                                                    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
                                                                                                                    if( $eformat8 == 1 ) 
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        $header .= "Content-type: text/html; charset=iso-8859-1\n";
                                                                                                                    }

                                                                                                                    $header .= "" . "Reply-To: <" . $from . ">\n";
                                                                                                                    $header .= "" . "X-Sender: <" . $from . ">\n";
                                                                                                                    $header .= "X-Mailer: PHP4\n";
                                                                                                                    $header .= "X-Priority: 3\n";
                                                                                                                    $header .= "" . "Return-Path: <" . $from . ">\n";
                                                                                                                    mail($to, $subject, $message, $header);
                                                                                                                }

                                                                                                            }
                                                                                                            echo "<br><b>Text Ad(s) Successfully Approved";
                                                                                                            return NULL;
                                                                                                        }

                                                                                                        echo "<br>\r\n<br>\r\n<b><center><font face=verdana size=2>Live News Update from Script Seller</b>\r\n<br><br>\r\n<script src=\"http://www.yourfreeworld.com/script/msg.php?sid=50\"></script>\r\n</font>\r\n</center>\r\n";
                                                                                                    }

                                                                                                }

                                                                                            }

                                                                                        }

                                                                                    }

                                                                                }

                                                                            }

                                                                        }

                                                                    }

                                                                }

                                                            }

                                                        }

                                                    }

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }

}

function sendmail($from, $to, $subject, $format, $body)
{
    include("config.php");
    $to = $to;
    $subject = $subject;
    $from = $webmasteremail;
    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
    if( $format == 1 ) 
    {
        $header .= "Content-type: text/html; charset=iso-8859-1\n";
    }
    else
    {
        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
    }

    $header .= "" . "Reply-To: <" . $from . ">\n";
    $header .= "" . "X-Sender: <" . $from . ">\n";
    $header .= "X-Mailer: PHP4\n";
    $header .= "X-Priority: 3\n";
    $header .= "" . "Return-Path: <" . $from . ">\n";
    mail($to, $subject, $body, $header);
}

function my_array_unique($somearray)
{
    $tmparr = array_unique($somearray);
    $k = 0;
    foreach( $tmparr as $v ) 
    {
        $newarr[$k] = $v;
        $k++;
    }
    return $newarr;
}

function random_number()
{
    $random_number = rand(0, 9);
    return $random_number;
}

function membersrecords($query, $number, $b, $p)
{
    $step = 50;
    $currentpage = $p;
    $sql = "select * from users";
    if( !($rs = mysql_query($sql)) ) 
    {
        mysql_error();
        print mysql_error();
        exit();
    }

    $row = mysql_num_rows($rs);
    $totallinks = $row;
    if( !isset($currentpage) ) 
    {
        $currentpage = 1;
    }

    if( 0 < $totallinks ) 
    {
        if( $totallinks < 50 ) 
        {
            echo "<br><b>Displaying Records from 1 - " . $totallinks . "</b><br>";
        }
        else
        {
            if( $totallinks < $currentpage * 50 ) 
            {
                echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . $totallinks . "</b><br>";
            }
            else
            {
                echo "<br><b>Displaying Records from " . intval($currentpage * 50 - 49) . " - " . intval($currentpage * 50) . "</b><br>";
            }

        }

    }

    if( $step < $totallinks ) 
    {
        $pagecount = ceil($totallinks / $step);
        print "<br>Page NO - &nbsp;&nbsp;";
        for( $i = 1; $i <= $pagecount; $i++ ) 
        {
            if( $pageno == $i ) 
            {
                echo $i . " ";
            }
            else
            {
                echo "<a href='admin.php?b=" . $b . "&p=" . $i . "'>" . $i . "</a> &nbsp; ";
            }

        }
        echo "<br><br><br>";
    }

    $start = ($currentpage - 1) * $step;
    $query = "Select * from users order by ID";
    $sql = $query . "" . " LIMIT " . $start . "," . $step;
    if( !($result = mysql_query($sql)) ) 
    {
        mysql_error();
        print mysql_error();
        exit();
    }

    echo "<br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=20><b>Record No.</b></td><td align=center><b>Name</b></td><td align=center valign=center><b>Email</b></td><td width=70 align=center><b>Username</b></td><td width=70 align=center><b>Status</b></td><td align=center><b>Action</b></td></tr>";
    while( $rs = mysql_fetch_row($result) ) 
    {
        $rowcount = $rowcount + 1;
        $no = intval($currentpage * 50) - 50 + $rowcount;
        if( $rs[10] == 0 ) 
        {
            $st = "Inactive<br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Resend Verfication Email'><br><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Verify Account'>";
        }
        else
        {
            if( $rs[14] == 1 ) 
            {
                $st = "Free";
            }
            else
            {
                $st = "Pro";
            }

        }

        echo "<tr><form action='admin.php' method=post><input type=hidden name=id value=" . $rs[0] . "><td align=center>" . $no . "</td><Td align=center>" . $rs[1] . "</td><Td align=center>" . $rs[7] . "</td><Td align=center>" . $rs[8] . "</td><Td align=center>" . $st . "</td><Td align=center valign=center>";
        echo "<input type=hidden name=atype value=" . $number . "><input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='View Details'>&nbsp;&nbsp;";
        echo "<input type=Submit style='color: #000000; font-size: 10pt; font-family: Verdana; font-weight: bold; border: 1px ridge #000000; background-color: B0D8DD' name='b' value='Delete Account'></form></td></tr>";
    }
    echo "</table>";
}

function assignreferralss($acountid, $refid, $status, $level, $mid)
{
    include("config.php");
    $tablee = "" . "matrix" . $mid;
    $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
    $arrm = mysql_fetch_array($rsm);
    $mname = $arrm[1];
    $fee = $arrm[2];
    $matrixtype = $arrm[3];
    $levels = $arrm[4];
    $forcedmatrix = $arrm[5];
    if( $level < $levels + 1 ) 
    {
        $referralid = 0;
        $rs = mysql_query("" . "Select * from " . $tablee . " where ID=" . $refid);
        if( 0 < mysql_num_rows($rs) ) 
        {
            $arr = mysql_fetch_array($rs);
            if( $level == 1 ) 
            {
                $rs = mysql_query("" . "Update " . $tablee . " set Level1=Level1-1 where ID=" . $refid);
            }
            else
            {
                if( $level == 2 ) 
                {
                    $rs = mysql_query("" . "Update " . $tablee . " set Level2=Level2-1 where ID=" . $refid);
                }
                else
                {
                    if( $level == 3 ) 
                    {
                        $rs = mysql_query("" . "Update " . $tablee . " set Level3=Level3-1 where ID=" . $refid);
                    }
                    else
                    {
                        if( $level == 4 ) 
                        {
                            $rs = mysql_query("" . "Update " . $tablee . " set Level4=Level4-1 where ID=" . $refid);
                        }
                        else
                        {
                            if( $level == 5 ) 
                            {
                                $rs = mysql_query("" . "Update " . $tablee . " set Level5=Level5-1 where ID=" . $refid);
                            }
                            else
                            {
                                if( $level == 6 ) 
                                {
                                    $rs = mysql_query("" . "Update " . $tablee . " set Level6=Level6-1 where ID=" . $refid);
                                }
                                else
                                {
                                    if( $level == 7 ) 
                                    {
                                        $rs = mysql_query("" . "Update " . $tablee . " set Level7=Level7-1 where ID=" . $refid);
                                    }
                                    else
                                    {
                                        if( $level == 8 ) 
                                        {
                                            $rs = mysql_query("" . "Update " . $tablee . " set Level8=Level8-1 where ID=" . $refid);
                                        }
                                        else
                                        {
                                            if( $level == 9 ) 
                                            {
                                                $rs = mysql_query("" . "Update " . $tablee . " set Level9=Level9-1 where ID=" . $refid);
                                            }
                                            else
                                            {
                                                if( $level == 10 ) 
                                                {
                                                    $rs = mysql_query("" . "Update " . $tablee . " set Level10=Level10-1 where ID=" . $refid);
                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

            if( $arr[3] != 0 ) 
            {
                $referralid = $arr[3];
            }

            if( $referralid != 0 ) 
            {
                assignreferralss($acountid, $referralid, 1, $level + 1, $mid);
            }

        }

    }

}

function assignreferrals($acountid, $refid, $status, $level, $mid)
{
    include("config.php");
    $tablee = "" . "matrix" . $mid;
    $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
    $arrm = mysql_fetch_array($rsm);
    $mname = $arrm[1];
    $fee = $arrm[2];
    $matrixtype = $arrm[3];
    $levels = $arrm[4];
    $forcedmatrix = $arrm[5];
    $refbonus = $arrm[84];
    $refbonuspaid = $arrm[83];
    $payouttype = $arrm[6];
    $matrixbonus = $arrm[7];
    $matchingbonus = $arrm[8];
    $level1 = $arrm[9];
    $level2 = $arrm[10];
    $level3 = $arrm[11];
    $level4 = $arrm[12];
    $level5 = $arrm[13];
    $level6 = $arrm[14];
    $level7 = $arrm[15];
    $level8 = $arrm[16];
    $level9 = $arrm[17];
    $level10 = $arrm[18];
    $level1m = $arrm[19];
    $level2m = $arrm[20];
    $level3m = $arrm[21];
    $level4m = $arrm[22];
    $level5m = $arrm[23];
    $level6m = $arrm[24];
    $level7m = $arrm[25];
    $level8m = $arrm[26];
    $level9m = $arrm[27];
    $level10m = $arrm[28];
    $level1c = $arrm[29];
    $level2c = $arrm[30];
    $level3c = $arrm[31];
    $level4c = $arrm[32];
    $level5c = $arrm[33];
    $level6c = $arrm[34];
    $level7c = $arrm[35];
    $level8c = $arrm[36];
    $level9c = $arrm[37];
    $level10c = $arrm[38];
    $level1cm = $arrm[39];
    $level2cm = $arrm[40];
    $level3cm = $arrm[41];
    $level4cm = $arrm[42];
    $level5cm = $arrm[43];
    $level6cm = $arrm[44];
    $level7cm = $arrm[45];
    $level8cm = $arrm[46];
    $level9cm = $arrm[47];
    $level10cm = $arrm[48];
    $textcreditsentry = $arrm[49];
    $bannercreditsentry = $arrm[50];
    $textcreditscycle = $arrm[51];
    $bannercreditscycle = $arrm[52];
    $reentry = $arrm[53];
    $reentrynum = $arrm[54];
    $entry1 = $arrm[55];
    $entry1num = $arrm[56];
    $matrixid1 = $arrm[57];
    $entry2 = $arrm[58];
    $entry2num = $arrm[59];
    $matrixid2 = $arrm[60];
    $entry3 = $arrm[61];
    $entry3num = $arrm[62];
    $matrixid3 = $arrm[63];
    $entry4 = $arrm[64];
    $entry4num = $arrm[65];
    $matrixid4 = $arrm[66];
    $entry5 = $arrm[67];
    $entry5num = $arrm[68];
    $matrixid5 = $arrm[69];
    $welcomemail = $arrm[70];
    $subject1 = stripslashes($arrm[71]);
    $message1 = stripslashes($arrm[72]);
    $eformat1 = $arrm[73];
    $cyclemail = $arrm[74];
    $subject2 = stripslashes($arrm[75]);
    $message2 = stripslashes($arrm[76]);
    $eformat2 = $arrm[77];
    $cyclemailsponsor = $arrm[78];
    $subject3 = stripslashes($arrm[79]);
    $message3 = stripslashes($arrm[80]);
    $eformat3 = $arrm[81];
    $f1 = $forcedmatrix;
    $f2 = $forcedmatrix * $forcedmatrix;
    $f3 = $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f4 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f5 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f6 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f7 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f8 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f9 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f10 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    if( $levels == 1 ) 
    {
        $fquery = "" . "Level1<" . $forcedmatrix;
    }
    else
    {
        if( $levels == 2 ) 
        {
            $fquery = "" . "Level2<" . $f2;
        }
        else
        {
            if( $levels == 3 ) 
            {
                $fquery = "" . "Level3<" . $f3;
            }
            else
            {
                if( $levels == 4 ) 
                {
                    $fquery = "" . "Level4<" . $f4;
                }
                else
                {
                    if( $levels == 5 ) 
                    {
                        $fquery = "" . "Level5<" . $f5;
                    }
                    else
                    {
                        if( $levels == 6 ) 
                        {
                            $fquery = "" . "Level6<" . $f6;
                        }
                        else
                        {
                            if( $levels == 7 ) 
                            {
                                $fquery = "" . "Level7<" . $f7;
                            }
                            else
                            {
                                if( $levels == 8 ) 
                                {
                                    $fquery = "" . "Level8<" . $f8;
                                }
                                else
                                {
                                    if( $levels == 9 ) 
                                    {
                                        $fquery = "" . "Level9<" . $f9;
                                    }
                                    else
                                    {
                                        if( $levels == 10 ) 
                                        {
                                            $fquery = "" . "Level10<" . $f10;
                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }

    if( $status == 0 ) 
    {
        $rs = mysql_query("" . "Update " . $tablee . " set ref_by=" . $refid . " where ID=" . $acountid);
    }

    if( $level < $levels + 1 ) 
    {
        $referralid = 0;
        $rs = mysql_query("" . "Select * from " . $tablee . " where ID=" . $refid);
        if( 0 < mysql_num_rows($rs) ) 
        {
            $arr = mysql_fetch_array($rs);
            if( $level == 1 ) 
            {
                $rs = mysql_query("" . "Update " . $tablee . " set Level1=Level1+1 where ID=" . $refid);
                $bonus = $level1;
                if( 0 < $bonus ) 
                {
                    creategift($bonus, $acountid, $refid, $mid);
                }

            }
            else
            {
                if( $level == 2 ) 
                {
                    $rs = mysql_query("" . "Update " . $tablee . " set Level2=Level2+1 where ID=" . $refid);
                    $bonus = $level2;
                    if( 0 < $bonus ) 
                    {
                        creategift($bonus, $acountid, $refid, $mid);
                    }

                }
                else
                {
                    if( $level == 3 ) 
                    {
                        $rs = mysql_query("" . "Update " . $tablee . " set Level3=Level3+1 where ID=" . $refid);
                        $bonus = $level3;
                        if( 0 < $bonus ) 
                        {
                            creategift($bonus, $acountid, $refid, $mid);
                        }

                    }
                    else
                    {
                        if( $level == 4 ) 
                        {
                            $rs = mysql_query("" . "Update " . $tablee . " set Level4=Level4+1 where ID=" . $refid);
                            $bonus = $level4;
                            if( 0 < $bonus ) 
                            {
                                creategift($bonus, $acountid, $refid, $mid);
                            }

                        }
                        else
                        {
                            if( $level == 5 ) 
                            {
                                $rs = mysql_query("" . "Update " . $tablee . " set Level5=Level5+1 where ID=" . $refid);
                                $bonus = $level5;
                                if( 0 < $bonus ) 
                                {
                                    creategift($bonus, $acountid, $refid, $mid);
                                }

                            }
                            else
                            {
                                if( $level == 6 ) 
                                {
                                    $rs = mysql_query("" . "Update " . $tablee . " set Level6=Level6+1 where ID=" . $refid);
                                    $bonus = $level6;
                                    if( 0 < $bonus ) 
                                    {
                                        creategift($bonus, $acountid, $refid, $mid);
                                    }

                                }
                                else
                                {
                                    if( $level == 7 ) 
                                    {
                                        $rs = mysql_query("" . "Update " . $tablee . " set Level7=Level7+1 where ID=" . $refid);
                                        $bonus = $level7;
                                        if( 0 < $bonus ) 
                                        {
                                            creategift($bonus, $acountid, $refid, $mid);
                                        }

                                    }
                                    else
                                    {
                                        if( $level == 8 ) 
                                        {
                                            $rs = mysql_query("" . "Update " . $tablee . " set Level8=Level8+1 where ID=" . $refid);
                                            $bonus = $level8;
                                            if( 0 < $bonus ) 
                                            {
                                                creategift($bonus, $acountid, $refid, $mid);
                                            }

                                        }
                                        else
                                        {
                                            if( $level == 9 ) 
                                            {
                                                $rs = mysql_query("" . "Update " . $tablee . " set Level9=Level9+1 where ID=" . $refid);
                                                $bonus = $level9;
                                                if( 0 < $bonus ) 
                                                {
                                                    creategift($bonus, $acountid, $refid, $mid);
                                                }

                                            }
                                            else
                                            {
                                                if( $level == 10 ) 
                                                {
                                                    $rs = mysql_query("" . "Update " . $tablee . " set Level10=Level10+1 where ID=" . $refid);
                                                    $bonus = $level10;
                                                    if( 0 < $bonus ) 
                                                    {
                                                        creategift($bonus, $acountid, $refid, $mid);
                                                    }

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

            if( $arr[3] != 0 ) 
            {
                $referralid = $arr[3];
            }

            if( $referralid != 0 ) 
            {
                assignreferrals($acountid, $referralid, 1, $level + 1, $mid);
            }

        }

    }

}

function newupline($acountid, $ref_by, $mid)
{
    include("config.php");
    $check = 0;
    $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
    $arrm = mysql_fetch_array($rsm);
    $levels = $arrm[4];
    $forcedmatrix = $arrm[5];
    $tablee = "" . "matrix" . $mid;
    $checkid = 0;
    $rs = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID limit 0,1");
    if( 0 < mysql_num_rows($rs) ) 
    {
        $arr = mysql_fetch_array($rs);
        $check = 1;
        $checkid = $arr[0];
    }
    else
    {
        $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
        while( $arr = mysql_fetch_array($rs) ) 
        {
            $rs1 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr[0] . " order by ID limit 0,1");
            if( 0 < mysql_num_rows($rs1) ) 
            {
                $arr1 = mysql_fetch_array($rs1);
                if( $check == 0 ) 
                {
                    $check = 1;
                    $checkid = $arr1[0];
                }

                break;
            }

        }
        if( $check == 0 ) 
        {
            $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
            while( $arr = mysql_fetch_array($rs) ) 
            {
                $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                while( $arr1 = mysql_fetch_array($rs1) ) 
                {
                    $rs2 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr1[0] . " order by ID limit 0,1");
                    if( 0 < mysql_num_rows($rs2) ) 
                    {
                        $arr2 = mysql_fetch_array($rs2);
                        if( $check == 0 ) 
                        {
                            $check = 1;
                            $checkid = $arr2[0];
                        }

                        break;
                    }

                }
            }
            if( $check == 0 ) 
            {
                $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                while( $arr = mysql_fetch_array($rs) ) 
                {
                    $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                    while( $arr1 = mysql_fetch_array($rs1) ) 
                    {
                        $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                        while( $arr2 = mysql_fetch_array($rs2) ) 
                        {
                            $rs3 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr2[0] . " order by ID limit 0,1");
                            if( 0 < mysql_num_rows($rs3) ) 
                            {
                                $arr3 = mysql_fetch_array($rs3);
                                if( $check == 0 ) 
                                {
                                    $check = 1;
                                    $checkid = $arr3[0];
                                }

                                break;
                            }

                        }
                    }
                }
                if( $check == 0 ) 
                {
                    $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                    while( $arr = mysql_fetch_array($rs) ) 
                    {
                        $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                        while( $arr1 = mysql_fetch_array($rs1) ) 
                        {
                            $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                            while( $arr2 = mysql_fetch_array($rs2) ) 
                            {
                                $rs3 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr2[0] . " order by ID");
                                while( $arr3 = mysql_fetch_array($rs3) ) 
                                {
                                    $rs4 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr3[0] . " order by ID limit 0,1");
                                    if( 0 < mysql_num_rows($rs4) ) 
                                    {
                                        $arr4 = mysql_fetch_array($rs4);
                                        if( $check == 0 ) 
                                        {
                                            $check = 1;
                                            $checkid = $arr4[0];
                                        }

                                        break;
                                    }

                                }
                            }
                        }
                    }
                    if( $check == 0 ) 
                    {
                        $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                        while( $arr = mysql_fetch_array($rs) ) 
                        {
                            $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                            while( $arr1 = mysql_fetch_array($rs1) ) 
                            {
                                $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                                while( $arr2 = mysql_fetch_array($rs2) ) 
                                {
                                    $rs3 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr2[0] . " order by ID");
                                    while( $arr3 = mysql_fetch_array($rs3) ) 
                                    {
                                        $rs4 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr3[0] . " order by ID");
                                        while( $arr4 = mysql_fetch_array($rs4) ) 
                                        {
                                            $rs5 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr4[0] . " order by ID limit 0,1");
                                            if( 0 < mysql_num_rows($rs5) ) 
                                            {
                                                $arr5 = mysql_fetch_array($rs5);
                                                if( $check == 0 ) 
                                                {
                                                    $check = 1;
                                                    $checkid = $arr5[0];
                                                }

                                                break;
                                            }

                                        }
                                    }
                                }
                            }
                        }
                        if( $check == 0 ) 
                        {
                            $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                            while( $arr = mysql_fetch_array($rs) ) 
                            {
                                $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                                while( $arr1 = mysql_fetch_array($rs1) ) 
                                {
                                    $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                                    while( $arr2 = mysql_fetch_array($rs2) ) 
                                    {
                                        $rs3 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr2[0] . " order by ID");
                                        while( $arr3 = mysql_fetch_array($rs3) ) 
                                        {
                                            $rs4 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr3[0] . " order by ID");
                                            while( $arr4 = mysql_fetch_array($rs4) ) 
                                            {
                                                $rs5 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr4[0] . " order by ID");
                                                while( $arr5 = mysql_fetch_array($rs5) ) 
                                                {
                                                    $rs6 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr5[0] . " order by ID limit 0,1");
                                                    if( 0 < mysql_num_rows($rs6) ) 
                                                    {
                                                        $arr6 = mysql_fetch_array($rs6);
                                                        if( $check == 0 ) 
                                                        {
                                                            $check = 1;
                                                            $checkid = $arr6[0];
                                                        }

                                                        break;
                                                    }

                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if( $check == 0 ) 
                            {
                                $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                                while( $arr = mysql_fetch_array($rs) ) 
                                {
                                    $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                                    while( $arr1 = mysql_fetch_array($rs1) ) 
                                    {
                                        $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                                        while( $arr2 = mysql_fetch_array($rs2) ) 
                                        {
                                            $rs3 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr2[0] . " order by ID");
                                            while( $arr3 = mysql_fetch_array($rs3) ) 
                                            {
                                                $rs4 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr3[0] . " order by ID");
                                                while( $arr4 = mysql_fetch_array($rs4) ) 
                                                {
                                                    $rs5 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr4[0] . " order by ID");
                                                    while( $arr5 = mysql_fetch_array($rs5) ) 
                                                    {
                                                        $rs6 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr5[0] . " order by ID");
                                                        while( $arr6 = mysql_fetch_array($rs6) ) 
                                                        {
                                                            $rs7 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr6[0] . " order by ID limit 0,1");
                                                            if( 0 < mysql_num_rows($rs7) ) 
                                                            {
                                                                $arr7 = mysql_fetch_array($rs7);
                                                                if( $check == 0 ) 
                                                                {
                                                                    $check = 1;
                                                                    $checkid = $arr7[0];
                                                                }

                                                                break;
                                                            }

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if( $check == 0 ) 
                                {
                                    $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                                    while( $arr = mysql_fetch_array($rs) ) 
                                    {
                                        $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                                        while( $arr1 = mysql_fetch_array($rs1) ) 
                                        {
                                            $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                                            while( $arr2 = mysql_fetch_array($rs2) ) 
                                            {
                                                $rs3 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr2[0] . " order by ID");
                                                while( $arr3 = mysql_fetch_array($rs3) ) 
                                                {
                                                    $rs4 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr3[0] . " order by ID");
                                                    while( $arr4 = mysql_fetch_array($rs4) ) 
                                                    {
                                                        $rs5 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr4[0] . " order by ID");
                                                        while( $arr5 = mysql_fetch_array($rs5) ) 
                                                        {
                                                            $rs6 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr5[0] . " order by ID");
                                                            while( $arr6 = mysql_fetch_array($rs6) ) 
                                                            {
                                                                $rs7 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr6[0] . " order by ID");
                                                                while( $arr7 = mysql_fetch_array($rs7) ) 
                                                                {
                                                                    $rs8 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr7[0] . " order by ID limit 0,1");
                                                                    if( 0 < mysql_num_rows($rs8) ) 
                                                                    {
                                                                        $arr8 = mysql_fetch_array($rs8);
                                                                        if( $check == 0 ) 
                                                                        {
                                                                            $check = 1;
                                                                            $checkid = $arr8[0];
                                                                        }

                                                                        break;
                                                                    }

                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if( $check == 0 ) 
                                    {
                                        $rs = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $ref_by . "" . " and ID<>'" . $acountid . "' order by ID");
                                        while( $arr = mysql_fetch_array($rs) ) 
                                        {
                                            $rs1 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr[0] . " order by ID");
                                            while( $arr1 = mysql_fetch_array($rs1) ) 
                                            {
                                                $rs2 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr1[0] . " order by ID");
                                                while( $arr2 = mysql_fetch_array($rs2) ) 
                                                {
                                                    $rs3 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr2[0] . " order by ID");
                                                    while( $arr3 = mysql_fetch_array($rs3) ) 
                                                    {
                                                        $rs4 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr3[0] . " order by ID");
                                                        while( $arr4 = mysql_fetch_array($rs4) ) 
                                                        {
                                                            $rs5 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr4[0] . " order by ID");
                                                            while( $arr5 = mysql_fetch_array($rs5) ) 
                                                            {
                                                                $rs6 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr5[0] . " order by ID");
                                                                while( $arr6 = mysql_fetch_array($rs6) ) 
                                                                {
                                                                    $rs7 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr6[0] . " order by ID");
                                                                    while( $arr7 = mysql_fetch_array($rs7) ) 
                                                                    {
                                                                        $rs8 = mysql_query("" . "select ID from " . $tablee . " where ref_by=" . $arr7[0] . " order by ID");
                                                                        while( $arr8 = mysql_fetch_array($rs8) ) 
                                                                        {
                                                                            $rs9 = mysql_query("" . "select ID from " . $tablee . " where Level1<" . $forcedmatrix . " and ref_by=" . $arr8[0] . " order by ID limit 0,1");
                                                                            if( 0 < mysql_num_rows($rs9) ) 
                                                                            {
                                                                                $arr9 = mysql_fetch_array($rs9);
                                                                                if( $check == 0 ) 
                                                                                {
                                                                                    $check = 1;
                                                                                    $checkid = $arr9[0];
                                                                                }

                                                                                break;
                                                                            }

                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }

    if( $check != 1 ) 
    {
        $rs2 = mysql_query("" . "select ID from " . $tablee . " where Level1<'" . $forcedmatrix . "' and ID <>'" . $acountid . "' order by ID limit 0,1");
        $arr2 = mysql_fetch_array($rs2);
        $checkid = $arr2[0];
    }

    return $checkid;
}

function rassignreferrals($acountid, $refid, $status, $level, $mid)
{
    include("config.php");
    $tablee = "" . "matrix" . $mid;
    $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
    $arrm = mysql_fetch_array($rsm);
    $mname = $arrm[1];
    $fee = $arrm[2];
    $matrixtype = $arrm[3];
    $levels = $arrm[4];
    $forcedmatrix = $arrm[5];
    $refbonus = $arrm[84];
    $refbonuspaid = $arrm[83];
    $payouttype = $arrm[6];
    $matrixbonus = $arrm[7];
    $matchingbonus = $arrm[8];
    $level1 = $arrm[9];
    $level2 = $arrm[10];
    $level3 = $arrm[11];
    $level4 = $arrm[12];
    $level5 = $arrm[13];
    $level6 = $arrm[14];
    $level7 = $arrm[15];
    $level8 = $arrm[16];
    $level9 = $arrm[17];
    $level10 = $arrm[18];
    $level1m = $arrm[19];
    $level2m = $arrm[20];
    $level3m = $arrm[21];
    $level4m = $arrm[22];
    $level5m = $arrm[23];
    $level6m = $arrm[24];
    $level7m = $arrm[25];
    $level8m = $arrm[26];
    $level9m = $arrm[27];
    $level10m = $arrm[28];
    $level1c = $arrm[29];
    $level2c = $arrm[30];
    $level3c = $arrm[31];
    $level4c = $arrm[32];
    $level5c = $arrm[33];
    $level6c = $arrm[34];
    $level7c = $arrm[35];
    $level8c = $arrm[36];
    $level9c = $arrm[37];
    $level10c = $arrm[38];
    $level1cm = $arrm[39];
    $level2cm = $arrm[40];
    $level3cm = $arrm[41];
    $level4cm = $arrm[42];
    $level5cm = $arrm[43];
    $level6cm = $arrm[44];
    $level7cm = $arrm[45];
    $level8cm = $arrm[46];
    $level9cm = $arrm[47];
    $level10cm = $arrm[48];
    $textcreditsentry = $arrm[49];
    $bannercreditsentry = $arrm[50];
    $textcreditscycle = $arrm[51];
    $bannercreditscycle = $arrm[52];
    $reentry = $arrm[53];
    $reentrynum = $arrm[54];
    $entry1 = $arrm[55];
    $entry1num = $arrm[56];
    $matrixid1 = $arrm[57];
    $entry2 = $arrm[58];
    $entry2num = $arrm[59];
    $matrixid2 = $arrm[60];
    $entry3 = $arrm[61];
    $entry3num = $arrm[62];
    $matrixid3 = $arrm[63];
    $entry4 = $arrm[64];
    $entry4num = $arrm[65];
    $matrixid4 = $arrm[66];
    $entry5 = $arrm[67];
    $entry5num = $arrm[68];
    $matrixid5 = $arrm[69];
    $welcomemail = $arrm[70];
    $subject1 = stripslashes($arrm[71]);
    $message1 = stripslashes($arrm[72]);
    $eformat1 = $arrm[73];
    $cyclemail = $arrm[74];
    $subject2 = stripslashes($arrm[75]);
    $message2 = stripslashes($arrm[76]);
    $eformat2 = $arrm[77];
    $cyclemailsponsor = $arrm[78];
    $subject3 = stripslashes($arrm[79]);
    $message3 = stripslashes($arrm[80]);
    $eformat3 = $arrm[81];
    $f1 = $forcedmatrix;
    $f2 = $forcedmatrix * $forcedmatrix;
    $f3 = $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f4 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f5 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f6 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f7 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f8 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f9 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    $f10 = $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix * $forcedmatrix;
    if( $levels == 1 ) 
    {
        $fquery = "" . "Level1<" . $forcedmatrix;
    }
    else
    {
        if( $levels == 2 ) 
        {
            $fquery = "" . "Level2<" . $f2;
        }
        else
        {
            if( $levels == 3 ) 
            {
                $fquery = "" . "Level3<" . $f3;
            }
            else
            {
                if( $levels == 4 ) 
                {
                    $fquery = "" . "Level4<" . $f4;
                }
                else
                {
                    if( $levels == 5 ) 
                    {
                        $fquery = "" . "Level5<" . $f5;
                    }
                    else
                    {
                        if( $levels == 6 ) 
                        {
                            $fquery = "" . "Level6<" . $f6;
                        }
                        else
                        {
                            if( $levels == 7 ) 
                            {
                                $fquery = "" . "Level7<" . $f7;
                            }
                            else
                            {
                                if( $levels == 8 ) 
                                {
                                    $fquery = "" . "Level8<" . $f8;
                                }
                                else
                                {
                                    if( $levels == 9 ) 
                                    {
                                        $fquery = "" . "Level9<" . $f9;
                                    }
                                    else
                                    {
                                        if( $levels == 10 ) 
                                        {
                                            $fquery = "" . "Level10<" . $f10;
                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }

    if( $status == 0 ) 
    {
        $rs = mysql_query("" . "Update " . $tablee . " set ref_by=" . $refid . " where ID=" . $acountid);
    }

    if( $level < $levels + 1 ) 
    {
        $referralid = 0;
        $rs = mysql_query("" . "Select * from " . $tablee . " where ID=" . $refid);
        if( 0 < mysql_num_rows($rs) ) 
        {
            $arr = mysql_fetch_array($rs);
            $err = 0;
            $rsb = mysql_query("" . "select * from " . $tablee . " where Username='" . $arr["2"] . "'");
            if( 0 < mysql_num_rows($rsb) ) 
            {
                $err = 0;
            }
            else
            {
                if( $nonmatrixmatch == 1 ) 
                {
                    $err = 0;
                }
                else
                {
                    $err = 1;
                }

            }

            if( $level == 1 ) 
            {
                $bonus = $level1;
                mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
            }
            else
            {
                if( $level == 2 ) 
                {
                    $bonus = $level2;
                    mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                    mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                }
                else
                {
                    if( $level == 3 ) 
                    {
                        $bonus = $level3;
                        mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                        mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                    }
                    else
                    {
                        if( $level == 4 ) 
                        {
                            $bonus = $level4;
                            mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                            mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                        }
                        else
                        {
                            if( $level == 5 ) 
                            {
                                $bonus = $level5;
                                mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                                mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                            }
                            else
                            {
                                if( $level == 6 ) 
                                {
                                    $bonus = $level6;
                                    mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                                    mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                                }
                                else
                                {
                                    if( $level == 7 ) 
                                    {
                                        $bonus = $level7;
                                        mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                                        mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                                    }
                                    else
                                    {
                                        if( $level == 8 ) 
                                        {
                                            $bonus = $level8;
                                            mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                                            mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                                        }
                                        else
                                        {
                                            if( $level == 9 ) 
                                            {
                                                $bonus = $level9;
                                                mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                                                mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                                            }
                                            else
                                            {
                                                if( $level == 10 ) 
                                                {
                                                    $bonus = $level10;
                                                    mysql_query("" . "update " . $tablee . " set Total=Total+" . $bonus . " where ID=" . $refid);
                                                    mysql_query("" . "update users set Total=Total+" . $bonus . ",Unpaid=Unpaid+" . $bonus . " where Username='" . $arr["1"] . "'");
                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

            if( $arr[3] != 0 ) 
            {
                $referralid = $arr[3];
            }

            if( $referralid != 0 ) 
            {
                rassignreferrals($acountid, $referralid, 1, $level + 1, $mid);
            }

        }

    }

}

function creategift($bonus, $acountid, $refid, $mid)
{
    include("config.php");
    $tablee = "" . "matrix" . $mid;
    $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
    $arrm = mysql_fetch_array($rsm);
    $mname = $arrm[1];
    $fee = $arrm[2];
    $matrixtype = $arrm[3];
    $levels = $arrm[4];
    $forcedmatrix = $arrm[5];
    $fuser = "";
    $tuser = "admin";
    $rsf = mysql_query("" . "select Username from " . $tablee . " where ID=" . $acountid);
    if( 0 < mysql_num_rows($rsf) ) 
    {
        $arrf = mysql_fetch_array($rsf);
        $fuser = $arrf[0];
    }

    $rsf = mysql_query("" . "select Username from " . $tablee . " where ID=" . $refid);
    if( 0 < mysql_num_rows($rsf) ) 
    {
        $arrf = mysql_fetch_array($rsf);
        $tuser = $arrf[0];
    }

    mysql_query("" . "insert into gifts(FUsername,TUsername,PaymentMode,TransID,Amount,matrixid,posid,approved,Date,ADate) values('" . $fuser . "','" . $tuser . "','','','" . $bonus . "'," . $mid . "," . $acountid . ",0,'" . $today . "','" . $today . "')");
}

function matrixmail($b, $user, $mid, $mt)
{
    include("config.php");
    $tablee = "" . "matrix" . $mid;
    $rsm = mysql_query("" . "select * from membershiplevels where ID=" . $mid);
    $arrm = mysql_fetch_array($rsm);
    $mname = $arrm[1];
    $fee = $arrm[2];
    $matrixtype = $arrm[3];
    $levels = $arrm[4];
    $forcedmatrix = $arrm[5];
    $refbonus = $arrm[84];
    $refbonuspaid = $arrm[83];
    $payouttype = $arrm[6];
    $matrixbonus = $arrm[7];
    $matchingbonus = $arrm[8];
    $level1 = $arrm[9];
    $level2 = $arrm[10];
    $level3 = $arrm[11];
    $level4 = $arrm[12];
    $level5 = $arrm[13];
    $level6 = $arrm[14];
    $level7 = $arrm[15];
    $level8 = $arrm[16];
    $level9 = $arrm[17];
    $level10 = $arrm[18];
    $level1m = $arrm[19];
    $level2m = $arrm[20];
    $level3m = $arrm[21];
    $level4m = $arrm[22];
    $level5m = $arrm[23];
    $level6m = $arrm[24];
    $level7m = $arrm[25];
    $level8m = $arrm[26];
    $level9m = $arrm[27];
    $level10m = $arrm[28];
    $level1c = $arrm[29];
    $level2c = $arrm[30];
    $level3c = $arrm[31];
    $level4c = $arrm[32];
    $level5c = $arrm[33];
    $level6c = $arrm[34];
    $level7c = $arrm[35];
    $level8c = $arrm[36];
    $level9c = $arrm[37];
    $level10c = $arrm[38];
    $level1cm = $arrm[39];
    $level2cm = $arrm[40];
    $level3cm = $arrm[41];
    $level4cm = $arrm[42];
    $level5cm = $arrm[43];
    $level6cm = $arrm[44];
    $level7cm = $arrm[45];
    $level8cm = $arrm[46];
    $level9cm = $arrm[47];
    $level10cm = $arrm[48];
    $textcreditsentry = $arrm[49];
    $bannercreditsentry = $arrm[50];
    $textcreditscycle = $arrm[51];
    $bannercreditscycle = $arrm[52];
    $reentry = $arrm[53];
    $reentrynum = $arrm[54];
    $entry1 = $arrm[55];
    $entry1num = $arrm[56];
    $matrixid1 = $arrm[57];
    $entry2 = $arrm[58];
    $entry2num = $arrm[59];
    $matrixid2 = $arrm[60];
    $entry3 = $arrm[61];
    $entry3num = $arrm[62];
    $matrixid3 = $arrm[63];
    $entry4 = $arrm[64];
    $entry4num = $arrm[65];
    $matrixid4 = $arrm[66];
    $entry5 = $arrm[67];
    $entry5num = $arrm[68];
    $matrixid5 = $arrm[69];
    $welcomemail = $arrm[70];
    $subject1 = stripslashes($arrm[71]);
    $message1 = stripslashes($arrm[72]);
    $eformat1 = $arrm[73];
    $cyclemail = $arrm[74];
    $subject2 = stripslashes($arrm[75]);
    $message2 = stripslashes($arrm[76]);
    $eformat2 = $arrm[77];
    $cyclemailsponsor = $arrm[78];
    $subject3 = stripslashes($arrm[79]);
    $message3 = stripslashes($arrm[80]);
    $eformat3 = $arrm[81];
    $err = 0;
    $rsp = mysql_query("" . "select * from " . $tablee . " where ID=" . $b);
    if( 0 < mysql_num_rows($rsp) ) 
    {
        $arr1 = mysql_fetch_array($rsp);
        $rs = mysql_query("" . "select * from users where Username='" . $arr1["1"] . "'");
        if( 0 < mysql_num_rows($rs) ) 
        {
            $arr = mysql_fetch_array($rs);
            $user = $arr[8];
            $ref_by = $arr[11];
        }
        else
        {
            $err = 1;
        }

    }
    else
    {
        $err = 1;
    }

    if( $err == 1 ) 
    {
        $rs = mysql_query("" . "select * from users where Username='" . $user . "'");
        if( 0 < mysql_num_rows($rs) ) 
        {
            $arr = mysql_fetch_array($rs);
            $user = $arr[8];
            $ref_by = $arr[11];
            $err = 0;
        }
        else
        {
            $err = 1;
        }

    }

    $refname = "";
    if( $mt == 1 ) 
    {
        $message1 = $message1;
        $subject1 = $subject1;
        $eformat1 = $eformat1;
    }
    else
    {
        if( $mt == 2 ) 
        {
            $message1 = $message2;
            $subject1 = $subject2;
            $eformat1 = $eformat2;
        }
        else
        {
            if( $mt == 3 ) 
            {
                $message1 = $message3;
                $subject1 = $subject3;
                $eformat1 = $eformat3;
                $rsu = mysql_query("" . "select Name from users where Usename='" . $ref_by . "'");
                if( 0 < mysql_num_rows($rsu) ) 
                {
                    $arru = mysql_fetch_array($rsu);
                    $refname = $arru[0];
                }

            }

        }

    }

    $to = $arr[7];
    $message1 = str_replace("{name}", "" . $arr["1"], $message1);
    $message1 = str_replace("{email}", "" . $arr["7"], $message1);
    $message1 = str_replace("{username}", "" . $arr["8"], $message1);
    $message1 = str_replace("{password}", "" . $arr["9"], $message1);
    $message1 = str_replace("{id}", "" . $b, $message1);
    $message1 = str_replace("{matrix}", "" . $mname, $message1);
    $message1 = str_replace("{refname}", "" . $refname, $message1);
    $message1 = str_replace("{sitename}", "" . $sitename, $message1);
    $message1 = str_replace("{siteurl}", "" . $siteurl, $message1);
    $subject1 = str_replace("{name}", "" . $arr["1"], $subject1);
    $subject1 = str_replace("{email}", "" . $arr["7"], $subject1);
    $subject1 = str_replace("{username}", "" . $arr["8"], $subject1);
    $subject1 = str_replace("{password}", "" . $arr["9"], $subject1);
    $subject1 = str_replace("{id}", "" . $b, $subject1);
    $subject1 = str_replace("{matrix}", "" . $mname, $subject1);
    $subject1 = str_replace("{refname}", "" . $refname, $subject1);
    $subject1 = str_replace("{sitename}", "" . $sitename, $subject1);
    $subject1 = str_replace("{siteurl}", "" . $siteurl, $subject1);
    $message = stripslashes($message1);
    $subject = stripslashes($subject1);
    $from = $webmasteremail;
    $header = "" . "From: " . $sitename . "<" . $from . ">\n";
    if( $eformat1 == 1 ) 
    {
        $header .= "Content-type: text/plain; charset=iso-8859-1\n";
    }
    else
    {
        $header .= "Content-type: text/html; charset=iso-8859-1\n";
    }

    $header .= "" . "Reply-To: <" . $from . ">\n";
    $header .= "" . "X-Sender: <" . $from . ">\n";
    $header .= "X-Mailer: PHP4\n";
    $header .= "X-Priority: 3\n";
    $header .= "" . "Return-Path: <" . $from . ">\n";
    if( $err == 0 ) 
    {
        mail($to, $subject, $message, $header);
    }

}

