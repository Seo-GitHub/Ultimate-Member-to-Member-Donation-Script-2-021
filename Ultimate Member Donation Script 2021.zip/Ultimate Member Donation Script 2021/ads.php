<?php
  session_start();

include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
middle();
} 

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$check=1;
	$email=$arr[7];
        $name=$arr[1];
	$ref=$arr[11];
	$username=$_SESSION[username_session];
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
	}
	else {
		$statust="Pro";
	}
	$total=$arr[15];
	$paid=$arr[17];
	$unpaid=$arr[16];

?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Promotional Center</b></font></p>
<br>
		<div align="center">
		<table border="0" cellpadding="3" cellspacing="0" width="80%">
		      <tr> 
                        <td valign="center" align="left" colspan=2><font face=verdana size=2><b>Text Link:</b><br><a href="<?php echo $siteurl; ?>/?<?php echo $_SESSION["username_session"]; ?>" target=_blank><?php echo $siteurl; ?>/?<?php echo $_SESSION["username_session"]; ?></a>
<br><br>
<?php $rs=mysql_query("select * from banners order by ID");
if(mysql_num_rows($rs)>0) { ?>
<b>Banner Links</b><br>
<?php while($arr=mysql_fetch_array($rs)) { ?>
<a href="<?php echo $siteurl;?>/?<?php echo $_SESSION["username_session"];?>"><img src="<?php echo $arr[1];?>" border="0"></a><br>
<textarea rows=5 cols=50><a href="<?php echo $siteurl;?>/?<?php echo $_SESSION["username_session"];?>"><img src="<?php echo $arr[1]?>" border="0"></a></textarea>
<br><br>
<?php } } ?>
<br><br>

<?php $rs=mysql_query("select * from soloads order by ID");
if(mysql_num_rows($rs)>0) { 
if(mysql_num_rows($rs)==1) $cont="is a <b>solo ad</b>"; else $cont="are <b>solo ads</b>"
?>
Following <?php echo $cont; ?> copy template that you can copy and paste into your web site and/or send out to safelists or your mailing lists to promote <?php echo $sitename; ?>.
Personal recommendations always work well in marketing.You can even write a personal testimonial after you have used our services to gain a better response from your promotions. 
<br><br>

<?php $i=0;
$refurl="$siteurl/?$_SESSION[username_session]";
$url="<a href='$refurl' target=_blank>$refurl</a>";
 while($arr=mysql_fetch_array($rs)) { 
$i++; ?>
<b>Solo Ad #<?php echo $i; ?></b>
<br><br>
Subject: <?php echo stripslashes($arr[1]); ?>
<br><br>
<?php 
$arr[2]=str_replace("\n","<br>",$arr[2]);
$arr[2]=str_replace("{refurl}",$refurl,$arr[2]);
$arr[2]=str_replace("{name}",$name,$arr[2]);
$arr[2]=str_replace("{username}",$username,$arr[2]);
echo stripslashes($arr[2]);
echo "<br><br>";
}
 } 
?>
</td>
		      </tr>
		</table>
</td></tr></table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php   return 1;
} include "footer.php";
?>