<?php
include "header.php";
include "config.php";
include "func.php";
$a=validatet($_POST[Email]);

if ($a=="")
{
  ?>
  <div align="left">
   <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td rowspan="23" align="center" valign="top" width="72%" >
        <form action=forgot.php method=post>
          <div align="center">
            <p><font color="#0000CC"><br><br><b>Password Reminder</b></font></p>
            <p align="center"> <strong><font size="-1">Please enter&nbsp;the Email
              address you used to register at </font><font color="#000040"><b><?php echo($sitename) ; ?></b></font><font size="-1"><font size="-1">
              and then press submit.</font></font></strong> <font size="-1" color="#D64200">
              </font><font size="-1"> <br>
              <input name="Email" size="30" >
              <br>
              </font></p>
          </div>
          <p align="center"><small>
            <input type="submit" value="Submit">
            </small></p>
          <p><strong>Your Password will be sent to you within few minutes.</strong>
          </p>
        </form>
        <p align="center">&nbsp;</p>
      </td>
    </tr>
  </table>
  </div>
  <?php
}
else
{
  $sql = "Select * from users where Email='".$a."'";
  $result = mysql_query($sql);
  $total = mysql_num_rows($result);
  if ($total < 1)
  {
    echo("<b><br><br><br><center>Sorry , this Email Address doesn't exist in our member database .<br></center></b>");
    ?>
    <div align="left">
    <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td rowspan="23" align="center" valign="top" width="72%" >
        <form action=forgot.php method=post>
          <div align="center">
            <p><font color="#0000CC"><br><br><b>Password Reminder</b></font></p>
            <p align="center"> <strong><font size="-1">Please enter&nbsp;the Email
              address you used to register at </font><font color="#000040"><b><?php echo($sitename) ; ?></b></font><font size="-1"><font size="-1">
              and then press submit.</font></font></strong> <font size="-1" color="#D64200">
              </font><font size="-1"> <br>
              <input name="Email" size="30" >
              <br>
              </font></p>
          </div>
          <p align="center"><small>
            <input type="submit" value="Submit">
            </small></p>
          <p><strong>Your Password will be sent to you within few minutes.</strong>
          </p>
        </form>
        <p align="center">&nbsp;</p>
      </td>
    </tr>
    </table>
   </div>
   <?php
  }
  else
  {
  $rs  =  mysql_fetch_row($result);

  $to = $rs[7];

$message1=$message5;
$message1=str_replace("{name}","$rs[1]",$message1);
$message1=str_replace("{email}","$rs[7]",$message1);
$message1=str_replace("{username}","$rs[8]",$message1);
$message1=str_replace("{password}","$rs[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);

$subject1=str_replace("{name}","$rs[1]",$subject5);
$subject1=str_replace("{email}","$rs[7]",$subject1);
$subject1=str_replace("{username}","$rs[8]",$subject1);
$subject1=str_replace("{password}","$rs[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat5==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

  mail($to,$subject,$message,$header);

    echo("<br><br><br><b><center>Your Password had been send to your Email Address!<br></center></b><br><br><br><br><br><br><br>");
  }
}
echo("<BR><BR>");
include "footer.php";
?>