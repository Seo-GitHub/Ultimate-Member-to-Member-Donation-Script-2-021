<?php
  session_start();

  include "header.php";
  include "config.php";
  include "func.php";

if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {

  if (!$_POST) 
  {
	middle();
  }

    elseif ($_POST["pwd"]!="")

  {
 	if($_SESSION[password_session]==$_POST["pwd"])
	{

    print "<center><b>Your Payment Details has been updated successfully<br></b></center>";
	    $db_field[1]=validatet($_POST["payza"]);
        $db_field[2]=validatet($_POST["egopay"]);
        $db_field[3]=validatet($_POST["merchant1"]);
        $db_field[4]=validatet($_POST["merchant2"]);
        $db_field[5]=validatet($_POST["merchant3"]);
        $db_field[6]=validatet($_POST["merchant4"]);
        $db_field[7]=validatet($_POST["merchant5"]);
		mysql_query("update users set Payza='$db_field[1]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Egopay='$db_field[2]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Merchant1='$db_field[3]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Merchant2='$db_field[4]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Merchant3='$db_field[5]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Merchant4='$db_field[6]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Merchant5='$db_field[7]' where Username='$_SESSION[username_session]'");

        }
	else
	{
	    print "<center><b>Invalid Password! Account cannot be updated!<br></b></center>";
	}

    middle();
  } 
  else {
    middle();
  }

}


function middle()
  {
include "config.php";
		$username=$_SESSION["username_session"];
		$rs = mysql_query("select * from users where Username='$username'");
		$arr=mysql_fetch_array($rs);
			$name=$arr['Name'];
			$address=$arr['Address'];
			$city=$arr['City'];
			$state=$arr['State'];
			$zip=$arr['Zip'];
			$country=$arr['Country'];
			$password=$arr['Password'];
			$email=$arr['Email'];
$status=$arr[14];
$subs=$arr[19];
$pz=$arr[Payza];
$eg=$arr[25];
$m1=$arr[26];
$m2=$arr[27];
$m3=$arr[28];
$m4=$arr[29];
$m5=$arr[30];

?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Payment Information</b></font></p>
<br>
	<form method="post" action="">
	<table width="450" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr align="center" valign="middle"> 
                  <td colspan="2"><b>Update your Personal Information</b></td>
                </tr>
<?  if($payza!='0') { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Payza Email*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="payza" size="20" maxlength="40" value="<?php echo $pz; ?>">
                    </font></b></td>
                </tr>
<? } ?>
<?  if($egop[0]!='0') { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Egopay Email*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="egopay" size="20" maxlength="40" value="<?php echo $eg; ?>">
                    </font></b></td>
                </tr>
<? } ?>
<? if($extramerchants>0) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><? echo $merchantname1; ?>*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="merchant1" size="20" maxlength="40" value="<?php echo $m1; ?>">
                    </font></b></td>
                </tr>
<? } ?>
<? if($extramerchants>1) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><? echo $merchantname2; ?>*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="merchant2" size="20" maxlength="40" value="<?php echo $m2; ?>">
                    </font></b></td>
                </tr>
<? } ?>
<? if($extramerchants>2) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><? echo $merchantname3; ?>*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="merchant3" size="20" maxlength="40" value="<?php echo $m3; ?>">
                    </font></b></td>
                </tr>
<? } ?>
<? if($extramerchants>3) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><? echo $merchantname4; ?>*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="merchant4" size="20" maxlength="40" value="<?php echo $m4; ?>">
                    </font></b></td>
                </tr>
<? } ?>
<? if($extramerchants>4) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><? echo $merchantname5; ?>*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="merchant5" size="20" maxlength="40" value="<?php echo $m5; ?>">
                    </font></b></td>
                </tr>
<? } ?>

                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Password* 
                    </font></b></td>
                  <td width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="password" name="pwd" size="20" maxlength="40">
                    </font></b></td>
                </tr>
	                <tr align="left" valign="middle"> 
                  <td width="100%" colspan=2><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
		You need to enter your password to update your information.
                    </font></b></td>
                </tr>
	
                <tr align="center" valign="middle"> 
                  <td colspan="2" height="40"><b></b><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="submit" value="Update">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    </font></b></td>
                </tr>
              </table>
  </form> 
  </td>
  </tr>
</table>

</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php     return 1;
  }
include "footer.php";
?>