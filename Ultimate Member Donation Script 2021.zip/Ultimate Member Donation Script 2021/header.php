<?php include "config.php"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><? echo $sitename; ?></title>

<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div id="header-bg">
		<div id="header">
			<div class="logo"><img src="images/logo.jpg" /></div>
		   <div class="nav1">
		       <ul>
			  <li><a href="index.php">Home</a></li>
			  <li><a href="faq.php">FAQ's</a></li>
			  <li><a href="testimonials.php">Testimonials</a></li>
			  <li><a href="join.php">Join Now</a></li>
			  <li><a href="login.php">Login</a></li>
			  <li><a href="contactus.php"> Contact Us</a></li>
		      </ul>
		   </div>
			<div class="clear-both"></div>
		    <div class="header-banner"><img src="images/header.jpg" /></div>
		</div>
		<div id="all-content">
			<div id="left-bar">
			<?php if(!isset($_SESSION["username_session"])) { ?>
<form action="login.php" method="post">
				<div class="login-top">Member Login</div>
				<div class="login-middal">
					<table align="center" cellpadding="0" cellspacing="0" border="0">
						<tr>
							<td><input name="id" class="from-box" type="text"  id="textfield5" placeholder="User Name:" /></td>
						</tr>
						<tr>
							<td><input name="password" class="from-pass" type="password"  id="textfield5" placeholder="Password:" /></td>
						</tr>
						<tr>
							<td align="center"><input name="" type="image" src="images/login.jpg"/></td>
						</tr>
						<tr>
							<td class="forget-text"><a href="join.php">Register </a>| <a href="forgot.php">Forgot Password</a></td>
						</tr>
					</table>
				</div>
				<div class="login-bot"></div>
				  </form>
			  <?php } ?>
			  <?php if(isset($_SESSION["username_session"])) { ?>
			  <div class="text-add">Member Menu</div>	
				<div class="login-middal">
					<div class="side-menu">
					 
                   <ul>
					<li><a href="login.php">Members Home</a></li>
<li><a href="inviter.php">Invite Friends</a></li>
<li><a href="purchasepos.php">Purchase Position(s)</a></li>
<li><a href="managepos.php">Matrix Positions</a></li>
<li><a href="approvedgifts.php">Approved Gifts</a></li>
<li><a href="pendinggifts.php">Pending Gifts</a></li>
<li><a href="stats.php">Stats</a></li>
<li><a href="ads.php">Promotional Center</a></li>
<li><a href="banners.php">Banner Advertisement</a></li>
<li><a href="textadv.php">Text Ad Advertisement</a></li>
<li><a href="bonus.php">Bonus</a></li>
<li><a href="paymentinfo.php">Payment Info</a></li>
<li><a href="update_pf.php">Profile</a></li>
<li><a href="submittestimonials.php">Submit Testimonials</a></li>
<li><a href="logout.php">Logout</a></li>
                </ul>
		    
                </div>
					<div class="clear-both"></div>
				</div>
				<?php } ?>
				
			  
				<div style="padding-top: 10px;"></div>
				<div class="text-add">Text Ads</div>
				<div class="login-middal">
				<?php 
$rs=mysql_query("select * from memberstextads where remaining>0 and approved=1 order by rand() limit 0,$nads");
if(mysql_num_rows($rs)<1) { ?>

					<table style="padding-top: 6px;" width="173px;" align="center" cellpadding="0" cellspacing="0" border="0">
						<tr>
							<td  class="text-add-title"><a href="#">Text Ads Title Text</a></td>
						</tr>
						<tr>
							<td class="text-add-text">
Text ads here Text ads here<br/>
							Text ads here Text ads here<br/>
							Text ads here Text ads here<br/></td>
						</tr>
					</table>
					<?php }
while($arr=mysql_fetch_array($rs)) {
$rsu=mysql_query("update memberstextads set remaining=remaining-1 where ID=$arr[0]");
?>
					<table style="padding-top: 6px;" width="173px;" align="center" cellpadding="0" cellspacing="0" border="0">
						<tr>
							<td  class="text-add-title"><a href="<? echo "$siteurl/tr1.php?id=$arr[0]"; ?>" target="_blank"><b><? echo stripslashes($arr[2]); ?></b></a></td>
						</tr>
						<tr>
							<td class="text-add-text">
<br><? echo stripslashes($arr[9]); ?></td>
						</tr>
					</table>
					<?php } ?>
					
				</div>
				<div class="login-bot"></div>
			</div>
			<div id="right-bar">
			
	