<?php
// Provide Values for Database
$dbhost="localhost";
$dbname="email: