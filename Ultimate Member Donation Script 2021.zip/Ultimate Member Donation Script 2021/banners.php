<?php
  session_start();

include "header.php";
  include "func.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
middle();
} 

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$email=$arr[7];
$totban=$arr[20];
$banused=$arr[21];
$tottext=$arr[22];
$textused=$arr[23];
$id=(int)$_POST[id];
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td>
			<font face="verdana" size="3"><b>
			<p><center>Banner Advertisement</center></b></font></p><font face=verdana size=2><br>
<?php
$unused=$totban-$banused;
if(!$_POST) {
echo "<br><b>Banner Credits Available $unused</b><br>";
if($unused>0) {  ?>
<br><center><b>Add New Banner</b><br><br>
</font><font face="verdana" size="2">Banner Url is the location of the image of
the banner.<br>
Make sure your banner shows correctly before approving it</font><font face=verdana size=2>.</font></b></center><font face=verdana size=2>
<form action='' method=post>
<table>
<tr><td><font face=verdana size=2>Banner Url:</td><td><input type=text name=burl value="http://"></td></tr>
<tr><td><font face=verdana size=2>Website Url:</td><td><input type=text name=wurl value="http://"></td></tr>
<tr><td><font face=verdana size=2>Assign Credits:</td><td><input type=text name=credits value="<?php echo $unused; ?>"></td></tr>
<tr><td colspan=2><input type=submit name=b value="Preview"> </td></tr>
</table></form>

</font>
<font face=verdana size=2>

<?php
}
echo "<div align=left>";
$rsb=mysql_query("select * from membersbanners where Username='$_SESSION[username_session]' and approved<2");
?>
<br>
<center>
  <b>Stats</b>
</center>
<br>
<?php
if(mysql_num_rows($rsb)>0) {
echo "<table>";
while($arrb=mysql_fetch_array($rsb)) {
echo "<tr><td colspan=2><font face=verdana size=2>Banner:<br><a href=$arrb[3] target=_blank><img src=$arrb[2] width=468 height=60 border=0></a></td></tr>";
echo "<tr><td><font face=verdana size=2>No of credits :</td><td><font face=verdana size=2>$arrb[4]</td></tr>";
echo "<tr><td><font face=verdana size=2>No of credits shown :</td><td><font face=verdana size=2>".($arrb[4]-$arrb[5])."</td></tr>";
echo "<tr><td><font face=verdana size=2>No of clicks :</td><td><font face=verdana size=2>$arrb[6]</td></tr>";

if($arrb[7]==0) {
echo "<tr><td colspan=2><font face=verdana size=2>Waiting for admin approval</td></tr>";
}
else {
echo "<tr><td colspan=2><form action='' method=post><input type=hidden name=id value=$arrb[0]><input type=submit name=b value=Edit> &nbsp; &nbsp; <input type=submit name=b value=Delete></form></td></tr>";
}
echo "<tr><td colspan=2><hr></td></tr>";
}
echo "</table>";

}
else {
echo "<br>No Stats Available<br>";
}
 
 }
else {
if($_POST[b]=="Add") {
$burl=validatet($_POST[burl]);
$wurl=validatet($_POST[wurl]);
$burl=str_replace("<a href=","",$burl);
$burl=str_replace("</a>","",$burl);
$burl=str_replace("<img src=","",$burl);
$wurl=str_replace("<a href=","",$wurl);
$wurl=str_replace("</a>","",$wurl);
$wurl=str_replace("<img src=","",$wurl);
$credits=(int)$_POST[credits];
if(($burl=="")||($burl=="http://")) {
echo "<b><br>Invalid Banner Url</b><br>";
}
elseif(($wurl=="")||($wurl=="http://")) {
echo "<b><br>Invalid Website Url</b><br>";
}
elseif($credits>$unused) {
echo "<b><br>You don't have enough credits to add this banner</b><br>";
}
elseif($credits<1) {
echo "<b><br>Invalid credits!</b><br>";
}
else {
$sql_i="insert into membersbanners(Username,BannerURL,WebsiteURL,assigned,remaining,hits,approved,Date) values('$_SESSION[username_session]','$burl','$wurl',$credits,$credits,0,0,now())";
$rsi=mysql_query($sql_i);
mysql_query("update users set bannersused=bannersused+$credits where Username='$_SESSION[username_session]'");
echo "<br><br><b>Your banner has been added and is waiting for the admin approval.</b><br>";
}

}
elseif($_POST[b]=="Preview") {
$burl=validatet($_POST[burl]);
$wurl=validatet($_POST[wurl]);
$burl=str_replace("<a href=","",$burl);
$burl=str_replace("</a>","",$burl);
$burl=str_replace("<img src=","",$burl);
$wurl=str_replace("<a href=","",$wurl);
$wurl=str_replace("</a>","",$wurl);
$wurl=str_replace("<img src=","",$wurl);
$credits=(int)$_POST[credits];
echo "<br><b>Banner Credits Available $unused</b><br>";
if(($burl=="")||($burl=="http://")) {
echo "<b><br>Invalid Banner Url</b><br>";
}
elseif(($wurl=="")||($wurl=="http://")) {
echo "<b><br>Invalid Website Url</b><br>";
}
elseif($credits>$unused) {
echo "<b><br>You don't have enough credits to add this banner</b><br>";
}
elseif($credits<1) {
echo "<b><br>Invalid credits!</b><br>";
}
else { 
echo "<form action='' method=post><input type=hidden name=burl value=$burl><input type=hidden name=wurl value=$wurl><input type=hidden name=credits value=$credits>";
echo "<a href=$wurl><img src=$burl border=0 width=468 height=60></a>";
echo "<br>If this banner is appearing correctly, then press the Add button. If it is not appearing correctly, then go back to the previous page, and change the banner.<br><input type=submit name=b value=Add></form>";
}
}
elseif($_POST[b]=="Edit") {
if($_POST[edit1]=="") {
$rs=mysql_query("select * from membersbanners where ID=$id and Username='$_SESSION[username_session]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
echo "<br><b>Banner Credits Available $unused</b><br>";
echo "<form action='' method=post><input type=hidden name=id value=$id>
<input type=hidden name=edit1 value=edit>
<table>
<tr><td><font face=verdana size=2>Banner Url:</td><td><input type=text name=burl value=\"$arr[2]\"></td></tr>
<tr><td><font face=verdana size=2>Website Url:</td><td><input type=text name=wurl value=\"$arr[3]\"></td></tr>
<tr><td><font face=verdana size=2>Credits Available:</td><td><font face=verdana size=2>$arr[5]</td></tr><tr><td>Add Credits</td><td><input type=text name=credits size=5><font size=1 face=verdana> ( To subtract credits use '-' sign before credits)</font></td></tr>
<tr><td colspan=2><input type=submit name=b value=Edit></td></tr></table></form>";
}
}
else {
$rs=mysql_query("select * from membersbanners where ID=$id and Username='$_SESSION[username_session]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$credits=$arr[4];
$rem=$arr[5];
$credits1=$_POST[credits];
$newcredits=$credits1;//-$rem;
$burl=validatet($_POST[burl]);
$wurl=validatet($_POST[wurl]);
$burl=str_replace("<a href=","",$burl);
$burl=str_replace("</a>","",$burl);
$burl=str_replace("<img src=","",$burl);
$wurl=str_replace("<a href=","",$wurl);
$wurl=str_replace("</a>","",$wurl);
$wurl=str_replace("<img src=","",$wurl);

if(($burl=="")||($burl=="http://")) {
echo "<b><br>Invalid Banner Url</b><br>";
}
elseif(($wurl=="")||($wurl=="http://")) {
echo "<b><br>Invalid Website Url</b><br>";
}
elseif($credits1>$unused) {
echo "<b><br>You don't have enough credits to add this banner</b><br>";
}
elseif($credits1<-$rem) {
echo "<b><br>Invalid credits!</b><br>";
}
else {
if(($burl!=$arr[2])||($wurl!=$arr[3])) {
$sql_i="update membersbanners set BannerURL='$burl',WebsiteURL='$wurl',approved=0 where ID=$id and Username='$_SESSION[username_session]'";
$rsi=mysql_query($sql_i);
echo "<br><br><b>Your banner has been successfully updated, and is waiting for the admin approval.</b><br>";
}
$sql_i="update membersbanners set assigned=assigned+$newcredits,remaining=remaining+$newcredits where ID=$id and Username='$_SESSION[username_session]'";
$rsi=mysql_query($sql_i);
mysql_query("update users set bannersused=bannersused+$credits1 where Username='$_SESSION[username_session]'");


echo "<br><br><b>Credits updated successfully.</b><br>";
}


}
}
}
elseif($_POST[b]=="Delete") {
$rs=mysql_query("update membersbanners set approved=2 where ID=$id and Username='$_SESSION[username_session]'");
$rs=mysql_query("select * from membersbanners where ID=$id and Username='$_SESSION[username_session]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
	$rem=$arr[5];
    mysql_query("update users set bannersused=bannersused-$rem where Username='$_SESSION[username_session]'");
}

echo "<br><br><b>Banner Successfully Deleted</b><br><br>";
}
}
?>
</td></tr></table>


</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php }
include "footer.php";
?>