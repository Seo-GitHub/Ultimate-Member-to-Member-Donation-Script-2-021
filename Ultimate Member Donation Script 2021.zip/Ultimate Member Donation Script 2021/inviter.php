<?php
  session_start();

include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
  middle();
}

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$check=1;
	$email=$arr[7];
        $name=$arr[1];
	$ref=$arr[11];
	$username=$_SESSION[username_session];
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
	}
	else {
		$statust="Pro";
	}
	$total=$arr[15];
	$paid=$arr[17];
	$unpaid=$arr[16];


?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b>
<p align="center">Invite Your Friends&nbsp;</p></b></font>
<br>
		<div align="center">
		<table border="0" cellpadding="3" align="center" cellspacing="0" width="450">
		     
<!-- SMARTADDON BEGIN -->
<script type="text/javascript">
(function() {
var s=document.createElement('script');s.type='text/javascript';s.async = true;
s.src='http://s1.smartaddon.com/share_addon.js';
var j =document.getElementsByTagName('script')[0];j.parentNode.insertBefore(s,j);
})();
</script>

<div id="sa_share_bar">
<a id="sa_share_facebook" layout="icon" url="http://m2m-matrix.buy4script.net/" size="24"></a>
<a id="sa_share_twitter" layout="icon" url="http://m2m-matrix.buy4script.net/" size="24"></a>
<a id="sa_share_googleplus" layout="icon" url="http://m2m-matrix.buy4script.net/" size="24"></a>
<a id="sa_share_email" layout="icon" url="http://m2m-matrix.buy4script.net/" size="24"></a>
<a id="sa_share_share" layout="icon" url="http://m2m-matrix.buy4script.net/" size="24"></a>
</div>
<!-- SMARTADDON END -->
	</table>
</td></tr></table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php }
include "footer.php";
?>