<?php
session_start();

include "func.php";
foreach($_GET as $k=>$v)
$id .=$k;
$id=validatet($id);
if($id !="") {
//if($_SESSION["refid_session"]=="") {
$_SESSION["refid_session"]=$id ;
//}
}

?>
<iframe border="0" width="100%" height="100%" src="http://videos.multimillionmatrix.com/"></iframe>