<?php
function validatet($ad) {
  $ad=trim($ad);
  $ad=str_replace("'","",$ad);
  $ad=str_replace("\"","",$ad);
  $ad=str_replace("\\","",$ad);
  $ad=str_replace("<script","",$ad);
  $ad=str_replace("</script","",$ad);
  $ad=str_replace("<iframe","",$ad);
  $ad=str_replace("</iframe","",$ad);
  $ad=str_replace("&lt;script","",$ad);
  $ad=str_replace("&lt;IFRAME","",$ad);
  $ad=str_replace("&lt;/script","",$ad);
  $ad=str_replace("&lt;/IFRAME","",$ad);

  return $ad;
}
?>