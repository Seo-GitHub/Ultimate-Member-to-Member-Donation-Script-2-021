<?php
include "config.php";
$dtext="";
$rs=mysql_query("select ID,BannerURL from membersbanners where remaining>0 and approved=1 order by rand() limit 0,$showban");
while($arr=mysql_fetch_array($rs)) {
$dtext.="<br><center><a href=$siteurl/trr.php?id=$arr[0] target=_blank><img src=$arr[1] width=468 height=60 border=0></a><br></center><br>";
$rsu=mysql_query("update membersbanners set remaining=remaining-1 where ID=$arr[0]");
}
mysql_close($dbconnect);
echo "document.write('$dtext');"; 
?>